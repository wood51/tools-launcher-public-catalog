# Programmes

Plugin Tools Launcher 0.2.0 pour lancer les applications du PC.

Dans **Programmes → Gérer les programmes…**, cliquer sur **Ajouter**, choisir
un ou plusieurs exécutables ou raccourcis Windows, ou les glisser dans la
fenêtre, comme dans Files. Le nom est modifiable directement dans la liste.
**Modifier** permet de changer le chemin, la catégorie ou les droits administrateur.
La catégorie est facultative : vide, le programme apparaît directement ;
renseignée, elle crée un sous-menu. Plusieurs programmes peuvent partager une catégorie.

Les icônes sont lues par le fournisseur natif Windows depuis les exécutables
et les raccourcis. Pour conserver des paramètres de lancement ou une icône
personnalisée, sélectionner un raccourci `.lnk`. Les applications du Microsoft
Store nécessitent un raccourci Windows utilisable.

Pour Regedit ou un autre outil nécessitant des droits élevés, cocher
**Exécuter en tant qu’administrateur** dans Modifier. Windows présente sa
demande UAC ; l’outil ne la valide pas à votre place. Une demande d’élévation
de Windows (erreur 740) est également prise en charge automatiquement.

**Retirer** ou la touche **Suppr** enlève les lignes sélectionnées du menu,
sans supprimer les programmes du PC. La sélection multiple est possible.
Les changements sont enregistrés immédiatement avec l'API du Launcher dans
`extensions/programmes/data/programmes.json`, avec une sauvegarde `.json.bak`.
Les listes de la version 0.1.0 sont reprises sans conversion manuelle.

Le menu, les données et les notifications utilisent l’API du Launcher.
L’ouverture Windows et la gestion de la sélection suivent Files, pour être
compatibles avec le Launcher public 1.3.0.

Installation locale : copier `extension.json`, `main.py` et `ui.py` dans
`extensions/programmes/` du Launcher, puis le redémarrer. Aucune dépendance
supplémentaire. Le plugin utilise le thème du Launcher.

Tests depuis la racine du dépôt :
`.venv\Scripts\python.exe -m unittest discover -s projects/programmes/tests -v`
