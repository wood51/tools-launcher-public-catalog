"""Composants de sdk/ui.py embarqués pour les installations sans le SDK."""

from PySide6.QtWidgets import QMessageBox, QPushButton, QVBoxLayout, QWidget


def window(title: str, width: int = 520, height: int = 360):
    root = QWidget()
    root.setObjectName("root")
    root.setWindowTitle(title)
    root.resize(width, height)
    return root, QVBoxLayout(root)


def button(text: str, callback=None, variant: str = "accent"):
    if variant not in {"accent", "neutral", "danger"}:
        raise ValueError(f"variante inconnue : {variant}")
    item = QPushButton(text)
    item.setObjectName({"accent": "primary", "danger": "danger", "neutral": ""}[variant])
    if callback:
        item.clicked.connect(callback)
    return item


def show_error(parent, title: str, message: str) -> None:
    QMessageBox.critical(parent, title, message)
