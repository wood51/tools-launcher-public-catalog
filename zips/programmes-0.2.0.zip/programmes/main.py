"""Applications locales dans le menu Tools Launcher, classées si souhaité."""

import os
import shutil
from pathlib import Path

from PySide6.QtCore import QFileInfo, Qt
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame,
    QFileIconProvider, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .ui import button, show_error


def target_path(text):
    path = Path(os.path.expandvars(text.strip().strip('"'))).expanduser()
    if not path.is_file() and path.parent == Path('.'):
        return Path(shutil.which(str(path)) or path)
    return path


def menu_text(text):
    # Qt interprète sinon les esperluettes comme des raccourcis clavier.
    return text.replace("&", "&&")


class Programmes:
    def __init__(self, api):
        self.api = api
        self.manager = None
        self.icons = QFileIconProvider()

    def icon(self, path):
        # Windows fournit l'icône de l'exécutable ou l'icône personnalisée du .lnk.
        return self.icons.icon(QFileInfo(str(target_path(path))))

    def load(self):
        data = self.api.load_json("programmes.json")
        if data is None and not (self.api.data_dir / "programmes.json").exists():
            return []
        if not isinstance(data, list) or any(
            not isinstance(item, dict)
            or any(not isinstance(item.get(key), str) for key in ("name", "path", "category"))
            or not item["name"].strip() or not item["path"].strip()
            or not isinstance(item.get("admin", False), bool)
            for item in data
        ):
            raise ValueError("La liste des programmes est illisible. Le fichier existant est conservé.")
        return data

    def save(self, entries):
        path = self.api.data_dir / "programmes.json"
        if path.exists():
            shutil.copy2(path, path.with_suffix(".json.bak"))
        self.api.save_json("programmes.json", entries)

    def launch(self, entry):
        path = target_path(entry["path"])
        if not path.is_file():
            self.api.notify("Programme introuvable", f'{entry["name"]} : {path}', level="error")
            return
        try:
            # Comme Files : le Shell Windows gère les raccourcis et la demande UAC.
            if entry.get("admin", False):
                os.startfile(str(path), "runas")
            else:
                try:
                    os.startfile(str(path))
                except OSError as error:
                    if getattr(error, "winerror", None) != 740:
                        raise
                    os.startfile(str(path), "runas")
        except OSError as error:
            if getattr(error, "winerror", None) == 1223:
                self.api.notify("Lancement annulé", "La demande de droits administrateur a été annulée.", level="warning")
            else:
                self.api.notify("Lancement impossible", f'{entry["name"]} : {error}', level="error")

    def build_menu(self, menu):
        try:
            entries = self.load()
        except (OSError, ValueError) as error:
            menu.addAction("Liste des programmes illisible").setEnabled(False)
            self.api.log(str(error))
            entries = []
        if not entries and not menu.actions():
            menu.addAction("Aucun programme ajouté").setEnabled(False)
        groups = {}
        for entry in sorted(entries, key=lambda item: (item["category"].casefold(), item["name"].casefold())):
            category = entry["category"]
            parent = menu
            if category:
                if category not in groups:
                    groups[category] = menu.addMenu(menu_text(category))
                parent = groups[category]
            action = parent.addAction(self.icon(entry["path"]), menu_text(entry["name"]))
            action.setToolTip(entry["path"])
            action.triggered.connect(lambda checked=False, item=entry: self.launch(item))
        menu.addSeparator()
        menu.addAction("Gérer les programmes…", self.show_manager)

    def show_manager(self):
        if self.manager is None:
            try:
                self.manager = ProgramManager(self)
            except (OSError, ValueError) as error:
                show_error(None, "Programmes", str(error))
                return
        elif not self.manager.isVisible():
            try:
                self.manager.refresh(self.load())
            except (OSError, ValueError) as error:
                show_error(self.manager, "Programmes", str(error))
                return
        self.manager.show()
        self.manager.raise_()
        self.manager.activateWindow()

    def close(self):
        if self.manager is not None:
            self.manager.close()


class ProgramEditor(QDialog):
    def __init__(self, api, categories, entry=None, parent=None):
        super().__init__(parent)
        self.api = api
        self.setObjectName("root")
        self.setWindowTitle("Modifier le programme" if entry else "Ajouter un programme")
        self.resize(580, 240)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.name_input = QLineEdit()
        self.path_input = QLineEdit()
        self.path_input.setPlaceholderText("Exécutable ou raccourci Windows")
        path_row = QHBoxLayout()
        path_row.addWidget(self.path_input, 1)
        path_row.addWidget(button("Parcourir…", self.browse, "neutral"))
        self.category = QComboBox()
        self.category.setEditable(True)
        self.category.addItem("")
        self.category.addItems(sorted(set(categories), key=str.casefold))
        self.category.lineEdit().setPlaceholderText("Facultatif — vide pour un accès direct")
        form.addRow("&Nom", self.name_input)
        form.addRow("&Programme", path_row)
        form.addRow("&Catégorie", self.category)
        self.admin = QCheckBox("Exécuter en tant qu’administrateur")
        form.addRow("", self.admin)
        layout.addLayout(form)
        self.error = QLabel()
        self.error.setWordWrap(True)
        layout.addWidget(self.error)
        actions = QHBoxLayout()
        actions.addStretch()
        cancel = button("Annuler", self.reject, "neutral")
        cancel.setAutoDefault(False)
        actions.addWidget(cancel)
        save = button("Enregistrer", self.accept)
        save.setDefault(True)
        actions.addWidget(save)
        layout.addLayout(actions)
        if entry:
            self.name_input.setText(entry["name"])
            self.path_input.setText(entry["path"])
            self.category.setCurrentText(entry["category"])
            self.admin.setChecked(entry.get("admin", False))

    def browse(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Choisir un programme", "",
            "Programmes Windows (*.exe *.lnk *.appref-ms *.bat *.cmd);;Tous les fichiers (*)",
            options=QFileDialog.Option.DontResolveSymlinks,
        )
        if filename:
            self.path_input.setText(filename)
            if not self.name_input.text().strip():
                self.name_input.setText(Path(filename).stem)

    def entry(self):
        return {"name": self.name_input.text().strip(),
                "path": str(target_path(self.path_input.text())),
                "category": self.category.currentText().strip(), "admin": self.admin.isChecked()}

    def accept(self):
        entry = self.entry()
        if not entry["name"]:
            self.error.setText("Saisissez un nom pour ce programme.")
            self.name_input.setFocus()
            return
        if not self.path_input.text().strip() or not target_path(entry["path"]).is_file():
            self.error.setText("Choisissez un programme ou un raccourci existant.")
            self.path_input.setFocus()
            return
        super().accept()


class ProgramManager(QWidget):
    """Liste éditable et glisser-déposer, suivant le parcours de Files."""
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.api = controller.api
        self.widget = self
        self.setObjectName("root")
        self.setWindowTitle("Programmes")
        self.resize(820, 520)
        self.setAcceptDrops(True)
        layout = QVBoxLayout(self)
        title = QLabel("Vos programmes")
        title.setObjectName("title")
        layout.addWidget(title)
        hint = QLabel("Lancez vos applications depuis le menu Programmes. Les catégories sont facultatives.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.drop = QFrame()
        self.drop.setObjectName("drop")
        self.drop.setMinimumHeight(72)
        drop_layout = QVBoxLayout(self.drop)
        drop_hint = QLabel("Glissez des programmes ou des raccourcis ici pour les ajouter")
        drop_hint.setAlignment(Qt.AlignCenter)
        drop_hint.setWordWrap(True)
        drop_layout.addWidget(drop_hint)
        layout.addWidget(self.drop)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Nom (modifiable)", "Catégorie", "Emplacement"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked | QAbstractItemView.EditTrigger.EditKeyPressed)
        self.table.setAlternatingRowColors(True)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.itemChanged.connect(self.on_item_changed)
        self.delete_shortcut = QShortcut(QKeySequence(Qt.Key_Delete), self.table)
        self.delete_shortcut.activated.connect(self.remove)
        layout.addWidget(self.table, 1)
        self.empty = QLabel("Aucun programme. Cliquez sur Ajouter pour choisir une application du PC.")
        self.empty.setWordWrap(True)
        layout.addWidget(self.empty)
        actions = QHBoxLayout()
        actions.addWidget(button("Ajouter", self.add))
        self.edit_button = button("Modifier", self.edit, "neutral")
        self.remove_button = button("Retirer", self.remove, "danger")
        self.launch_button = button("Lancer", self.launch, "neutral")
        for item in (self.edit_button, self.remove_button, self.launch_button):
            actions.addWidget(item)
        actions.addStretch()
        actions.addWidget(button("Fermer", self.close, "neutral"))
        layout.addLayout(actions)
        self.table.itemSelectionChanged.connect(self.update_actions)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.refresh(controller.load())

    def refresh(self, entries):
        selected = self.selected_rows()
        self.entries = entries
        self.table.blockSignals(True)
        self.table.setRowCount(len(entries))
        for row, entry in enumerate(entries):
            name = QTableWidgetItem(self.controller.icon(entry["path"]), entry["name"])
            self.table.setItem(row, 0, name)
            category = QTableWidgetItem(entry["category"] or "Sans catégorie")
            category.setFlags(category.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(row, 1, category)
            path = QTableWidgetItem(entry["path"])
            path.setFlags(path.flags() & ~Qt.ItemIsEditable)
            path.setToolTip(entry["path"] + ("\nAdministrateur" if entry.get("admin") else ""))
            self.table.setItem(row, 2, path)
        self.table.clearSelection()
        if selected and entries:
            self.table.selectRow(min(selected[0], len(entries) - 1))
        self.table.blockSignals(False)
        self.empty.setVisible(not entries)
        self.update_actions()

    def update_actions(self):
        rows = self.selected_rows()
        self.remove_button.setEnabled(bool(rows))
        self.edit_button.setEnabled(len(rows) == 1)
        self.launch_button.setEnabled(len(rows) == 1)

    def selected_rows(self):
        return sorted({index.row() for index in self.table.selectedIndexes()})

    def persist(self, entries):
        try:
            self.controller.save(entries)
        except (OSError, ValueError) as error:
            show_error(self.widget, "Enregistrement impossible", str(error))
            return False
        self.refresh(entries)
        return True

    def edit_entry(self, index=None):
        dialog = ProgramEditor(self.api, [item["category"] for item in self.entries if item["category"]],
                               self.entries[index] if index is not None else None, self.widget)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            entries = list(self.entries)
            if index is None:
                entries.append(dialog.entry())
            else:
                entries[index] = dialog.entry()
            self.persist(entries)

    def add(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Ajouter des programmes", "",
            "Programmes Windows (*.exe *.lnk *.appref-ms *.bat *.cmd *.msc);;Tous les fichiers (*)",
            options=QFileDialog.Option.DontResolveSymlinks,
        )
        if paths:
            self.add_paths(paths)

    def add_paths(self, paths):
        entries = list(self.entries)
        known = {os.path.normcase(str(target_path(item["path"]).resolve())) for item in entries}
        added = 0
        for text in paths:
            path = target_path(text)
            key = os.path.normcase(str(path.resolve()))
            if path.is_file() and key not in known:
                entries.append({"name": path.stem, "path": str(path), "category": "", "admin": False})
                known.add(key)
                added += 1
        if added and self.persist(entries):
            self.status.setText(f"{added} programme(s) ajouté(s). Utilisez Modifier pour choisir une catégorie ou les droits administrateur.")
        elif not added:
            self.status.setText("Aucun ajout : les fichiers sont déjà présents ou introuvables.")

    def on_item_changed(self, item):
        if item.column() == 0:
            entries = [dict(entry) for entry in self.entries]
            entries[item.row()]["name"] = item.text().strip() or target_path(entries[item.row()]["path"]).stem
            if not self.persist(entries):
                self.refresh(self.entries)

    def edit(self):
        rows = self.selected_rows()
        if len(rows) == 1:
            self.edit_entry(rows[0])

    def remove(self):
        rows = set(self.selected_rows())
        if rows and self.persist([entry for index, entry in enumerate(self.entries) if index not in rows]):
            self.status.setText(f"{len(rows)} entrée(s) retirée(s) du menu. Les applications restent installées.")

    def launch(self):
        rows = self.selected_rows()
        if len(rows) == 1:
            self.controller.launch(self.entries[rows[0]])

    def set_drop_hover(self, hover):
        self.drop.setProperty("hover", hover)
        self.drop.style().unpolish(self.drop)
        self.drop.style().polish(self.drop)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.set_drop_hover(True)

    def dragLeaveEvent(self, event):
        self.set_drop_hover(False)
        event.accept()

    def dropEvent(self, event):
        self.set_drop_hover(False)
        self.add_paths([url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()])
        event.acceptProposedAction()


def register(api):
    controller = Programmes(api)
    api.add_menu("Programmes", controller.build_menu)
    api.on_quit(controller.close)
