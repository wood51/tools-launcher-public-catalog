# Publication

Outil d'auteur : crée ou importe une clé de signature, signe une extension (zip ou dossier) et la publie dans un catalogue.

Deux onglets : **Publication** pour choisir l’extension, son catalogue et les options Git ; **Clés de signature** pour gérer les clés privées ou approuver une clé publique reçue.

- **Clé de signature** : la clé privée reste dans `~/.tools_launcher_signing/<id>.key`, chiffrée par un mot de passe (jamais enregistré). Pour qu'un lanceur accepte vos extensions, la clé **publique** doit figurer dans `core/assets/trusted_keys.json` (à commiter avec le lanceur). Un collaborateur génère sa clé, vous envoie le fichier `.pub.json`, et vous l'ajoutez avec « Clé publique reçue… » (en la limitant à ses extensions).
- **Extension** : glissez un zip ou un dossier d'extension. Les contrôles sont ceux de l'installation.
- **Signer le zip** : écrit une copie avec `SIGNATURE.json` (un seul fichier à transmettre).
- **Publier localement** : indiquez ou parcourez le dossier racine du clone Git local, puis l’outil signe, copie dans `<catalogue>/zips/` et met `index.json` à jour.
- **Créer le commit et envoyer au dépôt Git** : cochez cette option avant de publier pour envoyer aussi la publication avec Dulwich, sans `git.exe`. Le clone doit suivre une branche d’`origin` et disposer d’un nom et d’une adresse e-mail Git configurés. Les dépôts HTTPS et les dépôts locaux sont pris en charge. Seuls `index.json` et le ZIP de cette publication sont ajoutés au commit ; les autres modifications restent en place. Si des commits locaux attendent déjà ou si le dépôt distant a changé, synchronisez le clone avant de reprendre. Aucun push forcé ni synchronisation automatique.
- **Jeton Git** : pour un dépôt privé ou l’envoi HTTPS, fournir un jeton ayant accès au dépôt et le droit d’écriture sur son contenu. La clé de signature et le jeton Git sont distincts : la signature utilise une clé privée, Git utilise un jeton d’accès. La mémorisation du jeton est facultative, propre à l’adresse du dépôt, et chiffrée avec Windows DPAPI pour le compte Windows courant sur ce PC. Sans mémorisation, le champ est effacé à la fin de l’envoi. Ne pas mettre d’identifiants dans l’URL du dépôt.
- **Reprendre l’envoi Git** : après un échec, le catalogue et le commit éventuel restent disponibles localement. La reprise est mémorisée et reste disponible après fermeture de l’outil ; elle ne crée pas un deuxième commit. L’envoi tourne en arrière-plan. Attendre son résultat avant de fermer Publication.

Les réglages, le jeton chiffré si demandé et le suivi de reprise utilisent l’API du Launcher, dans `extensions/publisher/data/`. La clé privée de signature reste dans son emplacement dédié.

Pour installer ailleurs, seule la **clé publique** de l’auteur doit être approuvée dans le Launcher du poste destinataire. La clé privée et son mot de passe restent sur le poste de publication. Un catalogue privé demande un jeton de lecture dans les sources du Catalogue ; ce jeton ne remplace pas la vérification de signature. Une nouvelle version d’outil s’installe depuis le Catalogue actualisé, en conservant le dossier `data/` de l’extension.
