"""Envoi du seul commit de publication avec Dulwich, sans git.exe."""

import io
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

from dulwich import porcelain
from dulwich.client import get_transport_and_path
from dulwich.repo import Repo


class GitPublishError(ValueError):
    def __init__(self, message, commit=None):
        super().__init__(message)
        self.commit = commit


def origin_url(repo):
    config = repo.get_config_stack()
    try:
        remote = config.get((b"remote", b"origin"), b"url").decode("utf-8")
    except KeyError:
        raise GitPublishError("Le clone ne possède pas de dépôt distant origin.") from None
    try:
        remote = config.get((b"remote", b"origin"), b"pushurl").decode("utf-8")
    except KeyError:
        pass
    if "://" in remote:
        url = urlsplit(remote)
        if url.scheme != "https" or not url.hostname or url.username or url.password:
            raise GitPublishError("Utilisez une adresse origin HTTPS sans identifiants dans l’URL.")
    elif not Path(remote).is_dir():
        raise GitPublishError("Le dépôt origin doit être une adresse HTTPS ou un dépôt local.")
    return remote


def catalog_destination(catalog):
    """Adresse de publication, utilisée pour associer chaque jeton à son dépôt."""
    if not str(catalog).strip():
        raise GitPublishError("Choisissez le clone Git local du catalogue.")
    try:
        with Repo(str(catalog)) as repo:
            return origin_url(repo)
    except GitPublishError:
        raise
    except Exception:
        raise GitPublishError("Choisissez la racine du clone Git local du catalogue.") from None


def send_catalog(job, token="", save=None):
    """Commit index + ZIP, puis push normal. `save` mémorise le commit avant l'envoi.

    Un échec de push ne retire jamais le commit local. Un nouvel appel avec
    `job['commit']` reprend exactement cet envoi, sans second commit.
    """
    commit = job.get("commit")
    try:
        catalog = Path(job["catalog"]).resolve()
        zip_name = PurePosixPath(job["zip"])
        if (len(zip_name.parts) != 2 or zip_name.parts[0] != "zips"
                or zip_name.suffix != ".zip" or ".." in zip_name.parts or ":" in str(zip_name)):
            raise GitPublishError("Chemin de ZIP invalide.")
        files = ["index.json", zip_name.as_posix()]
        for name in files:
            path = catalog / name
            if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(catalog):
                raise GitPublishError("Le catalogue doit contenir index.json et le ZIP publié.")
        with Repo(str(catalog)) as repo:
            if repo.bare or Path(repo.path).resolve() != catalog:
                raise GitPublishError("Choisissez la racine du clone Git local du catalogue.")
            control = Path(repo.controldir())
            if any((control / name).exists() for name in ("MERGE_HEAD", "rebase-merge", "rebase-apply")):
                raise GitPublishError("Terminez la fusion ou le rebase du catalogue avant de publier.")
            head_ref = repo.refs.read_ref(b"HEAD")
            if not head_ref or not head_ref.startswith(b"ref: refs/heads/"):
                raise GitPublishError("Le catalogue doit être positionné sur une branche locale.")
            branch = head_ref.removeprefix(b"ref: ")
            config = repo.get_config_stack()
            remote = origin_url(repo)
            if job.get("remote") and job["remote"] != remote:
                raise GitPublishError("L’adresse origin a changé depuis la préparation de l’envoi. Vérifiez le clone du catalogue.")
            # Respecter la branche suivie quand elle appartient à origin.
            remote_branch = branch
            section = (b"branch", branch.removeprefix(b"refs/heads/"))
            try:
                if config.get(section, b"remote") != b"origin":
                    raise GitPublishError("La branche du catalogue doit suivre origin.")
                remote_branch = config.get(section, b"merge")
            except KeyError:
                pass
            if not remote_branch.startswith(b"refs/heads/"):
                raise GitPublishError("Branche distante invalide.")
            credentials = {"username": "token", "password": token} if token and remote.startswith("https://") else {}
            client, transport_path = get_transport_and_path(remote, config=config, **credentials)
            refs = client.get_refs(transport_path).refs
            remote_head = refs.get(remote_branch)
            head = repo.head()
            if commit:
                if head.decode() != commit:
                    raise GitPublishError("La branche a changé depuis l’échec de l’envoi. Vérifiez le catalogue.")
                if remote_head == head:
                    return commit  # Réponse réseau perdue après un push déjà réussi.
                if repo[head].parents != [remote_head]:
                    raise GitPublishError("Le dépôt distant a changé. Synchronisez le catalogue avant de reprendre.")
            else:
                if remote_head != head:
                    raise GitPublishError("Le clone et origin diffèrent. Synchronisez-les avant de publier ; aucun commit existant n’a été envoyé.")
                status = porcelain.status(repo)
                staged = {path.replace(b"\\", b"/") for paths in status.staged.values() for path in paths}
                allowed = {name.encode("utf-8") for name in files}
                if staged - allowed:
                    raise GitPublishError("D’autres fichiers sont déjà préparés pour un commit. Terminez ce travail avant de publier.")
                for key in (b"name", b"email"):
                    try:
                        if not config.get((b"user",), key).strip():
                            raise KeyError(key)
                    except KeyError:
                        raise GitPublishError("Configurez votre nom et votre adresse e-mail Git dans le clone du catalogue.") from None
                porcelain.add(repo, paths=[catalog / name for name in files])
                status = porcelain.status(repo)
                staged = {path.replace(b"\\", b"/") for paths in status.staged.values() for path in paths}
                if not staged or staged - allowed:
                    raise GitPublishError("Aucune modification de publication à enregistrer, ou index Git modifié par un autre programme.")
                commit = porcelain.commit(repo, message=job["message"].encode("utf-8")).decode()
                job = {**job, "commit": commit}
                if save:
                    save(job)
            result = porcelain.push(
                repo, remote, refspecs=[branch + b":" + remote_branch],
                force=False, outstream=io.BytesIO(), errstream=io.BytesIO(), **credentials,
            )
            if any(error is not None for error in (result.ref_status or {}).values()):
                raise GitPublishError("Le serveur a refusé le commit. Vérifiez les droits d’écriture et les règles de la branche.")
            return commit
    except GitPublishError as error:
        error.commit = commit
        raise
    except Exception as error:
        # Les exceptions réseau peuvent contenir l’URL ou le jeton : ne pas les afficher.
        raise GitPublishError(
            f"Envoi Git impossible ({type(error).__name__}). Vérifiez la connexion, origin et les droits du jeton."
            + (" Le commit local est conservé ; vous pouvez réessayer." if commit else ""), commit,
        ) from None
