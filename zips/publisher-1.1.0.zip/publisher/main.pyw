import json
import shutil
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QDragEnterEvent, QDropEvent, QIcon
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from core.api import get_api
from core.catalog.sources import encrypt_token, get_token, load_sources
from core.installer import InstallError
from core.publishing import PackageReport, analyse_zip, publish_zip, sign_zip, zip_from_folder
from core.registry import EXTENSION_ID
from core.signing import (
    KEY_DIR,
    add_trusted_key,
    generate_key,
    key_path,
    list_private_keys,
    public_key_of,
    trusted_keys,
)
from core.theme import apply_theme
from extensions.publisher.git_publish import GitPublishError, catalog_destination, send_catalog

MIN_PASSPHRASE = 12


class GitSendWorker(QThread):
    succeeded = Signal(str)
    failed = Signal(str, object)

    def __init__(self, job, token, api, parent):
        super().__init__(parent)
        self.job, self.token, self.api = job, token, api

    def run(self):
        try:
            commit = send_catalog(self.job, self.token,
                                  save=lambda job: self.api.save_json("pending_git.json", job))
            self.succeeded.emit(commit)
        except GitPublishError as error:
            self.failed.emit(str(error), error.commit)
        finally:
            self.token = ""


def set_hover(widget: QWidget, hover: bool) -> None:
    widget.setProperty("hover", hover)
    widget.style().unpolish(widget)
    widget.style().polish(widget)


def card(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(16, 12, 16, 12)
    heading = QLabel(f"<b>{title}</b>")
    heading.setTextFormat(Qt.RichText)
    layout.addWidget(heading)
    return frame, layout


def muted(text: str = "") -> QLabel:
    label = QLabel(text)
    label.setObjectName("muted")
    label.setWordWrap(True)
    return label


class NewKeyDialog(QDialog):
    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle("Nouvelle clé de signature")
        self.key_id = QLineEdit()
        self.key_id.setPlaceholderText("prenom, en minuscules")
        self.name = QLineEdit()
        self.name.setPlaceholderText("Nom affiché aux utilisateurs")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.confirm = QLineEdit()
        self.confirm.setEchoMode(QLineEdit.Password)
        form = QFormLayout()
        form.addRow("Identifiant", self.key_id)
        form.addRow("Nom", self.name)
        form.addRow(f"Mot de passe ({MIN_PASSPHRASE} caractères min.)", self.password)
        form.addRow("Confirmer", self.confirm)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Annuler")
        cancel.clicked.connect(self.reject)
        ok = QPushButton("Créer")
        ok.setObjectName("primary")
        ok.clicked.connect(self.accept_if_valid)
        buttons.addWidget(cancel)
        buttons.addWidget(ok)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(muted("Le mot de passe n'est enregistré nulle part : sans lui, la clé est inutilisable. Sauvegardez le fichier de clé hors ligne."))
        layout.addLayout(buttons)
        self.setMinimumWidth(460)

    def accept_if_valid(self) -> None:
        if not EXTENSION_ID.fullmatch(self.key_id.text()):
            QMessageBox.warning(self, "Clé", "Identifiant invalide (minuscules, chiffres, _ et -).")
        elif not self.name.text().strip():
            QMessageBox.warning(self, "Clé", "Le nom est obligatoire.")
        elif key_path(self.key_id.text()).exists():
            QMessageBox.warning(self, "Clé", "Cette clé existe déjà.")
        elif len(self.password.text()) < MIN_PASSPHRASE or self.password.text() != self.confirm.text():
            QMessageBox.warning(self, "Clé", f"Mot de passe trop court ({MIN_PASSPHRASE} caractères minimum) ou différent.")
        else:
            self.accept()


class PublisherWindow(QMainWindow):
    def __init__(self, api=None) -> None:
        super().__init__()
        self.api = api if api is not None else get_api("publisher")
        pending = self.api.load_json("pending_git.json")
        self.pending_git = pending if (isinstance(pending, dict) and all(
            isinstance(pending.get(key), str) for key in ("catalog", "zip", "message")
        )) else None
        self.git_busy = False
        self.git_worker = None
        self.token_destination = None
        self.setWindowTitle("Publication")
        self.setAcceptDrops(True)
        self.work = Path(tempfile.mkdtemp(prefix="publisher_"))
        self.zip_path: Path | None = None  # zip analysé (ou zip temporaire fabriqué depuis un dossier)
        self.report: PackageReport | None = None

        root = QWidget()
        root.setObjectName("root")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)
        title = QLabel("Publication")
        title.setObjectName("title")
        layout.addWidget(title)
        self.tabs = QTabWidget()
        publication = QWidget()
        publication_layout = QVBoxLayout(publication)
        publication_layout.addWidget(self.build_extension_card())
        publication_layout.addWidget(self.build_actions_card())
        publication_layout.addStretch(1)
        keys = QWidget()
        keys_layout = QVBoxLayout(keys)
        keys_layout.addWidget(self.build_key_card())
        keys_layout.addWidget(muted("Pour installer sur un autre PC, importez uniquement le fichier de clé publique avec Clé reçue… La clé privée reste sur le poste de publication."))
        keys_layout.addStretch(1)
        for page, label in ((publication, "Publication"), (keys, "Clés de signature")):
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            scroll.setWidget(page)
            self.tabs.addTab(scroll, label)
        layout.addWidget(self.tabs)
        self.setCentralWidget(root)
        self.resize(800, 760)
        self.refresh_keys()
        self.refresh_catalogs()
        if self.pending_git and isinstance(self.pending_git.get("catalog"), str):
            self.catalog_path.setText(self.pending_git["catalog"])

    def closeEvent(self, event) -> None:
        if self.git_busy:
            self.result.setText("Envoi Git en cours. Attendez son résultat avant de fermer.")
            event.ignore()
            return
        shutil.rmtree(self.work, ignore_errors=True)
        super().closeEvent(event)

    #### Clé de signature ####

    def build_key_card(self) -> QFrame:
        frame, layout = card("Clé de signature")
        row = QHBoxLayout()
        self.key_combo = QComboBox()
        self.key_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.key_combo.setMinimumContentsLength(8)
        self.key_combo.currentIndexChanged.connect(self.update_key_status)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText("Mot de passe de la clé (non enregistré)")
        row.addWidget(self.key_combo, 1)
        row.addWidget(self.password, 2)
        layout.addLayout(row)
        self.key_status = muted()
        layout.addWidget(self.key_status)
        buttons = QHBoxLayout()
        for text, slot in (
            ("Générer…", self.generate_key),
            ("Importer…", self.import_key),
            ("Faire confiance…", self.trust_selected),
            ("Clé reçue…", self.trust_received),
        ):
            button = QPushButton(text)
            button.clicked.connect(lambda checked=False, s=slot: s())
            buttons.addWidget(button)
        buttons.addStretch(1)
        layout.addLayout(buttons)
        return frame

    def refresh_keys(self, select: str | None = None) -> None:
        self.key_combo.blockSignals(True)
        self.key_combo.clear()
        for key_id in list_private_keys():
            self.key_combo.addItem(key_id, key_id)
        self.key_combo.blockSignals(False)
        if select and self.key_combo.findData(select) >= 0:
            self.key_combo.setCurrentIndex(self.key_combo.findData(select))
        self.update_key_status()

    def selected_key(self) -> str | None:
        return self.key_combo.currentData()

    def update_key_status(self) -> None:
        key_id = self.selected_key()
        if key_id is None:
            self.key_status.setText("Aucune clé : générez-en une ou importez un fichier de clé privée.")
            return
        key = trusted_keys().get(key_id)
        if key is None:
            self.key_status.setText("Clé absente des clés de confiance de ce lanceur : ses signatures seront refusées tant qu'elle n'y est pas (« Faire confiance… »).")
        elif key.get("revoked") is True:
            self.key_status.setText("Clé révoquée : ses signatures sont refusées.")
        else:
            limit = key.get("ids")
            scope = f" (limitée à : {', '.join(limit)})" if isinstance(limit, list) else ""
            self.key_status.setText(f"Clé de confiance : {key.get('name', key_id)}{scope}.")

    def generate_key(self) -> None:
        dialog = NewKeyDialog(self)
        if not dialog.exec():
            return
        key_id, name = dialog.key_id.text(), dialog.name.text().strip()
        try:
            public = generate_key(key_path(key_id), dialog.password.text().encode("utf-8"))
            (KEY_DIR / f"{key_id}.pub.json").write_text(
                json.dumps({"id": key_id, "name": name, "public": public}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
            )
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Clé", str(e))
            return
        notes = [f"Clé « {key_id} » créée dans {KEY_DIR}.", "Sauvegardez le fichier .key hors ligne."]
        if not trusted_keys():  # premier lanceur : la clé devient la clé de confiance
            add_trusted_key(key_id, name, public)
            notes.append("Ajoutée aux clés de confiance de ce lanceur (core/assets/trusted_keys.json : à commiter).")
        else:
            notes.append(f"Pour qu'un lanceur l'accepte, envoyez {key_id}.pub.json à l'administrateur des clés de confiance.")
        QMessageBox.information(self, "Clé créée", "\n".join(notes))
        self.refresh_keys(key_id)

    def import_key(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Fichier de clé privée", "", "Clé (*.key);;Tous les fichiers (*)")
        if not path:
            return
        source = Path(path)
        key_id = source.stem
        if not EXTENSION_ID.fullmatch(key_id):
            QMessageBox.warning(self, "Clé", "Le nom du fichier (sans .key) doit être un identifiant : minuscules, chiffres, _ et -.")
            return
        if key_path(key_id).exists():
            QMessageBox.warning(self, "Clé", f"La clé « {key_id} » existe déjà.")
            return
        try:
            KEY_DIR.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, key_path(key_id))
        except OSError as e:
            QMessageBox.warning(self, "Clé", str(e))
            return
        self.refresh_keys(key_id)

    def trust_selected(self) -> None:
        key_id = self.selected_key()
        if key_id is None or key_id in trusted_keys():
            QMessageBox.information(self, "Clé", "Choisissez une clé qui n'est pas encore de confiance.")
            return
        try:
            public = public_key_of(key_path(key_id), self.password.text().encode("utf-8"))
        except ValueError as e:
            QMessageBox.warning(self, "Clé", f"{e}\n(saisissez le mot de passe de la clé)")
            return
        self.add_trust(key_id, key_id, public)

    def trust_received(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Clé publique reçue", "", "Clé publique (*.pub.json);;Tous les fichiers (*)")
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
            key_id, name, public = data["id"], data["name"], data["public"]
            if not (isinstance(key_id, str) and EXTENSION_ID.fullmatch(key_id) and isinstance(name, str) and isinstance(public, str)):
                raise ValueError("champs invalides")
        except (OSError, ValueError, KeyError, TypeError) as e:
            QMessageBox.warning(self, "Clé publique", f"Fichier invalide : {e}")
            return
        self.add_trust(key_id, name, public)

    def add_trust(self, key_id: str, name: str, public: str) -> None:
        name, ok = QInputDialog.getText(self, "Faire confiance", "Nom affiché du signataire :", text=name)
        if not ok or not name.strip():
            return
        ids_text, ok = QInputDialog.getText(
            self, "Faire confiance", "Extensions que cette clé peut signer (ids séparés par des virgules ; vide = toutes) :"
        )
        if not ok:
            return
        ids = [i.strip() for i in ids_text.split(",") if i.strip()]
        if any(not EXTENSION_ID.fullmatch(i) for i in ids):
            QMessageBox.warning(self, "Clé", "Identifiant d'extension invalide dans la liste.")
            return
        if not ids and QMessageBox.question(
            self, "Confirmer", f"« {name.strip()} » pourra signer TOUTES les extensions. Confirmer ?"
        ) != QMessageBox.Yes:
            return
        try:
            add_trusted_key(key_id, name.strip(), public, ids or None)
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Clé", str(e))
            return
        QMessageBox.information(self, "Clé", "Ajoutée à core/assets/trusted_keys.json : à commiter avec le lanceur.")
        self.update_key_status()

    #### Extension ####

    def build_extension_card(self) -> QFrame:
        frame, layout = card("Extension")
        self.drop = QFrame()
        self.drop.setObjectName("drop")
        drop_layout = QVBoxLayout(self.drop)
        hint = QLabel("Glissez ici un .zip ou un dossier d'extension")
        hint.setAlignment(Qt.AlignCenter)
        hint.setObjectName("muted")
        drop_layout.addWidget(hint)
        self.drop.setMinimumHeight(70)
        layout.addWidget(self.drop)
        row = QHBoxLayout()
        for text, slot in (("Choisir un zip…", self.choose_zip), ("Choisir un dossier…", self.choose_folder)):
            button = QPushButton(text)
            button.clicked.connect(lambda checked=False, s=slot: s())
            row.addWidget(button)
        row.addStretch(1)
        layout.addLayout(row)
        self.info = QLabel()
        self.info.setTextFormat(Qt.RichText)
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        return frame

    def choose_zip(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Zip d'extension", "", "Zip (*.zip)")
        if path:
            self.load(Path(path))

    def choose_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Dossier d'extension")
        if path:
            self.load(Path(path))

    def load(self, path: Path) -> None:
        self.zip_path = None
        self.report = None
        try:
            if path.is_dir():
                path = zip_from_folder(path, self.work / "pack.zip")
            self.report = analyse_zip(path)
            self.zip_path = path
        except (InstallError, OSError) as e:
            self.info.setText(f"<span style='color:#d9534f'>Zip inutilisable : {e}</span>")
        self.show_report()

    def show_report(self) -> None:
        report = self.report
        if report is None:
            self.update_actions()
            return
        lines = [f"<b>{report.name}</b> {report.version}" + (f" · par {report.author}" if report.author else "") + f" · id : {report.id}"]
        lines.append("Paquets Python demandés : oui" if report.has_requirements else "Aucun paquet Python demandé")
        lines.append(f"Signé par {report.signer}" if report.signer else "Non signé")
        lines += [f"<span style='color:#d9534f'>⚠ {problem}</span>" for problem in report.problems]
        self.info.setText("<br>".join(lines))
        self.update_actions()

    #### Actions ####

    def build_actions_card(self) -> QFrame:
        frame, layout = card("Signer et publier")
        self.sign_button = QPushButton("Signer le zip…")
        self.sign_button.clicked.connect(self.sign_only)
        layout.addWidget(self.sign_button)
        layout.addSpacing(6)
        layout.addWidget(QLabel("Catalogue Git local ou dossier de destination"))
        self.catalog_combo = QComboBox()
        self.catalog_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.catalog_combo.setMinimumContentsLength(20)
        self.catalog_combo.currentIndexChanged.connect(self.select_catalog)
        layout.addWidget(self.catalog_combo)
        catalog_row = QHBoxLayout()
        self.catalog_path = QLineEdit()
        self.catalog_path.setPlaceholderText(r"Ex. C:\Users\vous\Documents\mon-catalogue")
        self.catalog_path.setClearButtonEnabled(True)
        browse = QPushButton("Parcourir…")
        browse.clicked.connect(self.browse_catalog)
        catalog_row.addWidget(self.catalog_path, 1)
        catalog_row.addWidget(browse)
        layout.addLayout(catalog_row)
        layout.addWidget(muted("Choisissez la racine du clone Git local contenant index.json et le dossier zips."))
        self.notes = QLineEdit()
        self.notes.setPlaceholderText("Nouveautés de cette version (facultatif)")
        layout.addWidget(self.notes)
        self.send_git = QCheckBox("Créer le commit et envoyer au dépôt Git")
        self.send_git.toggled.connect(self.update_actions)
        layout.addWidget(self.send_git)
        self.git_token = QLineEdit()
        self.git_token.setEchoMode(QLineEdit.Password)
        self.git_token.setPlaceholderText("Jeton Git pour un dépôt privé ou l’envoi HTTPS (droit d’écriture)")
        layout.addWidget(self.git_token)
        self.remember_token = QCheckBox("Mémoriser le jeton pour ce dépôt (chiffré pour ce compte Windows)")
        layout.addWidget(self.remember_token)
        self.catalog_path.textChanged.connect(self.update_git_token)
        self.publish_button = QPushButton("Signer et publier")
        self.publish_button.setObjectName("primary")
        self.publish_button.clicked.connect(self.publish)
        layout.addWidget(self.publish_button)
        self.retry_button = QPushButton("Reprendre l’envoi Git")
        self.retry_button.clicked.connect(self.start_git_send)
        layout.addWidget(self.retry_button)
        self.result = muted()
        self.result.setTextFormat(Qt.PlainText)
        if self.pending_git:
            self.result.setText("Un envoi Git est en attente. Cliquez sur Reprendre l’envoi Git.")
        layout.addWidget(self.result)
        self.update_actions()
        return frame

    def refresh_catalogs(self) -> None:
        self.catalog_combo.clear()
        for source in load_sources():
            if source["type"] == "folder" and source.get("location"):
                self.catalog_combo.addItem(f"{source['name']} · {source['location']}", source["location"])
        self.catalog_combo.addItem("Autre clone Git ou dossier…", None)
        self.select_catalog()

    def select_catalog(self) -> None:
        catalog = self.catalog_combo.currentData()
        if catalog:
            self.catalog_path.setText(str(catalog))

    def browse_catalog(self) -> None:
        start = self.catalog_path.text().strip()
        catalog = QFileDialog.getExistingDirectory(self, "Clone Git local ou dossier du catalogue", start)
        if catalog:
            self.catalog_path.setText(catalog)

    def selected_catalog(self) -> Path | None:
        value = self.catalog_path.text().strip()
        if not value:
            self.browse_catalog()
            value = self.catalog_path.text().strip()
        return Path(value) if value else None

    def update_actions(self) -> None:
        ready = self.report is not None and not self.report.problems and self.zip_path is not None
        self.sign_button.setEnabled(ready)
        self.publish_button.setEnabled(ready and self.pending_git is None and not self.git_busy)
        self.publish_button.setText("Signer, publier et envoyer" if self.send_git.isChecked() else "Signer et publier localement")
        self.retry_button.setEnabled(self.pending_git is not None and not self.git_busy)

    def update_git_token(self) -> None:
        try:
            destination = catalog_destination(self.catalog_path.text().strip())
        except GitPublishError:
            destination = None
        if destination == self.token_destination:
            return
        self.token_destination = destination
        settings = self.api.load_settings()
        tokens = settings.get("git_tokens", {})
        encrypted = tokens.get(destination) if isinstance(tokens, dict) else None
        self.git_token.setText(get_token({"token": encrypted}) if encrypted else "")
        self.remember_token.setChecked(bool(encrypted))

    def credentials(self) -> tuple[str, Path, bytes] | None:
        key_id = self.selected_key()
        if key_id is None:
            QMessageBox.warning(self, "Clé", "Aucune clé de signature.")
            return None
        if not self.password.text():
            QMessageBox.warning(self, "Clé", "Saisissez le mot de passe de la clé.")
            return None
        key = trusted_keys().get(key_id)
        if key is None or key.get("revoked") is True:
            answer = QMessageBox.question(
                self,
                "Clé non reconnue",
                "Cette clé n'est pas dans les clés de confiance de ce lanceur : les paquets signés seront refusés à l'installation. Continuer ?",
            )
            if answer != QMessageBox.Yes:
                return None
        return key_id, key_path(key_id), self.password.text().encode("utf-8")

    def sign_only(self) -> None:
        creds = self.credentials()
        if creds is None or self.report is None or self.zip_path is None:
            return
        key_id, path, passphrase = creds
        default = f"{self.report.id}-{self.report.version}.zip"
        target, _ = QFileDialog.getSaveFileName(self, "Enregistrer le zip signé", default, "Zip (*.zip)")
        if not target:
            return
        try:
            signed = sign_zip(self.zip_path, Path(target), path, key_id, passphrase)
        except (InstallError, ValueError, OSError) as e:
            QMessageBox.warning(self, "Signature impossible", str(e))
            return
        finally:
            self.password.clear()
        self.result.setText(f"Signé par {signed.signer} : {target}")

    def publish(self) -> None:
        if self.pending_git is not None or self.git_busy:
            return
        catalog = self.selected_catalog()
        if catalog is None:
            return
        creds = self.credentials()
        if creds is None or self.report is None or self.zip_path is None:
            return
        key_id, path, passphrase = creds
        signed_path = self.work / "signed.zip"
        try:
            signed = sign_zip(self.zip_path, signed_path, path, key_id, passphrase)
            entry = publish_zip(catalog, signed_path, self.notes.text().strip())
        except (InstallError, ValueError, OSError) as e:
            QMessageBox.warning(self, "Publication impossible", str(e))
            return
        finally:
            self.password.clear()
        self.result.setText(f"Préparé localement : {entry['name']} {entry['version']} (signé par {signed.signer}) dans {catalog}")
        if self.send_git.isChecked():
            self.pending_git = {"catalog": str(catalog.resolve()), "zip": entry["zip"],
                                "message": f"Publier {entry['name']} {entry['version']}", "commit": None}
            try:
                self.api.save_json("pending_git.json", self.pending_git)
            except (OSError, ValueError):
                self.result.setText("Catalogue préparé localement. Impossible de mémoriser l’envoi Git ; aucun envoi effectué.")
                self.update_actions()
                return
            self.start_git_send()

    def start_git_send(self) -> None:
        if not self.pending_git or self.git_busy:
            return
        token = self.git_token.text().strip()
        try:
            destination = catalog_destination(self.pending_git["catalog"])
            if self.token_destination is not None and destination != self.token_destination:
                self.result.setText("Le dépôt a changé. Sélectionnez le catalogue de l’envoi en attente et renseignez son jeton.")
                return
            if self.pending_git.get("remote") and self.pending_git["remote"] != destination:
                self.result.setText("L’adresse origin de cet envoi a changé. Rétablissez sa destination avant de reprendre.")
                return
            self.pending_git["remote"] = destination
            settings = self.api.load_settings()
            tokens = settings.get("git_tokens", {})
            tokens = dict(tokens) if isinstance(tokens, dict) else {}
            if self.remember_token.isChecked() and token:
                tokens[destination] = encrypt_token(token)
            else:
                tokens.pop(destination, None)
            settings["git_tokens"] = tokens
            self.api.save_settings(settings)
            self.api.save_json("pending_git.json", self.pending_git)
        except (OSError, ValueError) as error:
            self.result.setText(str(error) if isinstance(error, GitPublishError) else "Impossible d’enregistrer les réglages de l’envoi. Aucun envoi effectué.")
            self.update_actions()
            return
        self.git_busy = True
        self.result.setText("Création du commit et envoi au dépôt Git en cours…")
        self.centralWidget().setEnabled(False)
        self.git_worker = GitSendWorker(dict(self.pending_git), token, self.api, self)
        self.git_worker.succeeded.connect(self.git_succeeded)
        self.git_worker.failed.connect(self.git_failed)
        self.git_worker.finished.connect(self.git_finished)
        self.git_worker.start()

    def git_succeeded(self, commit) -> None:
        try:
            self.api.save_json("pending_git.json", None)
            self.pending_git = None
        except (OSError, ValueError):
            self.pending_git["commit"] = commit
            self.result.setText(f"Commit {commit[:8]} envoyé. Le suivi local n’a pas pu être effacé ; une reprise vérifiera cet envoi.")
            return
        self.result.setText(f"Publication envoyée au dépôt Git · commit {commit[:8]}.")

    def git_failed(self, message, commit) -> None:
        self.pending_git["commit"] = commit
        try:
            self.api.save_json("pending_git.json", self.pending_git)
        except (OSError, ValueError):
            message += " Le suivi de reprise n’a pas pu être enregistré ; gardez cette fenêtre ouverte."
        self.result.setText("Catalogue conservé localement. " + message + "\nUtilisez Reprendre l’envoi Git après correction.")

    def git_finished(self) -> None:
        self.git_busy = False
        self.git_worker.deleteLater()
        self.git_worker = None
        if not self.remember_token.isChecked():
            self.git_token.clear()
        self.centralWidget().setEnabled(True)
        self.update_actions()

    #### Glisser-déposer ####

    @staticmethod
    def dropped_path(event) -> Path | None:
        for url in event.mimeData().urls():
            if url.isLocalFile():
                path = Path(url.toLocalFile())
                if path.is_dir() or path.suffix.lower() == ".zip":
                    return path
        return None

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if self.dropped_path(event):
            set_hover(self.drop, True)
            event.acceptProposedAction()

    def dragLeaveEvent(self, event) -> None:
        set_hover(self.drop, False)

    def dropEvent(self, event: QDropEvent) -> None:
        set_hover(self.drop, False)
        path = self.dropped_path(event)
        if path:
            event.acceptProposedAction()
            self.load(path)


def main() -> int:
    app = QApplication(sys.argv)
    apply_theme(app)
    app.setWindowIcon(QIcon(str(Path(__file__).parent / "icon.svg")))
    window = PublisherWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
