# Le Tableau — édition Tools Launcher et Python autonome

Tableau de tâches Windows : responsables, catégories, échéances, glisser-déposer,
liens vers fichiers et dossiers, corbeille, sauvegardes et partage sur NAS.
Cette première édition Catalogue reprend les fonctions de Le Tableau 1.4.1.

La configuration utilise cinq onglets sans barre de défilement : Tableau, Équipe,
Catégories, Sauvegardes et Ce PC. Les tâches peuvent se répéter à date fixe ou
après leur achèvement. Pendant un glisser-déposer, une zone de corbeille apparaît
en bas du tableau. Le vidage définitif de la corbeille demande confirmation.

## Avec Tools Launcher

Glisser `le_tableau.zip` dans **Launcher > Catalogue…**, vérifier le résumé,
puis confirmer l'installation. Ouvrir **Outils > Le Tableau**.
Ce paquet n'est pas signé : l'avertissement **Provenance NON vérifiée** est
attendu. La signature sera ajoutée à la publication par l'outil dédié du lanceur.
Le thème du lanceur est suivi en direct. Les mises à jour de cette édition
passent par le Catalogue ; elle n'installe pas les exécutables de l'édition Windows.

## Sans le lanceur

Extraire le ZIP dans un dossier `le_tableau`, puis ouvrir **Lancer Le Tableau.cmd**.
Dans les sources de développement, ouvrir ce même fichier dans `projects/le_tableau/`.
Il réutilise l'environnement Python du dépôt : aucune installation supplémentaire
n'est nécessaire sur le PC de développement. Fermer la fenêtre du tableau termine
l'essai. La console reste ouverte pendant l'utilisation et montre les erreurs utiles
à transmettre à l'assistant.

Pour itérer, ouvrir `projects/le_tableau/` avec l'assistant, modifier les sources,
fermer puis relancer l'outil. Il n'est pas nécessaire de reconstruire le ZIP à chaque
modification. Créer un tableau dans un dossier d'essai pour préserver le tableau réel.

Sur un autre PC, Python avec PySide6 6.12.0 reste nécessaire. Demander à l'assistant
de préparer un environnement `.venv` dans le dossier extrait. Commandes de préparation
depuis ce dossier, une seule fois (connexion Internet nécessaire) :

```powershell
py -m venv .venv
.venv/Scripts/python.exe -m pip install PySide6==6.12.0
```

Le lanceur cherche d'abord `.venv` dans le dossier de l'outil, puis l'environnement
du dépôt de développement, l'environnement Python activé, puis Python installé.
Si Python ou PySide6 manque, il affiche les instructions et n'installe rien automatiquement.
Le thème autonome est sombre ; cette édition ne dépend pas de Tools Launcher.
L'archive contient les sources Python, aucun EXE.

## Données

Au premier lancement, choisir **Ouvrir un tableau existant** et le dossier actuel
du tableau partagé, ou créer un nouveau tableau dans un dossier vide.
Les anciens tableaux restent compatibles. Aucun déplacement ni conversion automatique.

Les tâches, leurs liens et sauvegardes restent dans le dossier choisi, éventuellement
sur un partage SMB direct. Le stockage conserve ses verrous, contrôles de conflits
et sauvegardes. Une copie synchronisée par OneDrive ou Dropbox ne remplace pas SMB.
Les documents liés restent à leur emplacement ; seuls leurs chemins sont enregistrés.
Sous Windows, l’ouverture utilise l’association native du fichier ou du dossier.
En cas d’échec, le message conserve le numéro d’erreur Windows utile au diagnostic.

Les préférences de cette édition sont dans `data/settings.json` à côté du code :
dernier tableau, profil par tableau, durée des messages et rappels.
Le journal d'erreurs est `data/application.log` ; le shim autonome utilise aussi
`data/app.log`. Ne pas distribuer ce dossier personnel et le conserver lors d'une mise à jour.
Le Catalogue préserve le dossier `data/`.

Le lancement historique `run.py` / l'EXE conserve ses préférences Windows.
Les nouvelles préférences sont indépendantes : sélectionner à nouveau le tableau
et son prénom au premier lancement de l'édition Catalogue.

## Dépendance et limites

PySide6==6.12.0, déjà utilisé par le lanceur ; aucun autre paquet ajouté.
En autonome, les notifications et badges du lanceur sont indisponibles.
Les confirmations et rappels existants restent visibles dans la fenêtre du tableau.
Les couleurs des personnes et des colonnes restent des repères métier.

L'adaptation passe uniquement par `get_api`, l'API des préférences et `apply_theme`.
La surcharge de disposition lit les couleurs des widgets Qt stylés et suit le
changement de feuille du lanceur. Aucun fichier du noyau n'est modifié.
Le shim fourni est la copie exacte de celui du skill
`new-extension-2026-10-30.zip` : jetons complets (chiffres compris), contrôle des
chemins JSON et fichiers temporaires distincts par processus et thread.
Une lecture JSON hors de `data/` renvoie `None` et journalise l'erreur ; une
écriture hors de ce dossier lève `ValueError`.
Le Tableau sérialise les sauvegardes d'un même objet de préférences pour éviter
les refus de remplacement Windows entre threads. Ce verrou local ne remplace
pas le verrou SMB du tableau partagé et ne coordonne pas plusieurs processus.

La version de l'extension suit celle de l'application (1.4.1), plutôt que de
réinitialiser la numérotation d'une application déjà publiée.
