from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton


class Toast(QFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.setObjectName("toast")
        self.setMaximumWidth(460)
        row = QHBoxLayout(self)
        row.setContentsMargins(16, 12, 8, 12)
        self.text = QLabel()
        self.text.setTextFormat(Qt.TextFormat.PlainText)
        self.text.setWordWrap(True)
        row.addWidget(self.text, 1)
        close = QPushButton("×")
        close.setObjectName("quiet")
        close.setFixedWidth(30)
        close.clicked.connect(self.hide)
        row.addWidget(close)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.hide)
        self.hide()

    def notify(self, text, seconds):
        self.text.setText(text)
        self.setFixedWidth(min(460, self.parentWidget().width() - 40))
        self.adjustSize()
        self.place()
        self.show()
        self.raise_()
        self.timer.start(seconds * 1000)

    def place(self):
        self.move(self.parentWidget().width() - self.width() - 24,
                  self.parentWidget().height() - self.height() - 46)
