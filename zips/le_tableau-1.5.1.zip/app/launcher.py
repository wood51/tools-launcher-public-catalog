"""Préférences locales de l'édition Catalogue, sans accès au tableau partagé."""
from threading import RLock


class ApiSettings:
    def __init__(self, api):
        self.api = api
        self.data = api.load_settings()
        self.lock = RLock()

    def value(self, key, default=None, type=None):
        value = self.data.get(key, default)
        if type is not None:
            if type is bool:
                return value if isinstance(value, bool) else default
            if type is str:
                return value if isinstance(value, str) else default
            try:
                return type(value)
            except (ValueError, TypeError, OverflowError):
                return default
        return value

    def setValue(self, key, value):
        with self.lock:
            self.data[key] = value
            self.api.save_settings(self.data)

    def remove(self, key):
        with self.lock:
            if key in self.data:
                del self.data[key]
                self.api.save_settings(self.data)
