"""Manual GitHub updates. This module also runs in the separate installer."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, HTTPRedirectHandler, build_opener
import zipfile

from .version import VERSION, RELEASE_REPOSITORY

ASSET_NAME = "LeTableau-Windows.zip"
MAX_DOWNLOAD = 350 * 1024 * 1024
MAX_UNPACKED = 900 * 1024 * 1024
ROOT_FILES = {"LeTableau.exe", "LeTableau-MiseAJour.exe", "version.json",
              "Guide-utilisateur-Le-Tableau.pdf", "LIRE-MOI.txt", "NOTICE.md"}


class UpdateError(Exception):
    pass


def version_tuple(value):
    if not isinstance(value, str) or not re.fullmatch(r"v?\d+\.\d+\.\d+", value):
        raise UpdateError("Le numéro de version publié est incorrect.")
    return tuple(int(part) for part in value.removeprefix("v").split("."))


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def github_url(url):
    parsed = urlparse(url)
    if (parsed.scheme != "https" or parsed.username or parsed.password or
            parsed.port not in (None, 443) or parsed.hostname not in {
                "github.com", "api.github.com", "release-assets.githubusercontent.com",
                "objects.githubusercontent.com"}):
        raise UpdateError("Le lien de téléchargement n’est pas un lien GitHub autorisé.")
    return url


class GitHubRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        github_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def request(url, accept):
    req = Request(github_url(url), headers={"User-Agent": "LeTableau/" + VERSION,
                  "Accept": accept, "X-GitHub-Api-Version": "2022-11-28"})
    return build_opener(GitHubRedirect()).open(req, timeout=25)


@dataclass(frozen=True)
class Release:
    version: str
    url: str
    digest: str
    size: int


def check_release(current=VERSION):
    try:
        with request(f"https://api.github.com/repos/{RELEASE_REPOSITORY}/releases/latest",
                     "application/vnd.github+json") as response:
            payload = response.read(1024 * 1024 + 1)
        if len(payload) > 1024 * 1024:
            raise UpdateError("La réponse du serveur est trop volumineuse.")
        data = json.loads(payload)
        latest = data["tag_name"].removeprefix("v")
        if data.get("draft") or data.get("prerelease"):
            raise UpdateError("Cette version n’est pas une version stable.")
        if version_tuple(latest) <= version_tuple(current):
            return None
        assets = [a for a in data["assets"] if a["name"] == ASSET_NAME]
        if len(assets) != 1:
            raise UpdateError("Le fichier Windows n’est pas encore disponible. Réessayez plus tard.")
        asset = assets[0]
        digest = asset.get("digest", "") or ""
        if not re.fullmatch(r"sha256:[a-f0-9]{64}", digest):
            raise UpdateError("La vérification du fichier n’est pas encore disponible. Réessayez plus tard.")
        url = github_url(asset["browser_download_url"])
        if not url.startswith(f"https://github.com/{RELEASE_REPOSITORY}/releases/download/"):
            raise UpdateError("Ce fichier ne provient pas du dépôt de l’application.")
        size = asset["size"]
        if type(size) is not int or not 0 < size <= MAX_DOWNLOAD:
            raise UpdateError("La taille du fichier publié est incorrecte.")
        return Release(latest, url, digest.split(":")[1], size)
    except HTTPError as exc:
        if exc.code == 404:
            raise UpdateError("Aucune version n’est publiée pour le moment.") from exc
        if exc.code in (403, 429):
            raise UpdateError("GitHub limite les vérifications pour le moment. Réessayez plus tard.") from exc
        raise UpdateError("Le serveur de mises à jour est indisponible. Réessayez plus tard.") from exc
    except (OSError, URLError) as exc:
        raise UpdateError("Connexion impossible. Vérifiez l’accès à Internet puis réessayez.") from exc
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise UpdateError("Les informations de mise à jour sont incomplètes.") from exc


def package_path(name):
    # Also reject Windows alternate streams, reserved names and case collisions.
    if "\\" in name or ":" in name:
        raise UpdateError("Le paquet contient un chemin incorrect.")
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or any(p in (".", "..") for p in path.parts):
        raise UpdateError("Le paquet contient un chemin incorrect.")
    for part in path.parts:
        if part.endswith((".", " ")) or re.fullmatch(r"(?i)(con|prn|aux|nul|com\d|lpt\d)(\..*)?", part):
            raise UpdateError("Le paquet contient un nom de fichier incorrect.")
    if len(path.parts) == 1 and path.name not in ROOT_FILES:
        raise UpdateError("Le paquet contient un fichier inattendu.")
    if len(path.parts) > 1 and path.parts[0] not in ("_internal", "Licences"):
        raise UpdateError("Le paquet contient un dossier inattendu.")
    return path


def validate_package(folder, expected):
    folder = Path(folder).resolve()
    try:
        data = json.loads((folder / "version.json").read_text(encoding="utf-8"))
        if data["application"] != "LeTableau" or data["version"] != expected:
            raise UpdateError("Le fichier reçu ne correspond pas à la version annoncée.")
        version_tuple(data["version"])
        files = data["files"]
        if not isinstance(files, dict) or not files or len(files) > 10000:
            raise UpdateError("La liste des fichiers est incorrecte.")
        required = {"LeTableau.exe", "LeTableau-MiseAJour.exe", "_internal/python314.dll"}
        if not required.issubset(files):
            raise UpdateError("Le paquet est incomplet.")
        actual = {p.relative_to(folder).as_posix() for p in folder.rglob("*") if p.is_file()}
        if actual != set(files) | {"version.json"}:
            raise UpdateError("Les fichiers reçus ne correspondent pas à la liste annoncée.")
        seen = set()
        for name, digest in files.items():
            relative = package_path(name)
            if name.lower() in seen or not re.fullmatch(r"[a-f0-9]{64}", digest):
                raise UpdateError("La liste des fichiers est incorrecte.")
            seen.add(name.lower())
            path = folder.joinpath(*relative.parts)
            if path.is_symlink() or sha256(path) != digest:
                raise UpdateError("Un fichier reçu est endommagé. L’application actuelle est conservée.")
        return sorted(files) + ["version.json"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise UpdateError("Le paquet de mise à jour est illisible ou incomplet.") from exc


def unpack_package(archive, destination, expected):
    destination = Path(destination)
    total = 0
    seen = set()
    try:
        with zipfile.ZipFile(archive) as zipped:
            if len(zipped.infolist()) > 10000:
                raise UpdateError("Le paquet contient trop de fichiers.")
            for entry in zipped.infolist():
                if entry.is_dir():
                    continue
                parts = PurePosixPath(entry.filename).parts
                if len(parts) < 2 or parts[0] != "LeTableau":
                    raise UpdateError("Le paquet Windows est incorrect.")
                relative = package_path("/".join(parts[1:]))
                key = relative.as_posix().lower()
                if key in seen or stat.S_ISLNK(entry.external_attr >> 16):
                    raise UpdateError("Le paquet contient un fichier incorrect.")
                seen.add(key)
                total += entry.file_size
                if total > MAX_UNPACKED:
                    raise UpdateError("Le paquet décompressé est trop volumineux.")
                target = destination.joinpath(*relative.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with zipped.open(entry) as src, target.open("xb") as dst:
                    shutil.copyfileobj(src, dst)
        validate_package(destination, expected)
        return destination
    except (zipfile.BadZipFile, OSError) as exc:
        raise UpdateError("Le fichier reçu est endommagé ou l’espace disque est insuffisant.") from exc


def updates_root():
    return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "LeTableau" / "MisesAJour"


def prepare_release(release, progress=lambda done, total: None):
    root = updates_root()
    root.mkdir(parents=True, exist_ok=True)
    workspace = Path(tempfile.mkdtemp(prefix="installation-", dir=root))
    archive = workspace / "mise-a-jour.zip"
    try:
        count = 0
        digest = hashlib.sha256()
        start = time.monotonic()
        with request(release.url, "application/octet-stream") as response, archive.open("xb") as output:
            while block := response.read(256 * 1024):
                count += len(block)
                if count > release.size or count > MAX_DOWNLOAD or time.monotonic() - start > 600:
                    raise UpdateError("Le téléchargement est incomplet. Réessayez.")
                output.write(block)
                digest.update(block)
                progress(count, release.size)
        if count != release.size or digest.hexdigest() != release.digest:
            raise UpdateError("Le fichier reçu est endommagé. L’application actuelle est conservée.")
        progress(count, release.size)
        return unpack_package(archive, workspace / "LeTableau", release.version)
    except (OSError, URLError) as exc:
        raise UpdateError("Téléchargement impossible. Vérifiez Internet et l’espace disponible sur ce PC.") from exc


def installation_folder():
    if not getattr(sys, "frozen", False):
        raise UpdateError("La mise à jour s’installe depuis la version exécutable du logiciel.")
    folder = Path(sys.executable).resolve().parent
    if os.name == "nt":
        import ctypes
        if ctypes.windll.kernel32.GetDriveTypeW(str(folder.anchor)) == 4:
            raise UpdateError("Copiez d’abord le logiciel sur ce PC. Seul le tableau commun doit être sur le NAS.")
    if not (folder / "_internal").is_dir():
        raise UpdateError("Le dossier complet du logiciel est nécessaire pour installer la mise à jour.")
    try:
        with tempfile.TemporaryFile(dir=folder):
            pass
    except OSError as exc:
        raise UpdateError("Ce dossier n’est pas modifiable. Placez le logiciel dans un dossier personnel, par exemple le Bureau.") from exc
    return folder


def launch_installer(package, version, folder):
    workspace = Path(package).parent
    plan = workspace / "installation.json"
    plan.write_text(json.dumps({"target": str(folder), "package": str(package), "version": version,
                               "parent": os.getpid()}, ensure_ascii=False), encoding="utf-8")
    subprocess.Popen([str(Path(package) / "LeTableau-MiseAJour.exe"), "--job", str(plan)],
                     cwd=workspace, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    start = time.monotonic()
    while not (workspace / "pret").exists():
        if (workspace / "erreur.txt").exists():
            raise UpdateError((workspace / "erreur.txt").read_text(encoding="utf-8"))
        if time.monotonic() - start > 20:
            raise UpdateError("Le programme de mise à jour n’a pas démarré. L’application reste ouverte.")
        time.sleep(.1)


def is_installing(folder):
    path = Path(folder) / ".mise-a-jour.lock"
    if not path.exists() or os.name != "nt":
        return False
    import msvcrt
    try:
        with path.open("r+b") as lock:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
        return False
    except OSError:
        return True


def apply_package(package, target, version, backup, replace=os.replace):
    """Replace only distribution files; journal and restore every touched file on failure."""
    package, target, backup = Path(package).resolve(), Path(target).resolve(), Path(backup).resolve()
    if package == target or target in package.parents or package in target.parents:
        raise UpdateError("Le dossier de préparation doit être séparé du logiciel.")
    if not (target / "LeTableau.exe").is_file() or not (target / "_internal").is_dir():
        raise UpdateError("Le dossier du logiciel est incorrect.")
    names = validate_package(package, version)
    # Check ALL destination paths before changing anything (junctions included).
    for name in names:
        dest = target.joinpath(*package_path(name).parts)
        if not dest.resolve().is_relative_to(target):
            raise UpdateError("Un fichier du logiciel pointe vers un autre dossier.")
        for parent in (dest, *dest.parents):
            if parent == target:
                break
            if parent.is_symlink() or (hasattr(parent, "is_junction") and parent.is_junction()):
                raise UpdateError("Un fichier du logiciel est un lien vers un autre dossier.")
    changed = []
    backup.mkdir(parents=True, exist_ok=False)
    try:
        for name in names:
            source, dest, saved = package / name, target / name, backup / name
            if dest.is_file() and sha256(dest) == sha256(source):
                continue
            existed = dest.exists()
            if existed:
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, saved)
            dest.parent.mkdir(parents=True, exist_ok=True)
            pending = dest.with_name(dest.name + ".mise-a-jour")
            shutil.copy2(source, pending)
            try:
                deadline = time.monotonic() + 8
                while True:
                    try:
                        replace(pending, dest)
                        break
                    except PermissionError:
                        if time.monotonic() >= deadline:
                            raise
                        time.sleep(.2)
                changed.append((dest, saved if existed else None))
            finally:
                pending.unlink(missing_ok=True)
    except Exception as exc:
        failures = []
        for dest, saved in reversed(changed):
            try:
                if saved:
                    os.replace(saved, dest)
                else:
                    dest.unlink(missing_ok=True)
            except OSError:
                failures.append(str(dest))
        if failures:
            raise UpdateError(f"La restauration est incomplète. Fermez les autres fenêtres du logiciel. La copie précédente est conservée ici : {backup}") from exc
        raise UpdateError("La mise à jour n’a pas pu être installée. La version précédente a été conservée. Fermez les autres fenêtres du logiciel et réessayez.") from exc
