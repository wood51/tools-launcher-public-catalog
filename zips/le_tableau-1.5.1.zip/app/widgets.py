from __future__ import annotations
import json
from datetime import date
from PySide6.QtCore import Qt, Signal, QMimeData, QSize, QPoint, QPointF, QRectF, QTimer, QEvent
from PySide6.QtGui import QDrag, QColor, QPainter, QIcon, QPixmap, QPolygonF, QPen, QPainterPath, QPalette, QCursor
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QVBoxLayout, QHBoxLayout, QListWidget,
                              QListWidgetItem, QAbstractItemView, QMenu, QPushButton, QStyle, QToolButton,
                              QWidget, QGraphicsDropShadowEffect)
from .storage import STATUS_LABELS
from .colors import owner_color, badge_style

MONTHS = ["", "janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]
MIME = "application/x-letableau-task"


def pretty_date(value):
    if not value:
        return "Sans date"
    d = date.fromisoformat(value)
    return f"{d.day} {MONTHS[d.month]}" + (f" {d.year}" if d.year != date.today().year else "")


def due_label(task):
    if task["status"] == "done":
        return "Terminée"
    if not task["due"]:
        return "Sans date"
    delta = (date.fromisoformat(task["due"]) - date.today()).days
    if delta < 0:
        return f"{abs(delta)} j de retard"
    if delta == 0:
        return "Aujourd’hui"
    if delta == 1:
        return "Demain"
    return pretty_date(task["due"])


def board_icon(size=64):
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#4f8cff"))
    p.drawRoundedRect(0, 0, size, size, size*.23, size*.23)
    for x, height, color in [(0.23, .44, "#ffffff"), (.46, .62, "#d5e5ff"), (.69, .30, "#a9caff")]:
        p.setBrush(QColor(color))
        p.drawRoundedRect(int(size*x),int(size*.2),int(size*.12),int(size*height),size*.035,size*.035)
    p.end()
    return QIcon(pix)


def warning_icon(size=24):
    """Draw the warning triangle directly, independent of installed emoji fonts."""
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.scale(size/24, size/24)
    painter.setPen(QPen(QColor("#ffe0a1"), 1))
    painter.setBrush(QColor("#ffc04d"))
    painter.drawPolygon(QPolygonF([QPointF(12,2),QPointF(23,22),QPointF(1,22)]))
    painter.setPen(QPen(QColor("#412600"), 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    painter.drawLine(QPointF(12,9), QPointF(12,14))
    painter.drawPoint(QPointF(12,18))
    painter.end()
    return QIcon(pix)


def plus_icon(size=18):
    pix=QPixmap(size,size)
    pix.fill(Qt.GlobalColor.transparent)
    painter=QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    pen=QPen(QColor("#b7d0ff"),1.7)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    painter.setPen(pen)
    centre=size/2
    painter.drawLine(QPointF(centre,4),QPointF(centre,size-4))
    painter.drawLine(QPointF(4,centre),QPointF(size-4,centre))
    painter.end()
    return QIcon(pix)


def trash_icon_pixmap(size=72):
    pix=QPixmap(size,size)
    pix.fill(Qt.GlobalColor.transparent)
    painter=QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.scale(size/48,size/48)
    pen=QPen(QColor("#e86570"),2.1,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(QColor(232,101,112,18))
    body=QPainterPath()
    body.moveTo(11,18)
    body.lineTo(14,42)
    body.quadTo(14.5,45,18,45)
    body.lineTo(30,45)
    body.quadTo(33.5,45,34,42)
    body.lineTo(37,18)
    painter.drawPath(body)
    painter.drawLine(QPointF(20,24),QPointF(21,38))
    painter.drawLine(QPointF(28,24),QPointF(27,38))
    painter.save()
    painter.translate(9,14)
    painter.drawRoundedRect(QRectF(0,0,30,4),2,2)
    painter.drawRoundedRect(QRectF(10,-6,10,6),2,2)
    painter.restore()
    painter.end()
    return pix


class DragCardPreview(QWidget):
    """Aperçu indépendant de l'image native, recolorable pendant le glissement Windows."""
    def __init__(self,card):
        super().__init__(None,Qt.WindowType.ToolTip|Qt.WindowType.FramelessWindowHint|
                         Qt.WindowType.WindowTransparentForInput|Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.image=card.grab()
        self.margin=14
        self.danger=False
        probe=QPushButton()
        probe.setObjectName("primary")
        probe.ensurePolished()
        self.accent=probe.palette().color(QPalette.ColorRole.Button)
        probe.deleteLater()
        self.resize(card.width()+self.margin*2,card.height()+self.margin*2)
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.follow_cursor)
        self.timer.start(16)
        self.follow_cursor()
        QApplication.instance().installEventFilter(self)

    def eventFilter(self,watched,event):
        if event.type() in (QEvent.Type.DragEnter,QEvent.Type.DragMove,QEvent.Type.DragLeave):
            self.follow_cursor()
            self.repaint()
        return False

    def follow_cursor(self):
        self.move(QCursor.pos()-QPoint(30+self.margin,20+self.margin))

    def set_danger(self,on):
        self.danger=on
        self.follow_cursor()
        self.repaint()

    def paintEvent(self,event):
        p=QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        color=QColor("#e86570") if self.danger else QColor(self.accent)
        rect=QRectF(self.rect()).adjusted(self.margin,self.margin,-self.margin,-self.margin)
        p.setBrush(Qt.BrushStyle.NoBrush)
        for spread in range(10,0,-1):
            color.setAlpha(5+(10-spread)*2)
            p.setPen(QPen(color,2))
            p.drawRoundedRect(rect.adjusted(-spread,-spread,spread,spread),12+spread,12+spread)
        p.setOpacity(.85)
        p.drawPixmap(self.margin,self.margin,self.image)
        p.setOpacity(1)
        color.setAlpha(220)
        p.setPen(QPen(color,1.5))
        p.drawRoundedRect(rect.adjusted(.5,.5,-.5,-.5),12,12)


class TaskCard(QFrame):
    openAttachment=Signal(object)

    def __init__(self, task, parent=None, user_colors=None):
        super().__init__(parent)
        self.setObjectName("taskCard")
        emergency = bool((task.get("emergency",False) or task["urgent"]) and task["status"] != "done")
        self.setProperty("emergency", emergency)
        box = QVBoxLayout(self)
        box.setContentsMargins(15, 14, 15, 13)
        box.setSpacing(8)
        if emergency:
            row = QHBoxLayout()
            row.setSpacing(7)
            icon = QLabel()
            icon.setPixmap(warning_icon(22).pixmap(22,22))
            icon.setAccessibleName("Avertissement : tâche urgente")
            row.addWidget(icon)
            lab = QLabel("Urgent")
            lab.setObjectName("urgent")
            row.addWidget(lab)
            row.addStretch()
            box.addLayout(row)
        title = QLabel(task["title"])
        title.setObjectName("taskTitle")
        title.setWordWrap(True)
        title.setTextFormat(Qt.TextFormat.PlainText)
        heading=QHBoxLayout()
        heading.setSpacing(8)
        if task.get("category"):
            category=QLabel(task["category"][:17]+("…" if len(task["category"])>17 else ""))
            category.setObjectName("category")
            category.setMaximumWidth(120)
            category.setTextFormat(Qt.TextFormat.PlainText)
            category.setToolTip(task["category"])
            heading.addWidget(category,0,Qt.AlignmentFlag.AlignTop)
        heading.addWidget(title,1)
        box.addLayout(heading)
        if task["client"]:
            client = QLabel(task["client"])
            client.setObjectName("client")
            client.setTextFormat(Qt.TextFormat.PlainText)
            client.setWordWrap(True)
            box.addWidget(client)
        if task["notes"]:
            txt = task["notes"].replace("\n", " ")
            note = QLabel(txt[:95] + ("…" if len(txt)>95 else ""))
            note.setObjectName("taskNote")
            note.setTextFormat(Qt.TextFormat.PlainText)
            note.setWordWrap(True)
            box.addWidget(note)
        attachments=task.get("attachments",[])
        row = QHBoxLayout()
        row.setSpacing(5)
        owner_text=task["owner"] or "À attribuer"
        owner = QLabel(owner_text[:17]+("…" if len(owner_text)>17 else ""))
        owner.setToolTip(owner_text)
        owner.setTextFormat(Qt.TextFormat.PlainText)
        owner.setObjectName("owner")
        owner.setProperty("secretary", task["owner"] == "Secrétaire")
        owner.setStyleSheet(badge_style(owner_color(task["owner"],overrides=user_colors)))
        row.addWidget(owner)
        row.addStretch()
        if attachments:
            button=QToolButton()
            button.setObjectName("attachmentsButton")
            button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon))
            button.setIconSize(QSize(16,16))
            button.setText(str(len(attachments)))
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setToolTip(f"{len(attachments)} fichier(s) et dossier(s) liés · cliquer pour ouvrir")
            button.setAccessibleName(f"Ouvrir les {len(attachments)} fichiers et dossiers liés")
            menu=QMenu(button)
            menu.setToolTipsVisible(True)
            for attachment in attachments:
                icon=QStyle.StandardPixmap.SP_DirIcon if attachment["kind"]=="folder" else QStyle.StandardPixmap.SP_FileIcon
                action=menu.addAction(self.style().standardIcon(icon),attachment["name"].replace("&","&&"))
                action.setToolTip(attachment["path"])
                action.setData(attachment)
                action.triggered.connect(lambda checked=False,a=attachment:self.openAttachment.emit(a))
            button.setMenu(menu)
            row.addWidget(button)
        due = QLabel(due_label(task))
        due.setObjectName("doneLabel" if task["status"]=="done" else "due")
        due.setProperty("late",bool(task["due"] and task["due"]<date.today().isoformat() and task["status"]!="done"))
        due.setProperty("today",task["due"]==date.today().isoformat() and task["status"]!="done")
        row.addWidget(due)
        box.addLayout(row)
        if task["original_due"] and task["due"] and task["due"] > task["original_due"] and task["status"] != "done":
            report = QLabel("Reportée · prévue au départ le " + pretty_date(task["original_due"]))
            report.setObjectName("report")
            report.setWordWrap(True)
            box.addWidget(report)


class CardList(QListWidget):
    openTask = Signal(str)
    openAttachment = Signal(object)
    moveTask = Signal(str, int, str)
    contextTask = Signal(str, object)
    emptyContext = Signal(object)
    dragStarted = Signal()
    dragFinished = Signal()

    def __init__(self, status, parent=None):
        super().__init__(parent)
        self.status = status
        self.board_key = ""
        self.setObjectName("cards")
        self.setSpacing(7)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.itemClicked.connect(lambda item:self.openTask.emit(item.data(Qt.ItemDataRole.UserRole)["id"]))
        self.itemActivated.connect(lambda item:self.openTask.emit(item.data(Qt.ItemDataRole.UserRole)["id"]))
        self.customContextMenuRequested.connect(self.show_context)
        self.empty = QLabel("Rien ici pour le moment", self.viewport())
        self.empty.setObjectName("muted")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setWordWrap(True)
        self.empty.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def show_context(self, pos):
        item=self.itemAt(pos)
        if item:
            self.contextTask.emit(item.data(Qt.ItemDataRole.UserRole)["id"], self.viewport().mapToGlobal(pos))
        else:
            self.emptyContext.emit(self.viewport().mapToGlobal(pos))

    def populate(self, tasks, board_key, user_colors=None):
        scroll=self.verticalScrollBar().value()
        self.clear()
        self.board_key=board_key
        width=max(200,self.viewport().width()-18)
        for task in tasks:
            item=QListWidgetItem()
            item.setData(Qt.ItemDataRole.UserRole,task)
            item.setToolTip("Cliquer pour ouvrir · Glisser pour changer de colonne")
            self.addItem(item)
            card=TaskCard(task,user_colors=user_colors)
            card.openAttachment.connect(self.openAttachment.emit)
            self.setItemWidget(item,card)
            h=card.layout().totalHeightForWidth(width)
            item.setSizeHint(QSize(width,max(h,card.sizeHint().height())))
        self.empty.setVisible(not tasks)
        self.verticalScrollBar().setValue(scroll)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.empty.setGeometry(15,35,max(0,self.viewport().width()-30),60)
        width=max(180,self.viewport().width()-18)
        for i in range(self.count()):
            item=self.item(i)
            card=self.itemWidget(item)
            if card:
                item.setSizeHint(QSize(width,max(card.layout().totalHeightForWidth(width),card.sizeHint().height())))

    def startDrag(self,actions):
        item=self.currentItem()
        if item is None:
            return
        task=item.data(Qt.ItemDataRole.UserRole)
        mime=QMimeData()
        mime.setData(MIME,json.dumps({"id":task["id"],"version":task["version"],"board":self.board_key}).encode())
        drag=QDrag(self)
        drag.setMimeData(mime)
        card=self.itemWidget(item)
        self._drag_preview=None
        if card:
            invisible=QPixmap(1,1)
            invisible.fill(Qt.GlobalColor.transparent)
            drag.setPixmap(invisible)
            self._drag_preview=DragCardPreview(card)
            self._drag_preview.show()
        self.dragStarted.emit()
        try:
            drag.exec(Qt.DropAction.MoveAction)
        finally:
            if self._drag_preview:
                self._drag_preview.timer.stop()
                self._drag_preview.close()
                self._drag_preview.deleteLater()
                self._drag_preview=None
            self.dragFinished.emit()

    def set_drag_danger(self,on):
        preview=getattr(self,"_drag_preview",None)
        if preview:preview.set_danger(on)

    def valid_payload(self,event):
        try:
            data=json.loads(bytes(event.mimeData().data(MIME)))
            if data.get("board")==self.board_key and type(data.get("version")) is int and isinstance(data.get("id"),str):
                return data
        except (ValueError,TypeError):
            pass
        return None

    def mark_drop(self,on):
        column=self.parentWidget()
        column.setProperty("dropActive",on)
        column.style().unpolish(column)
        column.style().polish(column)
        column.update()

    def dragEnterEvent(self,event):
        if self.valid_payload(event):
            event.acceptProposedAction()
            self.mark_drop(True)

    def dragMoveEvent(self,event):
        if self.valid_payload(event):
            event.acceptProposedAction()

    def dragLeaveEvent(self,event):
        self.mark_drop(False)
        event.accept()

    def dropEvent(self,event):
        self.mark_drop(False)
        data=self.valid_payload(event)
        if data:
            self.moveTask.emit(data["id"],data["version"],self.status)
            event.acceptProposedAction()


class TrashDropTarget(QFrame):
    dropTask = Signal(str, int)

    def __init__(self,parent=None):
        super().__init__(parent)
        self.board_key=""
        self.open_lid=False
        self.drop_active=False
        self.drag_source=None
        self.setObjectName("trashDropTarget")
        self.setAcceptDrops(True)
        self.setFixedSize(100,112)
        row=QVBoxLayout(self)
        row.setContentsMargins(10,8,10,8)
        icon=QLabel()
        icon.setObjectName("trashDropIcon")
        icon.setPixmap(trash_icon_pixmap())
        self.halo=QGraphicsDropShadowEffect(icon)
        self.halo.setOffset(0,0)
        self.halo.setBlurRadius(18)
        self.halo.setColor(QColor(232,101,112,120))
        icon.setGraphicsEffect(self.halo)
        self.halo.setEnabled(False)
        icon.setAccessibleName("Icône de corbeille")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setToolTip("Déposer la tâche dans la corbeille")
        row.addWidget(icon,1)

    def set_active(self,on):
        self.drop_active=on
        self.halo.setEnabled(on)
        if self.drag_source is not None:
            self.drag_source.set_drag_danger(on)
        if not on:self.drag_source=None

    def payload(self,event):
        try:
            data=json.loads(bytes(event.mimeData().data(MIME)))
            if data.get("board")==self.board_key and type(data.get("version")) is int and isinstance(data.get("id"),str):
                return data
        except (ValueError,TypeError):
            pass
        return None

    def dragEnterEvent(self,event):
        if self.payload(event):
            source=event.source()
            self.drag_source=source if hasattr(source,"set_drag_danger") else None
            self.set_active(True)
            event.acceptProposedAction()

    def dragLeaveEvent(self,event):
        self.set_active(False)
        event.accept()

    def dropEvent(self,event):
        data=self.payload(event)
        self.set_active(False)
        if data:
            self.dropTask.emit(data["id"],data["version"])
            event.acceptProposedAction()


class ColumnPanel(QFrame):
    def __init__(self,color,parent=None):
        super().__init__(parent)
        self.color=QColor(color)
        self.setObjectName("columnPanel")

    def paintEvent(self,event):
        painter=QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        active=bool(self.property("dropActive"))
        path=QPainterPath()
        path.addRoundedRect(QRectF(self.rect()).adjusted(1,1,-1,-1),16,16)
        background=(self.palette().color(QPalette.ColorRole.Window)
            if QApplication.instance().property("tableauExtension")
            else QColor("#18243a" if active else "#131822"))
        painter.fillPath(path,background)
        pen=QPen(self.color,1.8 if active else 1.1)
        pen.setDashPattern([7,4])
        pen.setCapStyle(Qt.PenCapStyle.FlatCap)
        painter.setPen(pen)
        painter.drawPath(path)
        painter.end()


class BoardColumn(QFrame):
    addTask = Signal(str)

    def __init__(self,status,color,parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QPushButton
        self.setObjectName("columnContainer")
        outer=QVBoxLayout(self)
        outer.setContentsMargins(0,0,0,16)
        self.panel=ColumnPanel(color,self)
        outer.addWidget(self.panel)
        box=QVBoxLayout(self.panel)
        box.setContentsMargins(9,8,9,22)
        box.setSpacing(8)
        head=QHBoxLayout()
        head.setContentsMargins(7,0,7,0)
        dot=QLabel("●")
        dot.setStyleSheet(f"color:{color};font-size:12pt")
        head.addWidget(dot)
        title=QLabel(STATUS_LABELS[status])
        title.setObjectName("columnTitle")
        head.addWidget(title)
        head.addStretch()
        self.count_label=QLabel("0")
        self.count_label.setObjectName("count")
        head.addWidget(self.count_label)
        self.add_button=QPushButton(self)
        self.add_button.setIcon(plus_icon())
        self.add_button.setIconSize(QSize(18,18))
        self.add_button.setObjectName("columnAdd")
        self.add_button.setFixedSize(32,32)
        self.add_button.setToolTip("Nouvelle tâche dans « "+STATUS_LABELS[status]+" »")
        self.add_button.setAccessibleName(self.add_button.toolTip())
        self.add_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_button.clicked.connect(lambda:self.addTask.emit(status))
        box.addLayout(head)
        self.cards=CardList(status,self.panel)
        box.addWidget(self.cards,1)
        self.add_button.raise_()

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.layout().activate()
        # The centre of the circle sits on the panel's bottom border.
        self.add_button.move((self.width()-self.add_button.width())//2,
            self.panel.geometry().bottom()-self.add_button.height()//2)
