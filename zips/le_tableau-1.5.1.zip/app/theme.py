from .theme_base import *
import sys
from pathlib import Path

ASSETS=(Path(getattr(sys,"_MEIPASS",Path(__file__).resolve().parent.parent))/"assets").as_posix()

STYLESHEET += f"""
QWidget {{ background: transparent; }}
QMainWindow, QWidget#root {{ background: {BG}; }}
QDialog {{ background: {SURFACE}; }}
QLabel#eyebrow {{ color: {ACCENT}; font-size: 9pt; font-weight: 700; }}
QLabel#boardTitle {{ font-size: 25pt; font-weight: 700; }}
QLabel#brand {{ font-size: 13pt; font-weight: 700; }}
QLabel#muted {{ color: {MUTED}; }}
QLabel#pill {{ background: #25334d; color: #9cbcff; border-radius: 11px; padding: 4px 10px; font-size: 9pt; }}
QLabel#footer {{ color: {MUTED}; font-size: 9pt; }}
QFrame#separator {{ background: {BORDER}; max-height: 1px; }}
QFrame#column {{ background: #131822; border: 1px solid #242b39; border-radius: 16px; }}
QFrame#column[dropActive="true"] {{ border: 2px solid {ACCENT}; background: #18243a; }}
QLabel#columnTitle {{ font-size: 12pt; font-weight: 600; }}
QLabel#count {{ background: #242c3b; color: #b7c1d3; border-radius: 10px; padding: 3px 8px; font-size: 9pt; }}
QListWidget#cards {{ background: transparent; border: none; outline: none; padding: 0px; }}
QListWidget#cards::item {{ border: none; background: transparent; padding: 0; margin: 0; }}
QListWidget#cards::item:selected {{ background: transparent; }}
QFrame#taskCard {{ background: {SURFACE_2}; border: 1px solid #30394b; border-radius: 12px; }}
QFrame#taskCard:hover {{ border-color: {ACCENT}; background: #232b3a; }}
QFrame#taskCard[emergency="true"] {{ background: #30232a; border: 2px solid #f5a747; }}
QFrame#taskCard[emergency="true"]:hover {{ background: #3a2830; border-color: #ffca77; }}
QLabel#taskTitle {{ font-size: 11pt; font-weight: 600; }}
QLabel#client {{ color: #9faac0; font-size: 9pt; }}
QLabel#category {{ color: #bdc6d6; background: #29313f; border: 1px solid #3b4659; border-radius: 6px; padding: 3px 7px; font-size: 8pt; }}
QLabel#taskNote {{ color: #929eb5; font-size: 9pt; }}
QLabel#urgent {{ background: #5b3523; color: #ffd18a; border-radius: 6px; padding: 4px 8px; font-size: 9pt; font-weight: 700; }}
QLabel#priority {{ background: #462733; color: #ff9da7; border-radius: 6px; padding: 3px 7px; font-size: 8pt; font-weight: 700; }}
QLabel#owner {{ background: #283957; color: #b7d0ff; border-radius: 7px; padding: 4px 8px; font-size: 9pt; }}
QLabel#owner[secretary="true"] {{ background: #3b3151; color: #d6c0fb; }}
QLabel#due {{ color: #b7c1d3; font-size: 9pt; }}
QLabel#due[late="true"] {{ background: #442832; color: #ff9da7; border-radius: 6px; padding: 4px 7px; }}
QLabel#due[today="true"] {{ color: #f5bc66; }}
QLabel#report {{ color: #ba9be8; font-size: 8pt; }}
QLabel#doneLabel {{ color: {SUCCESS}; font-size: 9pt; }}
QPushButton#filter {{ border-radius: 8px; padding: 8px 15px; background: transparent; border: 1px solid transparent; color: {MUTED}; }}
QPushButton#filter:checked {{ background: #263753; border-color: #3c5784; color: #d7e5ff; }}
QPushButton#filter:hover {{ color: {TEXT}; background: {SURFACE_2}; }}
QPushButton#lateFilter {{ border-radius: 14px; padding: 5px 12px; background: #6d431d; color: #ffe0ac; border: 2px solid transparent; }}
QPushButton#lateFilter:hover {{ background: #855224; border-color: #f5bc66; }}
QPushButton#lateFilter:checked {{ background: #855224; border-color: #ffd18a; }}
QPushButton#quiet {{ background: transparent; border-color: transparent; color: {MUTED}; padding: 7px 10px; }}
QPushButton#quiet:hover {{ color: {TEXT}; border-color: {BORDER}; background: {SURFACE_2}; }}
QPushButton#mainMenu {{ background: #263753; border: 1px solid #4b6a9b; color: #e2ecff; padding: 6px 24px 6px 13px; font-weight: 600; }}
QPushButton#mainMenu:hover, QPushButton#mainMenu:pressed {{ background: #334e79; border-color: {ACCENT}; }}
QPushButton#columnAdd {{ padding: 0px; min-height: 0px; background: #242f43; border: 1px solid #3a4b68; border-radius: 16px; color: #b7d0ff; font-size: 17pt; }}
QPushButton#columnAdd:hover {{ background: #334e79; border-color: {ACCENT}; color: white; }}
QLabel#profileBadge {{ border-radius: 14px; padding: 0px 12px; font-size: 9pt; font-weight: 600; }}
QToolButton#attachmentsButton {{ color: #b7d0ff; background: #202d42; border: 1px solid #334765; border-radius: 6px; padding: 4px 18px 4px 6px; font-size: 9pt; }}
QToolButton#attachmentsButton:hover, QToolButton#attachmentsButton:pressed {{ color: #ffffff; background: #2a4267; border-color: {ACCENT}; }}
QToolButton#attachmentsButton::menu-indicator {{ image: url("{ASSETS}/chevron.svg"); width: 12px; height: 12px; subcontrol-position: right center; subcontrol-origin: padding; right: 3px; }}
QListWidget#attachmentList {{ background: {SURFACE_2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 3px; }}
QListWidget#attachmentList::item {{ padding: 5px 8px; border-radius: 4px; }}
QListWidget#attachmentList::item:selected {{ background: #2a4267; color: #ffffff; }}
QPushButton#danger {{ color: #ff9da7; background: #38242c; border-color: #58333e; }}
QPushButton#primary {{ padding: 11px 20px; }}
QLineEdit#search {{ min-height: 28px; padding: 5px 12px; border-radius: 9px; background: #171e2a; }}
QLineEdit, QComboBox, QDateEdit, QSpinBox {{ padding: 7px 10px; min-height: 26px; border: 1px solid {BORDER}; border-radius: 8px; background: {SURFACE_2}; }}
QDateEdit:disabled {{ color: #697386; background: #191e29; }}
QDateEdit::drop-down {{ border: none; background: transparent; width: 28px; }}
QSpinBox {{ padding-right: 28px; }}
QSpinBox::up-button {{ subcontrol-origin: border; subcontrol-position: top right; width: 24px; background: transparent; border: none; }}
QSpinBox::down-button {{ subcontrol-origin: border; subcontrol-position: bottom right; width: 24px; background: transparent; border: none; }}
QSpinBox::up-button:hover, QSpinBox::down-button:hover {{ background: #232a3a; }}
QSpinBox::up-arrow {{ image: url("{ASSETS}/chevron-up.svg"); width: 12px; height: 12px; }}
QSpinBox::down-arrow {{ image: url("{ASSETS}/chevron.svg"); width: 12px; height: 12px; }}
QComboBox::down-arrow, QDateEdit::down-arrow {{ image: url("{ASSETS}/chevron.svg"); width: 16px; height: 16px; }}
QTextEdit, QTextBrowser {{ background: {SURFACE_2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 8px; selection-background-color: #25407a; }}
QComboBox, QTextEdit {{ border: 1px solid #566077; }}
QComboBox {{ padding-right: 34px; }}
QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: top right; width: 30px; border: none; border-left: 1px solid #566077; background: transparent; }}
QComboBox:hover, QComboBox:focus, QTextEdit:focus {{ border-color: {ACCENT}; }}
QCalendarWidget QWidget {{ background: {SURFACE_2}; }}
QCalendarWidget QAbstractItemView {{ background: {SURFACE}; color: {TEXT}; selection-background-color: {ACCENT}; }}
QCheckBox {{ spacing: 8px; color: #bcc5d7; padding: 3px 0px; }}
QCheckBox#urgencyCheck {{ color: #ffd18a; font-weight: 700; background: #34272a; border: 1px solid #845b36; border-radius: 8px; padding: 8px 12px; }}
QCheckBox::indicator {{ width: 17px; height: 17px; border: 1px solid #4b5870; border-radius: 4px; background: {SURFACE_2}; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; image: url("{ASSETS}/check.svg"); }}
QFrame#message {{ background: #1e2d43; border: 1px solid #355176; border-radius: 9px; }}
QFrame#toast {{ background: #21344e; border: 1px solid #4f8cff; border-radius: 12px; }}
QFrame#trashDropTarget {{ background: transparent; border: none; }}
QLabel#error {{ color: #ff9da7; background: #38242c; padding: 10px; border-radius: 8px; }}
QMenu {{ background: {SURFACE_2}; border: 1px solid {BORDER}; padding: 6px; }}
QMenu::item {{ padding: 8px 18px; border-radius: 5px; }}
QMenu::item:selected {{ background: #2a4267; }}
QToolTip {{ background: {SURFACE_2}; color: {TEXT}; padding: 8px; border: 1px solid {BORDER}; }}
"""
