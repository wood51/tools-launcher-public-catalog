"""Traduction des dialogues Qt de l'édition autonome."""

from PySide6.QtCore import QLibraryInfo, QLocale, QTranslator


def install_french_qt(app):
    QLocale.setDefault(QLocale(QLocale.Language.French, QLocale.Country.France))
    translator=QTranslator(app)
    translations=QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)
    loaded=translator.load("qtbase_fr",translations)
    app._tableau_translators=[translator] if loaded else []
    if loaded:app.installTranslator(translator)
    return loaded
