"""References to existing files/folders. Never copy, move or delete originals."""
from __future__ import annotations

import ntpath
import os
from pathlib import Path


def valid_attachments(items):
    if not isinstance(items, list):
        return False
    seen = set()
    for item in items:
        if not isinstance(item, dict) or set(item) != {"name", "path", "kind"}:
            return False
        name, path, kind = item["name"], item["path"], item["kind"]
        if (not isinstance(name, str) or not name.strip() or len(name) > 300
                or not isinstance(path, str) or not path or len(path) > 32767 or "\0" in path
                or not (ntpath.isabs(path) or Path(path).is_absolute())
                or "://" in path or kind not in ("file", "folder")):
            return False
        key = ntpath.normcase(ntpath.normpath(path))
        if key in seen:
            return False
        seen.add(key)
    return True


def universal_path(path):
    """Resolve mapped network drives to UNC without depending on drive letters."""
    path = os.path.normpath(os.path.abspath(os.fspath(path)))
    if os.name != "nt" or path.startswith("\\\\"):
        return path
    import ctypes
    from ctypes import wintypes
    get_name = ctypes.WinDLL("mpr").WNetGetUniversalNameW
    get_name.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.LPVOID,
                         ctypes.POINTER(wintypes.DWORD)]
    get_name.restype = wintypes.DWORD
    size = wintypes.DWORD(1024)
    buffer = ctypes.create_string_buffer(size.value)
    result = get_name(path, 1, buffer, ctypes.byref(size))
    if result == 234 and 0 < size.value < 1024 * 1024:
        buffer = ctypes.create_string_buffer(size.value)
        result = get_name(path, 1, buffer, ctypes.byref(size))
    if result == 0:
        return ctypes.cast(buffer, ctypes.POINTER(wintypes.LPWSTR))[0]
    return path


def file_reference(path, kind):
    path = universal_path(path)
    name = ntpath.basename(path.rstrip("\\/")) or path
    item = {"name": name, "path": path, "kind": kind}
    if not valid_attachments([item]):
        raise ValueError("Ce chemin de fichier ou de dossier n’est pas valide.")
    return item


def reference_exists(item):
    # Called in a worker: disconnected shares must not block the GUI.
    if not valid_attachments([item]):
        return False
    path = Path(item["path"])
    return path.is_dir() if item["kind"] == "folder" else path.is_file()
