"""Le Tableau: a small, shared office task board."""
