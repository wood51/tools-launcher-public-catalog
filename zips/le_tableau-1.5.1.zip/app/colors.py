"""Shared badge colors, with readable text on both light and dark backgrounds."""
import hashlib
import re

BADGE_COLORS = (
    ("Bleu", "#3B6FA0"), ("Violet", "#8052A0"), ("Vert", "#367653"),
    ("Orange", "#AD662C"), ("Rose", "#A44572"), ("Turquoise", "#26797D"),
    ("Rouge", "#AE424C"), ("Jaune", "#D2AD43"), ("Indigo", "#555B9B"),
    ("Gris", "#586473"),
)


def valid_user_colors(colors):
    return isinstance(colors, dict) and all(
        isinstance(name, str) and bool(name.strip()) and len(name) <= 60
        and isinstance(color, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", color)
        for name, color in colors.items())


def owner_color(name, users=(), overrides=None):
    if not name:
        return "#424856"
    if overrides and name in overrides:
        return overrides[name]
    if name in users:
        index = list(users).index(name)
    else:
        index = int.from_bytes(hashlib.sha256(name.encode("utf-8")).digest()[:2], "big")
    return BADGE_COLORS[index % len(BADGE_COLORS)][1]


def board_user_colors(settings):
    colors = dict(settings.get("user_colors", {}))
    for name in settings["users"]:
        colors[name] = owner_color(name, settings["users"], colors)
    return colors


def badge_text_color(color):
    components = [int(color[i:i+2], 16)/255 for i in (1, 3, 5)]
    linear = [c/12.92 if c <= .04045 else ((c+.055)/1.055)**2.4 for c in components]
    luminance = sum(a*b for a, b in zip(linear, (.2126, .7152, .0722)))
    return "#FFFFFF" if 1.05/(luminance+.05) >= (luminance+.05)/.05 else "#000000"


def badge_style(color):
    return f"background-color: {color}; color: {badge_text_color(color)};"
