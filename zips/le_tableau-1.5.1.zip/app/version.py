VERSION = "1.5.1"
RELEASE_REPOSITORY = "wood51/le-tableau-releases"
