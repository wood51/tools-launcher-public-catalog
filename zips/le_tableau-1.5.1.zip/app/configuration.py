from __future__ import annotations

from PySide6.QtCore import Signal, Qt
from PySide6.QtGui import QIcon, QPixmap, QColor, QPainter
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QTextEdit, QComboBox, QSpinBox, QCheckBox, QPushButton, QFrame, QTabWidget, QWidget, QScrollArea)
from .storage import board_settings
from .colors import BADGE_COLORS, board_user_colors, owner_color


def caption(text):
    widget = QLabel(text)
    widget.setObjectName("muted")
    widget.setWordWrap(True)
    return widget


def color_icon(color):
    pixmap=QPixmap(16,16)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter=QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor(color))
    painter.drawEllipse(2,2,12,12)
    painter.end()
    return QIcon(pixmap)


class ConfigurationDialog(QDialog):
    saveRequested = Signal(object)
    openRequested = Signal()
    createRequested = Signal()
    openBoardFolderRequested = Signal()
    openBackupsRequested = Signal()
    openPeriodicBackupsRequested = Signal()

    def __init__(self, snapshot, folder, member, duration, reminders, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configuration")
        self.setMinimumSize(650, 500)
        self.resize(720, 580)
        self.config = board_settings(snapshot)
        self.user_colors = board_user_colors(self.config)
        self.color_combos = {}
        self.saving = False
        box = QVBoxLayout(self)
        box.setContentsMargins(26, 22, 26, 22)
        box.setSpacing(10)
        title = QLabel("Un tableau, toute l’équipe.")
        title.setObjectName("title")
        box.addWidget(title)
        box.addWidget(caption("Un seul tableau commun, un exemplaire du logiciel sur chaque PC."))
        self.tabs = QTabWidget()
        shared = QWidget()
        shared_box = QVBoxLayout(shared)
        shared_box.setContentsMargins(14, 18, 14, 14)
        shared_box.setSpacing(10)
        self.tabs.addTab(shared, "Tableau")
        team = QWidget()
        team_box = QVBoxLayout(team)
        team_box.setContentsMargins(14, 18, 14, 14)
        team_box.setSpacing(9)
        self.tabs.addTab(team, "Équipe")
        categories_tab = QWidget()
        categories_box = QVBoxLayout(categories_tab)
        categories_box.setContentsMargins(14, 18, 14, 14)
        categories_box.setSpacing(10)
        self.tabs.addTab(categories_tab, "Catégories")
        backups = QWidget()
        backups_box = QVBoxLayout(backups)
        backups_box.setContentsMargins(14, 18, 14, 14)
        backups_box.setSpacing(12)
        self.tabs.addTab(backups, "Sauvegardes")
        local = QWidget()
        local_box = QVBoxLayout(local)
        local_box.setContentsMargins(14, 18, 14, 14)
        local_box.setSpacing(14)
        self.tabs.addTab(local, "Ce PC")
        box.addWidget(self.tabs, 1)
        shared_box.addWidget(caption("Nom du tableau"))
        self.title_edit = QLineEdit(self.config["title"])
        self.title_edit.setMaxLength(80)
        shared_box.addWidget(self.title_edit)
        path = caption(str(folder))
        path.setToolTip(str(folder))
        shared_box.addWidget(caption("Dossier commun actuellement ouvert"))
        shared_box.addWidget(path)
        row = QHBoxLayout()
        self.open_button = QPushButton("Ouvrir un tableau existant…")
        self.open_button.clicked.connect(self.request_open)
        row.addWidget(self.open_button)
        self.create_button = QPushButton("Créer le tableau…")
        self.create_button.clicked.connect(self.request_create)
        row.addWidget(self.create_button)
        shared_box.addLayout(row)
        self.open_folder_button = QPushButton("Ouvrir le dossier du tableau")
        self.open_folder_button.clicked.connect(self.openBoardFolderRequested)
        shared_box.addWidget(self.open_folder_button)
        shared_box.addStretch()
        team_box.addWidget(caption("Les personnes de l’équipe · un prénom par ligne"))
        self.users = QTextEdit()
        self.users.setAcceptRichText(False)
        self.users.setPlainText("\n".join(self.config["users"]))
        self.users.setMaximumHeight(100)
        team_box.addWidget(self.users)
        team_box.addWidget(caption("Changer un prénom ici ne réattribue pas les anciennes tâches."))
        team_box.addWidget(caption("Couleur des badges · un choix par personne"))
        color_scroll=QScrollArea()
        color_scroll.setObjectName("teamColorScroll")
        color_scroll.setWidgetResizable(True)
        color_scroll.setFrameShape(QFrame.Shape.NoFrame)
        color_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        color_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        color_widget=QWidget()
        self.color_rows=QVBoxLayout(color_widget)
        self.color_rows.setContentsMargins(0,0,6,0)
        self.color_rows.setSpacing(6)
        color_scroll.setWidget(color_widget)
        team_box.addWidget(color_scroll,1)
        self.rebuild_colors()
        self.users.textChanged.connect(self.rebuild_colors)
        categories_box.addWidget(caption("Catégories · un nom par ligne"))
        self.categories=QTextEdit()
        self.categories.setAcceptRichText(False)
        self.categories.setPlaceholderText("Ex. Devis\nCommandes\nAdministratif")
        self.categories.setPlainText("\n".join(self.config["categories"]))
        categories_box.addWidget(self.categories,1)
        categories_box.addWidget(caption("Facultatives : une catégorie par tâche. Retirer un nom conserve les catégories des anciennes tâches."))
        row = QHBoxLayout()
        self.backup_enabled = QCheckBox("Sauvegarde à l’ouverture tous les")
        self.backup_enabled.setChecked(bool(self.config["backup_days"]))
        row.addWidget(self.backup_enabled)
        self.backup_days = QSpinBox()
        self.backup_days.setRange(1, 365)
        self.backup_days.setValue(self.config["backup_days"] or 7)
        self.backup_days.setSuffix(" jours")
        self.backup_days.setEnabled(self.backup_enabled.isChecked())
        self.backup_enabled.toggled.connect(self.backup_days.setEnabled)
        row.addWidget(self.backup_days)
        backups_box.addLayout(row)
        backups_box.addWidget(caption("30 copies périodiques sont gardées sur le NAS. Un seul poste crée la copie attendue."))
        self.open_backups_button = QPushButton("Ouvrir les sauvegardes")
        self.open_backups_button.clicked.connect(self.openBackupsRequested)
        backups_box.addWidget(self.open_backups_button)
        self.open_periodic_button = QPushButton("Ouvrir les sauvegardes périodiques")
        self.open_periodic_button.clicked.connect(self.openPeriodicBackupsRequested)
        backups_box.addWidget(self.open_periodic_button)
        backups_box.addStretch()
        row = QHBoxLayout()
        row.addWidget(caption("Sur ce poste, je suis"))
        self.member = QComboBox()
        row.addWidget(self.member, 1)
        local_box.addLayout(row)
        self.rebuild_members(member)
        self.users.textChanged.connect(lambda: self.rebuild_members(self.member.currentText()))
        row = QHBoxLayout()
        row.addWidget(caption("Les notifications disparaissent après"))
        self.duration = QSpinBox()
        self.duration.setRange(3, 30)
        self.duration.setValue(duration)
        self.duration.setSuffix(" secondes")
        row.addWidget(self.duration)
        local_box.addLayout(row)
        self.reminders = QCheckBox("Afficher un rappel des échéances à l’ouverture")
        self.reminders.setChecked(reminders)
        local_box.addWidget(self.reminders)
        local_box.addWidget(caption("Les notifications s’affichent dans l’application. Ces réglages sont propres à ce poste."))
        local_box.addStretch()
        self.error = QLabel()
        self.error.setObjectName("error")
        self.error.setWordWrap(True)
        self.error.hide()
        box.addWidget(self.error)
        box.addStretch()
        row = QHBoxLayout()
        row.addStretch()
        self.cancel = QPushButton("Fermer")
        self.cancel.clicked.connect(self.reject)
        row.addWidget(self.cancel)
        self.save_button = QPushButton("Enregistrer")
        self.save_button.setObjectName("primary")
        self.save_button.clicked.connect(self.submit)
        row.addWidget(self.save_button)
        box.addLayout(row)

    def rebuild_members(self, current):
        self.member.clear()
        self.member.addItem("Choisir mon prénom…", "")
        for name in self.users.toPlainText().splitlines():
            if name.strip():
                self.member.addItem(name.strip(), name.strip())
        index = self.member.findData(current)
        self.member.setCurrentIndex(max(0, index))

    def submit(self):
        self.set_saving(True)
        names=[name.strip() for name in self.users.toPlainText().splitlines() if name.strip()]
        colors={**board_user_colors(self.config),
                **{name:owner_color(name,names,self.user_colors) for name in names}}
        self.saveRequested.emit({"title": self.title_edit.text(), "users": self.users.toPlainText().splitlines(),
            "version": self.config["version"], "member": self.member.currentData() or "",
            "duration": self.duration.value(), "reminders": self.reminders.isChecked(),
            "backup_days": self.backup_days.value() if self.backup_enabled.isChecked() else 0,
            "user_colors":colors,"categories":self.categories.toPlainText().splitlines()})

    def rebuild_colors(self):
        while self.color_rows.count():
            entry=self.color_rows.takeAt(0)
            if entry.widget():entry.widget().deleteLater()
        self.color_combos={}
        names=list(dict.fromkeys(name.strip() for name in self.users.toPlainText().splitlines() if name.strip()))
        for name in names:
            row_widget=QWidget()
            row_widget.setFixedHeight(38)
            row=QHBoxLayout(row_widget)
            row.setContentsMargins(0,0,0,0)
            swatch=QLabel()
            swatch.setObjectName("memberColorSwatch")
            swatch.setFixedSize(14,14)
            row.addWidget(swatch)
            preview=QLabel(name[:24]+("…" if len(name)>24 else ""))
            preview.setObjectName("memberColorName")
            preview.setTextFormat(Qt.TextFormat.PlainText)
            preview.setToolTip(name)
            preview.setFixedHeight(30)
            preview.setMinimumWidth(150)
            row.addWidget(preview)
            row.addStretch()
            combo=QComboBox()
            combo.setObjectName("colorChoice")
            combo.setMinimumWidth(120)
            combo.setMaximumWidth(180)
            combo.setFixedHeight(36)
            color=owner_color(name,names,self.user_colors)
            choices=list(BADGE_COLORS)
            if color.upper() not in {c for _,c in choices}:
                choices.append(("Couleur actuelle",color))
            for label,hex_color in choices:
                combo.addItem(color_icon(hex_color),label,hex_color)
            selected=next(i for i in range(combo.count()) if combo.itemData(i).upper()==color.upper())
            combo.setCurrentIndex(selected)
            swatch.setStyleSheet(f"background-color:{color};border-radius:7px")
            def changed(index,n=name,c=combo,s=swatch):
                value=c.itemData(index)
                self.user_colors[n]=value
                s.setStyleSheet(f"background-color:{value};border-radius:7px")
            combo.currentIndexChanged.connect(changed)
            self.color_combos[name]=combo
            row.addWidget(combo)
            self.color_rows.addWidget(row_widget)
        self.color_rows.addStretch()

    def set_saving(self, busy):
        self.saving = busy
        self.tabs.setEnabled(not busy)
        for widget in (self.cancel, self.save_button, self.open_button, self.create_button,
                       self.open_folder_button, self.open_backups_button, self.open_periodic_button):
            widget.setEnabled(not busy)
        self.save_button.setText("Enregistrement…" if busy else "Enregistrer")

    def show_error(self, message):
        self.set_saving(False)
        self.error.setText(message)
        self.error.show()

    def request_open(self):
        self.reject()
        self.openRequested.emit()

    def request_create(self):
        self.reject()
        self.createRequested.emit()

    def reject(self):
        if not self.saving:
            super().reject()
