from PySide6.QtCore import Qt, QObject, Signal
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar

from . import updates
from .version import VERSION


class Progress(QObject):
    changed = Signal(int)


class UpdateDialog(QDialog):
    """Manual checks only; all network and hashing work stays off the GUI thread."""
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.release = None
        self.busy = False
        self.setWindowTitle("Mettre à jour Le Tableau")
        self.setMinimumWidth(540)
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)
        box = QVBoxLayout(self)
        box.setContentsMargins(28, 26, 28, 24)
        box.setSpacing(18)
        title = QLabel("Les nouveautés, quand vous voulez.")
        title.setObjectName("title")
        box.addWidget(title)
        self.status = QLabel("Recherche d’une nouvelle version…")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        box.addWidget(self.status)
        self.detail = QLabel(f"Version installée : {VERSION}\nLes tâches et vos réglages sont conservés.")
        self.detail.setObjectName("muted")
        self.detail.setWordWrap(True)
        box.addWidget(self.detail)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        box.addWidget(self.progress)
        self.error = QLabel()
        self.error.setObjectName("error")
        self.error.setWordWrap(True)
        self.error.setTextFormat(Qt.TextFormat.PlainText)
        self.error.hide()
        box.addWidget(self.error)
        buttons = QHBoxLayout()
        buttons.addStretch()
        self.close_button = QPushButton("Plus tard")
        self.close_button.clicked.connect(self.reject)
        buttons.addWidget(self.close_button)
        self.install_button = QPushButton("Mettre à jour")
        self.install_button.setObjectName("primary")
        self.install_button.setEnabled(False)
        self.install_button.clicked.connect(self.install)
        buttons.addWidget(self.install_button)
        box.addLayout(buttons)
        self.signals = Progress(self)
        self.signals.changed.connect(self.progress.setValue)
        self.check()

    def check(self):
        self.set_busy(True)
        self.window.job(updates.check_release, self.checked, self.failed)

    def checked(self, release):
        self.set_busy(False)
        self.progress.hide()
        self.release = release
        if release:
            self.status.setText(f"La version {release.version} est disponible.")
            self.detail.setText(f"Version installée : {VERSION}\n\nLe logiciel va se fermer, installer la mise à jour puis se rouvrir.\nLes tâches et vos réglages sont conservés.")
            self.install_button.setEnabled(True)
        else:
            self.status.setText("Vous avez déjà la dernière version.")
            self.close_button.setText("Fermer")

    def install(self):
        try:
            self.folder = updates.installation_folder()
        except updates.UpdateError as exc:
            self.failed(exc)
            return
        self.set_busy(True)
        self.error.hide()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.show()
        self.status.setText("Téléchargement et vérification de la nouvelle version…")
        def download():
            return updates.prepare_release(self.release,
                lambda done, total: self.signals.changed.emit(min(99, int(done * 100 / total))))
        self.window.job(download, self.prepared, self.failed)

    def prepared(self, package):
        self.status.setText("Préparation du redémarrage…")
        self.progress.setRange(0, 0)
        self.window.job(lambda: updates.launch_installer(package, self.release.version, self.folder),
                        self.ready, self.failed)

    def ready(self, _):
        self.busy = False
        self.window.update_busy = False
        self.accept()
        self.window.close()

    def failed(self, exc):
        self.set_busy(False)
        self.progress.hide()
        self.status.setText("La mise à jour n’a pas été installée.")
        self.error.setText(str(exc) if isinstance(exc, updates.UpdateError) else
                           "La vérification a échoué. Vous pouvez continuer à utiliser le tableau et réessayer plus tard.")
        self.error.show()
        self.close_button.setText("Fermer")
        self.install_button.setEnabled(self.release is not None)

    def set_busy(self, busy):
        self.busy = busy
        self.window.update_busy = busy
        self.close_button.setEnabled(not busy)
        self.install_button.setEnabled(False)

    def reject(self):
        if not self.busy:
            super().reject()
