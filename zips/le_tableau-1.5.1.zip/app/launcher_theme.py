"""Styles du tableau bâtis à partir des couleurs Qt appliquées par l'API."""
from pathlib import Path
import re

from PySide6.QtCore import QTimer
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QFrame, QLabel, QPushButton, QWidget


class ExtensionTheme:
    def __init__(self, app):
        self.app = app
        self.previous = None
        self.template = Path(__file__).with_name("launcher.qss").read_text(encoding="utf-8")
        self.timer = QTimer(app)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()

    def refresh(self):
        current = self.app.styleSheet()
        if current == self.previous:
            return
        # Retirer uniquement notre surcharge, après un changement de thème du noyau.
        base = current.split("/* Le Tableau extension */", 1)[0]
        colors = {}
        for token, cls, name, role in (
            ("BG", QWidget, "root", QPalette.ColorRole.Window),
            ("SURFACE", QFrame, "card", QPalette.ColorRole.Window),
            ("SURFACE_2", QPushButton, "", QPalette.ColorRole.Button),
            ("TEXT", QLabel, "", QPalette.ColorRole.WindowText),
            ("MUTED", QLabel, "muted", QPalette.ColorRole.WindowText),
            ("ACCENT", QPushButton, "primary", QPalette.ColorRole.Button),
            ("ON_ACCENT", QPushButton, "primary", QPalette.ColorRole.ButtonText),
        ):
            probe = cls()
            probe.setObjectName(name)
            probe.ensurePolished()
            colors[token] = probe.palette().color(role).name()
            probe.deleteLater()
        colors["BORDER"] = colors["MUTED"]
        text = re.sub(r"@([A-Z_0-9]+)", lambda match: colors[match[1]], self.template)
        self.previous = base + "\n/* Le Tableau extension */\n" + text
        self.app.setStyleSheet(self.previous)
