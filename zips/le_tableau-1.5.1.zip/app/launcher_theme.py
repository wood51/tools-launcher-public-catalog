"""Styles du tableau bâtis à partir des couleurs Qt appliquées par l'API."""
from pathlib import Path
import re

from PySide6.QtCore import QTimer
from PySide6.QtGui import QPalette, QColor
from PySide6.QtWidgets import QFrame, QLabel, QPushButton, QWidget


class ExtensionTheme:
    def __init__(self, app):
        self.app = app
        self.previous = None
        self.template = Path(__file__).with_name("launcher.qss").read_text(encoding="utf-8")
        self.timer = QTimer(app)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()

    def refresh(self):
        current = self.app.styleSheet()
        if current == self.previous:
            return
        # Retirer uniquement notre surcharge, après un changement de thème du noyau.
        base = current.split("/* Le Tableau extension */", 1)[0]
        colors = {}
        for token, cls, name, role in (
            ("BG", QWidget, "root", QPalette.ColorRole.Window),
            ("SURFACE", QFrame, "card", QPalette.ColorRole.Window),
            ("SURFACE_2", QPushButton, "", QPalette.ColorRole.Button),
            ("TEXT", QLabel, "", QPalette.ColorRole.WindowText),
            ("MUTED", QLabel, "muted", QPalette.ColorRole.WindowText),
            ("ACCENT", QPushButton, "primary", QPalette.ColorRole.Button),
            ("ON_ACCENT", QPushButton, "primary", QPalette.ColorRole.ButtonText),
        ):
            probe = cls()
            probe.setObjectName(name)
            probe.ensurePolished()
            colors[token] = probe.palette().color(role).name()
            probe.deleteLater()
        colors["BORDER"] = colors["MUTED"]
        foreground=QColor(colors["TEXT"])
        background=QColor(colors["SURFACE_2"])
        colors["FIELD_BORDER"]=QColor(*[round(a*.27+b*.73) for a,b in zip(
            foreground.getRgb()[:3],background.getRgb()[:3])]).name()
        arrow="chevron.svg" if foreground.lightness()>128 else "chevron-dark.svg"
        colors["FIELD_ARROW"]=(Path(__file__).resolve().parent.parent/"assets"/arrow).as_posix()
        text = re.sub(r"@([A-Z_0-9]+)", lambda match: colors[match[1]], self.template)
        self.previous = base + "\n/* Le Tableau extension */\n" + text
        self.app.setStyleSheet(self.previous)
