"""File-based board storage with OS locks and optimistic task revisions.

All clients must use the same direct SMB folder, not independently synced copies.
The lock file stays in place: its byte-range lock is released by Windows on exit.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime, timedelta
from calendar import monthrange
import copy
import json
import os
from pathlib import Path
import time
import uuid
from .attachments import valid_attachments
from .colors import valid_user_colors

STATUSES = ("todo", "doing", "waiting", "done")
STATUS_LABELS = {"todo": "À faire", "doing": "En cours", "waiting": "En attente", "done": "Terminé"}
RECURRENCE_MODES = ("calendar", "completion")
RECURRENCE_UNITS = ("day", "week", "month")


def valid_recurrence_spec(value):
    return (isinstance(value,dict) and set(value)=={"mode","unit","interval"}
            and value["mode"] in RECURRENCE_MODES and value["unit"] in RECURRENCE_UNITS
            and type(value["interval"]) is int and 1<=value["interval"]<=365)


def recurrence_date(value, unit, interval, anchor_day=None):
    current=date.fromisoformat(value)
    if unit=="day":return (current+timedelta(days=interval)).isoformat()
    if unit=="week":return (current+timedelta(weeks=interval)).isoformat()
    month=current.month-1+interval
    year=current.year+month//12
    month=month%12+1
    day=min(anchor_day or current.day,monthrange(year,month)[1])
    return date(year,month,day).isoformat()


def recurrence_template(task):
    return {key:copy.deepcopy(task[key]) for key in
            ("title","client","owner","urgent","emergency","notes","attachments","category")}


def valid_recurrence_series(series):
    if (not isinstance(series,dict) or set(series)!={"mode","unit","interval","active","next_due",
            "anchor_day","current_task_id","template"}
            or series["mode"] not in RECURRENCE_MODES or series["unit"] not in RECURRENCE_UNITS
            or type(series["interval"]) is not int or not 1<=series["interval"]<=365
            or type(series["active"]) is not bool or not isinstance(series["next_due"],str)
            or type(series["anchor_day"]) is not int or not 1<=series["anchor_day"]<=31
            or not isinstance(series["current_task_id"],str) or not series["current_task_id"]
            or not isinstance(series["template"],dict)):
        return False
    if series["mode"]=="calendar":
        try:date.fromisoformat(series["next_due"])
        except ValueError:return False
    elif series["next_due"]:
        return False
    template=series["template"]
    return (set(template)=={"title","client","owner","urgent","emergency","notes","attachments","category"}
            and isinstance(template["title"],str) and bool(template["title"].strip()) and len(template["title"])<=180
            and all(isinstance(template[key],str) for key in ("client","owner","notes","category"))
            and type(template["urgent"]) is bool and type(template["emergency"]) is bool
            and valid_attachments(template["attachments"]))


def valid_categories(categories):
    return (isinstance(categories,list) and len(categories)<=50
            and all(isinstance(name,str) and name.strip()==name and 0<len(name)<=80
                    and name.casefold() not in {"sans catégorie","toutes les catégories"} for name in categories)
            and len({name.casefold() for name in categories})==len(categories))


def board_settings(board):
    settings = {"version": 0, "title": "Tableau du bureau", "users": ["Alain", "Secrétaire"], "backup_days": 7, "user_colors": {}, "categories": []}
    settings.update(copy.deepcopy(board.get("settings", {})))
    return settings


def replace_with_retry(source, destination):
    deadline = time.monotonic() + 3.0
    while True:
        try:
            os.replace(source, destination)
            return
        except PermissionError:
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.10)


class StorageError(Exception):
    pass


class ConflictError(StorageError):
    pass


def timestamp():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def validate_board(board):
    if not isinstance(board, dict) or board.get("schema") != 1:
        raise StorageError("Ce fichier n’est pas un tableau compatible. Il n’a pas été modifié.")
    if type(board.get("revision")) is not int or board["revision"] < 0 or not isinstance(board.get("tasks"), list):
        raise StorageError("Le tableau est incomplet. Il n’a pas été modifié.")
    if "settings" in board:
        settings = board["settings"]
        if (not isinstance(settings, dict) or type(settings.get("version")) is not int
                or settings["version"] < 0 or not isinstance(settings.get("title"), str)
                or not settings["title"].strip() or len(settings["title"]) > 80
                or not isinstance(settings.get("users"), list) or not 1 <= len(settings["users"]) <= 30
                or type(settings.get("backup_days", 7)) is not int or not 0 <= settings.get("backup_days", 7) <= 365
                or any(not isinstance(name, str) or not name.strip() or len(name) > 60 for name in settings["users"])
                or len({name.casefold() for name in settings["users"]}) != len(settings["users"])):
            raise StorageError("La configuration du tableau est incorrecte. Le fichier n’a pas été modifié.")
        if not valid_user_colors(settings.get("user_colors", {})):
            raise StorageError("Une couleur de badge est incorrecte. Le fichier n’a pas été modifié.")
        if not valid_categories(settings.get("categories", [])):
            raise StorageError("La liste des catégories est incorrecte. Le fichier n’a pas été modifié.")
    recurrences=board.get("recurrences",{})
    if (not isinstance(recurrences,dict) or len(recurrences)>1000
            or any(not isinstance(ident,str) or not ident or not valid_recurrence_series(series)
                   for ident,series in recurrences.items())):
        raise StorageError("Les tâches récurrentes du tableau sont incorrectes.")
    seen = set()
    for task in board["tasks"]:
        if not isinstance(task, dict):
            raise StorageError("Une tâche est illisible. Le tableau n’a pas été modifié.")
        ident = task.get("id")
        if not isinstance(ident, str) or not ident or ident in seen:
            raise StorageError("Une tâche a un identifiant incorrect ou en double.")
        seen.add(ident)
        if task.get("status") not in STATUSES or type(task.get("version")) is not int or task["version"] < 1:
            raise StorageError("Une tâche contient un état ou une version incorrecte.")
        for key in ("title", "client", "owner", "notes", "due", "original_due", "created", "updated"):
            if not isinstance(task.get(key), str):
                raise StorageError("Une tâche contient un champ incorrect.")
        if not task["title"].strip() or type(task.get("urgent")) is not bool:
            raise StorageError("Une tâche contient un titre ou une priorité incorrecte.")
        if type(task.get("emergency",False)) is not bool:
            raise StorageError("Une tâche contient une urgence incorrecte.")
        recurrence_id=task.get("recurrence_id","")
        if not isinstance(recurrence_id,str) or (recurrence_id and recurrence_id not in recurrences):
            raise StorageError("Une tâche récurrente est incorrecte.")
        if not valid_attachments(task.get("attachments", [])):
            raise StorageError("Une tâche contient un lien de fichier ou de dossier incorrect.")
        category=task.get("category", "")
        if not isinstance(category,str) or len(category)>80 or category.strip()!=category:
            raise StorageError("Une tâche contient une catégorie incorrecte.")
        if type(task.get("deleted")) is not bool or not isinstance(task.get("history"), list):
            raise StorageError("L’historique d’une tâche est incorrect.")
        if any(not isinstance(h,dict) or not isinstance(h.get("at"),str) or not isinstance(h.get("text"),str) for h in task["history"]):
            raise StorageError("L’historique d’une tâche est illisible.")
        for key in ("due", "original_due"):
            if task[key]:
                try:
                    date.fromisoformat(task[key])
                except ValueError:
                    raise StorageError("Une tâche contient une date incorrecte.") from None
    return board


class BoardRepository:
    filename = "tableau.json"

    def __init__(self, folder, timeout=3.0):
        self.folder = Path(folder)
        self.path = self.folder / self.filename
        self.timeout = timeout

    @contextmanager
    def locked(self):
        if not self.folder.is_dir():
            raise StorageError("Le dossier du tableau est inaccessible. Vérifiez la connexion au réseau.")
        handle = None
        acquired = False
        try:
            fd = os.open(self.folder / ".tableau.lock", os.O_CREAT | os.O_RDWR)
            handle = os.fdopen(fd, "r+b", buffering=0)
            deadline = time.monotonic() + self.timeout
            while True:
                try:
                    handle.seek(0)
                    if os.name == "nt":
                        import msvcrt
                        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = True
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise StorageError("Le tableau est occupé sur l’autre poste. Réessayez dans quelques secondes.") from None
                    time.sleep(0.04)
            yield
        except OSError as exc:
            raise StorageError("Impossible d’accéder au dossier. Vérifiez le réseau et les droits d’écriture.") from exc
        finally:
            if handle is not None:
                if acquired:
                    try:
                        handle.seek(0)
                        if os.name == "nt":
                            import msvcrt
                            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                        else:
                            import fcntl
                            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                    except OSError:
                        pass
                handle.close()

    def _read(self):
        try:
            return validate_board(json.loads(self.path.read_text(encoding="utf-8")))
        except (ValueError, UnicodeError) as exc:
            raise StorageError("Le fichier du tableau est illisible. Il n’a pas été remplacé. Une sauvegarde peut être récupérée.") from exc
        except FileNotFoundError as exc:
            raise StorageError("Le fichier du tableau est introuvable. Vérifiez le dossier sélectionné.") from exc

    def _write(self, board, backup=True):
        validate_board(board)
        if backup and self.path.exists():
            backup_dir = self.folder / "Sauvegardes"
            backup_dir.mkdir(exist_ok=True)
            prior = self.path.read_bytes()
            name = f"tableau_{datetime.now():%Y%m%d_%H%M%S_%f}_{uuid.uuid4().hex[:8]}.json"
            with (backup_dir / name).open("xb") as stream:
                stream.write(prior)
                stream.flush()
                os.fsync(stream.fileno())
        temp = self.folder / f".tableau-{uuid.uuid4().hex}.tmp"
        try:
            with temp.open("x", encoding="utf-8", newline="\n") as stream:
                json.dump(board, stream, ensure_ascii=False, indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            # SMB may keep a just-closed handle briefly while releasing a lease.
            # Retry only the atomic replacement, still under the same board lock;
            # never repeat the whole mutation or drop the last good file.
            replace_with_retry(temp, self.path)
        finally:
            temp.unlink(missing_ok=True)
        if backup:
            try:
                for old in sorted((self.folder / "Sauvegardes").glob("tableau_*.json"), key=lambda p:p.name, reverse=True)[30:]:
                    old.unlink(missing_ok=True)
            except OSError:
                pass  # Retention failure must not turn an already-saved edit into a retry.

    def initialize(self, existing_only=False):
        with self.locked():
            if self.path.exists():
                return self._read()
            if existing_only:
                raise StorageError("Ce dossier ne contient pas de tableau. Choisissez le dossier déjà utilisé sur l’autre poste.")
            board = {"schema": 1, "revision": 0, "tasks": [], "recurrences": {}, "settings": board_settings({})}
            self._write(board, backup=False)
            return board

    def read(self):
        with self.locked():
            return self._read()

    def configure(self, title, users, version, backup_days=7, user_colors=None, categories=None):
        title = title.strip()
        users = [name.strip() for name in users if name.strip()]
        if not title or len(title) > 80:
            raise StorageError("Donnez un nom au tableau (80 caractères maximum).")
        if not 1 <= len(users) <= 30 or any(len(name) > 60 for name in users):
            raise StorageError("Indiquez entre 1 et 30 prénoms, de 60 caractères maximum.")
        if len({name.casefold() for name in users}) != len(users) or any(name.casefold() in {"tout le monde", "à attribuer"} for name in users):
            raise StorageError("Utilisez un prénom différent pour chaque personne.")
        if type(backup_days) is not int or not 0 <= backup_days <= 365:
            raise StorageError("Choisissez un délai de sauvegarde entre 1 et 365 jours.")
        if user_colors is not None and not valid_user_colors(user_colors):
            raise StorageError("Choisissez une couleur valide pour chaque badge.")
        if categories is not None:
            if not isinstance(categories,list):
                raise StorageError("Indiquez une catégorie par ligne.")
            categories=[name.strip() if isinstance(name,str) else name for name in categories
                        if not isinstance(name,str) or name.strip()]
            if not valid_categories(categories):
                raise StorageError("Indiquez jusqu’à 50 catégories différentes (80 caractères maximum). « Sans catégorie » et « Toutes les catégories » sont réservés aux filtres.")
        with self.locked():
            board = self._read()
            previous = board_settings(board)
            if previous["version"] != version:
                raise ConflictError("La configuration a changé sur l’autre poste. Fermez puis rouvrez la configuration avant de réessayer.")
            colors=previous["user_colors"] if user_colors is None else copy.deepcopy(user_colors)
            category_names=previous["categories"] if categories is None else categories
            if (previous["title"] == title and previous["users"] == users and previous["backup_days"] == backup_days
                    and previous["user_colors"] == colors and previous["categories"] == category_names):
                return board
            board["settings"] = {**previous,"version": version + 1, "title": title, "users": users,
                                 "backup_days": backup_days, "user_colors": colors, "categories": copy.deepcopy(category_names)}
            board["revision"] += 1
            self._write(board)
            return board

    def backup_on_open(self):
        """One periodic copy per interval, shared by all clients, under the board lock."""
        with self.locked():
            board = self._read()
            days = board_settings(board)["backup_days"]
            if not days:
                return None
            directory = self.folder / "Sauvegardes periodiques"
            directory.mkdir(exist_ok=True)
            copies = sorted(directory.glob("tableau_*.json"), key=lambda p:p.name, reverse=True)
            for previous in copies:
                try:
                    saved_day = datetime.strptime(previous.name.split("_")[1], "%Y%m%d").date()
                except (ValueError, IndexError):
                    continue
                if (date.today() - saved_day).days < days:
                    return None
                break
            destination = directory / f"tableau_{datetime.now():%Y%m%d_%H%M%S_%f}_{uuid.uuid4().hex[:8]}.json"
            temporary = directory / ("." + destination.name + ".tmp")
            try:
                with temporary.open("xb") as stream:
                    stream.write(self.path.read_bytes())
                    stream.flush()
                    os.fsync(stream.fileno())
                replace_with_retry(temporary, destination)
            finally:
                temporary.unlink(missing_ok=True)
            for previous in copies[29:]:
                try:
                    previous.unlink(missing_ok=True)
                except OSError:
                    pass
            return destination

    def create(self, fields):
        recurrence=fields.get("recurrence")
        if recurrence is not None and (not valid_recurrence_spec(recurrence) or not fields.get("due")):
            raise StorageError("Une tâche récurrente doit avoir une date et une répétition valide.")
        with self.locked():
            board = self._read()
            board.setdefault("recurrences",{})
            task=new_task(fields)
            if recurrence:
                recurrence_id=uuid.uuid4().hex
                task["recurrence_id"]=recurrence_id
                due=date.fromisoformat(task["due"])
                board["recurrences"][recurrence_id]={**copy.deepcopy(recurrence),"active":True,
                    "next_due":recurrence_date(task["due"],recurrence["unit"],recurrence["interval"],due.day)
                        if recurrence["mode"]=="calendar" else "",
                    "anchor_day":due.day,"current_task_id":task["id"],"template":recurrence_template(task)}
            board["tasks"].append(task)
            board["revision"] += 1
            self._write(board)
            return board

    def update(self, ident, version, changes, note="", today=None):
        allowed = {"title", "client", "owner", "urgent", "emergency", "due", "notes", "status", "deleted", "attachments", "category", "recurrence"}
        if changes.keys() - allowed:
            raise StorageError("Modification non reconnue.")
        changes=copy.deepcopy(changes)
        recurrence_marker=object()
        recurrence=changes.pop("recurrence",recurrence_marker)
        if recurrence is not recurrence_marker and recurrence is not None and not valid_recurrence_spec(recurrence):
            raise StorageError("La répétition choisie est incorrecte.")
        with self.locked():
            board = self._read()
            board.setdefault("recurrences",{})
            task = next((x for x in board["tasks"] if x["id"] == ident), None)
            if task is None or task["version"] != version:
                raise ConflictError("Cette tâche a changé sur l’autre poste. Votre saisie est conservée ; relisez la dernière version avant de réessayer.")
            if task["deleted"] and changes.get("deleted") is not False:
                raise ConflictError("Cette tâche est dans la corbeille. Actualisez le tableau.")
            changed = {k:v for k,v in changes.items() if task.get(k) != v}
            current_series=board["recurrences"].get(task.get("recurrence_id",""))
            current_recurrence=({key:current_series[key] for key in ("mode","unit","interval")}
                                if current_series and current_series["active"]
                                and current_series["current_task_id"]==task["id"] else None)
            if recurrence is not recurrence_marker and recurrence==current_recurrence:
                recurrence=recurrence_marker
            recurrence_changed=recurrence is not recurrence_marker
            if recurrence_changed and recurrence is not None and not (changed.get("due",task["due"])):
                raise StorageError("Une tâche récurrente doit avoir une date prévue.")
            if not changed and not recurrence_changed:
                return board
            old_due = task["due"]
            task.update(changed)
            if "due" in changed and not task["original_due"] and task["due"]:
                task["original_due"] = task["due"]
            if recurrence_changed:
                previous=board["recurrences"].get(task.get("recurrence_id",""))
                if previous:previous["active"]=False
                if recurrence is None:
                    task["recurrence_id"]=""
                else:
                    recurrence_id=task.get("recurrence_id") or uuid.uuid4().hex
                    task["recurrence_id"]=recurrence_id
                    due=date.fromisoformat(task["due"])
                    board["recurrences"][recurrence_id]={**copy.deepcopy(recurrence),"active":True,
                        "next_due":recurrence_date(task["due"],recurrence["unit"],recurrence["interval"],due.day)
                            if recurrence["mode"]=="calendar" else "",
                        "anchor_day":due.day,"current_task_id":task["id"],"template":recurrence_template(task)}
            series=board["recurrences"].get(task.get("recurrence_id",""))
            if series and series["active"] and series["current_task_id"]==task["id"]:
                series["template"]=recurrence_template(task)
                if "due" in changed and task["due"]:
                    due=date.fromisoformat(task["due"])
                    series["anchor_day"]=due.day
                    series["next_due"]=(recurrence_date(task["due"],series["unit"],series["interval"],due.day)
                                        if series["mode"]=="calendar" else "")
            task["version"] += 1
            task["updated"] = timestamp()
            if "deleted" in changed:
                text = "Déplacée dans la corbeille" if task["deleted"] else "Restaurée depuis la corbeille"
            elif "status" in changed:
                text = "Passée dans « " + STATUS_LABELS[task["status"]] + " »"
            elif "due" in changed:
                text = "Date modifiée : " + (old_due or "sans date") + " → " + (task["due"] or "sans date")
            elif "emergency" in changed:
                text = "Urgence activée" if task["emergency"] else "Urgence retirée"
            elif "attachments" in changed:
                text = "Liens de fichiers et dossiers modifiés"
            elif "category" in changed:
                text = "Catégorie : " + task["category"] if task["category"] else "Catégorie retirée"
            elif recurrence_changed:
                text = "Récurrence modifiée" if recurrence is not None else "Récurrence arrêtée"
            else:
                text = "Tâche modifiée"
            if note.strip():
                text += ". " + note.strip()
            task["history"].append({"at": task["updated"], "text": text})
            if (series and series["active"] and series["mode"]=="completion"
                    and series["current_task_id"]==task["id"] and task["status"]=="done"
                    and changed.get("status")=="done"):
                current_day=today or date.today()
                fields={**copy.deepcopy(series["template"]),"status":"todo",
                    "due":recurrence_date(current_day.isoformat(),series["unit"],series["interval"],current_day.day)}
                following=new_task(fields)
                following["recurrence_id"]=task["recurrence_id"]
                board["tasks"].append(following)
                series["current_task_id"]=following["id"]
                series["template"]=recurrence_template(following)
            board["revision"] += 1
            self._write(board)
            return board

    def generate_recurrences(self, today=None):
        current_day=today or date.today()
        with self.locked():
            board=self._read()
            board.setdefault("recurrences",{})
            generated=False
            for recurrence_id,series in board["recurrences"].items():
                if not series["active"] or series["mode"]!="calendar":continue
                due=series["next_due"]
                if date.fromisoformat(due)>current_day:continue
                while True:
                    following=recurrence_date(due,series["unit"],series["interval"],series["anchor_day"])
                    if date.fromisoformat(following)>current_day:break
                    due=following
                fields={**copy.deepcopy(series["template"]),"status":"todo","due":due}
                task=new_task(fields)
                task["recurrence_id"]=recurrence_id
                board["tasks"].append(task)
                series["current_task_id"]=task["id"]
                series["template"]=recurrence_template(task)
                series["next_due"]=recurrence_date(due,series["unit"],series["interval"],series["anchor_day"])
                generated=True
            if generated:
                board["revision"]+=1
                self._write(board)
            return board

    def purge_deleted(self):
        with self.locked():
            board=self._read()
            removed=[task for task in board["tasks"] if task["deleted"]]
            if not removed:return board
            board["tasks"]=[task for task in board["tasks"] if not task["deleted"]]
            board.setdefault("recurrences",{})
            for recurrence_id in list(board["recurrences"]):
                remaining=[task for task in board["tasks"] if task.get("recurrence_id")==recurrence_id]
                if not remaining:
                    del board["recurrences"][recurrence_id]
                    continue
                series=board["recurrences"][recurrence_id]
                if series["current_task_id"] not in {task["id"] for task in remaining}:
                    current=max(remaining,key=lambda task:(task["due"] or "",task["created"]))
                    series["current_task_id"]=current["id"]
                    series["template"]=recurrence_template(current)
            board["revision"]+=1
            self._write(board)
            return board


def new_task(fields):
    now = timestamp()
    return {"id": uuid.uuid4().hex, "version": 1, "title": fields.get("title", "").strip(),
            "client": fields.get("client", "").strip(), "owner": fields.get("owner", "").strip(),
            "urgent": bool(fields.get("urgent", False)), "emergency": bool(fields.get("emergency",False)), "status": fields.get("status", "todo"),
            "due": fields.get("due", ""), "original_due": fields.get("due", ""),
            "notes": fields.get("notes", "").strip(), "deleted": False,
            "attachments": copy.deepcopy(fields.get("attachments", [])),
            "category": fields.get("category", ""),
            "recurrence_id": fields.get("recurrence_id", ""),
            "created": now, "updated": now, "history": [{"at": now, "text": "Tâche créée"}]}

