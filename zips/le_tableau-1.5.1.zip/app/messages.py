"""Explicit French button labels, independent of the Qt language pack."""
from PySide6.QtWidgets import QMessageBox


def confirm(parent,title,text,accept_text,cancel_text="Annuler",default_accept=False):
    dialog=QMessageBox(QMessageBox.Icon.Question,title,text,parent=parent)
    accept=dialog.addButton(accept_text,QMessageBox.ButtonRole.AcceptRole)
    cancel=dialog.addButton(cancel_text,QMessageBox.ButtonRole.RejectRole)
    dialog.setDefaultButton(accept if default_accept else cancel)
    dialog.setEscapeButton(cancel)
    dialog.exec()
    return dialog.clickedButton() is accept


def information(parent,title,text):
    dialog=QMessageBox(QMessageBox.Icon.Information,title,text,parent=parent)
    close=dialog.addButton("Fermer",QMessageBox.ButtonRole.AcceptRole)
    dialog.setDefaultButton(close)
    dialog.exec()
