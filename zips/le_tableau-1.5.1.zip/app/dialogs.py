from __future__ import annotations
import copy
import ntpath
from datetime import date
from html import escape
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtWidgets import (QApplication,QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,
    QDateEdit,QCheckBox,QTextEdit,QPushButton,QTextBrowser,QListWidget,QListWidgetItem,
    QFileDialog,QStyle,QWidget,QTabWidget,QSpinBox)
from .storage import STATUS_LABELS, STATUSES
from .widgets import pretty_date
from .attachments import file_reference
from .messages import confirm


def label(text):
    w=QLabel(text)
    w.setObjectName("muted")
    return w


class TaskDialog(QDialog):
    saveRequested=Signal(object,object,str)
    openAttachmentRequested=Signal(object)

    def __init__(self,task=None,owners=None,status="todo",parent=None,categories=None):
        super().__init__(parent)
        self.task=copy.deepcopy(task)
        self.saving=False
        self.report_note=""
        self.attachments=copy.deepcopy(task.get("attachments", [])) if task else []
        self.setWindowTitle("La tâche" if task else "Nouvelle tâche")
        self.setMinimumWidth(600)
        screen=self.screen().availableGeometry()
        self.resize(680,min(700,screen.height()-60))
        outer=QVBoxLayout(self)
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(0)
        header=QWidget()
        header_row=QHBoxLayout(header)
        header_row.setContentsMargins(22,16,22,12)
        title=QLabel("La tâche" if task else "Nouvelle tâche")
        title.setObjectName("title")
        header_row.addWidget(title)
        header_row.addStretch()
        self.urgent=QCheckBox("Urgent")
        self.urgent.setChecked(bool(task and (task["urgent"] or task.get("emergency",False))))
        header_row.addWidget(self.urgent)
        self.recurring=QCheckBox("Récurrente")
        recurrence=task.get("recurrence") if task else None
        self.recurring.setChecked(bool(recurrence))
        header_row.addWidget(self.recurring)
        outer.addWidget(header)
        self.tabs=QTabWidget()
        outer.addWidget(self.tabs,1)
        content=QWidget()
        files=QWidget()
        self.tabs.addTab(content,"Tâche")
        self.tabs.addTab(files,"Fichiers et historique")
        box=QVBoxLayout(content)
        box.setContentsMargins(22,4,22,8)
        box.setSpacing(10)
        self.error=QLabel()
        self.error.setObjectName("error")
        self.error.setWordWrap(True)
        self.error.hide()
        group=QVBoxLayout()
        group.setSpacing(6)
        group.addWidget(label("Qu’y a-t-il à faire ?"))
        self.title_edit=QLineEdit(task["title"] if task else "")
        self.title_edit.setObjectName("taskTitleInput")
        self.title_edit.setMaxLength(180)
        group.addWidget(self.title_edit)
        box.addLayout(group)
        self.category=QComboBox()
        self.category.setToolTip("La liste des catégories se règle dans Configuration > Le tableau commun.")
        self.category.addItem("Sans catégorie", "")
        category_names=list(categories or [])
        current_category=task.get("category", "") if task else ""
        if current_category and current_category not in category_names:
            category_names.append(current_category)
        for name in category_names:self.category.addItem(name,name)
        self.category.setCurrentIndex(max(0,self.category.findData(current_category)))
        row=QHBoxLayout()
        col=QVBoxLayout()
        col.setSpacing(6)
        col.addWidget(label("Qui s’en occupe ?"))
        self.owner=QComboBox()
        self.owner.setEditable(True)
        self.owner.addItems(list(dict.fromkeys(["À attribuer",*(owners or ["Alain","Secrétaire"])])))
        self.owner.setCurrentText(task["owner"] or "À attribuer" if task else "À attribuer")
        self.owner.lineEdit().setMaxLength(60)
        col.addWidget(self.owner)
        row.addLayout(col,1)
        col=QVBoxLayout()
        col.setSpacing(6)
        col.addWidget(label("Où en est-on ?"))
        self.status=QComboBox()
        for s in STATUSES:self.status.addItem(STATUS_LABELS[s],s)
        self.status.setCurrentIndex(STATUSES.index(task["status"] if task else status))
        col.addWidget(self.status)
        row.addLayout(col,1)
        box.addLayout(row)
        col=QVBoxLayout()
        col.setSpacing(6)
        col.addWidget(label("Catégorie · facultatif"))
        col.addWidget(self.category)
        box.addLayout(col)
        row=QHBoxLayout()
        row.setSpacing(16)
        row.setContentsMargins(0,3,0,3)
        self.has_date=QCheckBox("Date prévue")
        self.has_date.setChecked(bool(task and task["due"]))
        row.addWidget(self.has_date)
        self.due=QDateEdit()
        self.due.setCalendarPopup(True)
        self.due.setDisplayFormat("dddd d MMMM yyyy")
        self.due.setMinimumDate(QDate(2000,1,1))
        self.due.setMaximumDate(QDate(2100,12,31))
        self.due.setDate(QDate.fromString(task["due"],"yyyy-MM-dd") if task and task["due"] else QDate.currentDate())
        self.has_date.toggled.connect(self.due.setEnabled)
        self.due.setEnabled(self.has_date.isChecked())
        row.addWidget(self.due,1)
        box.addLayout(row)
        self.recurrence_controls=QWidget()
        recurrence_row=QHBoxLayout(self.recurrence_controls)
        recurrence_row.setContentsMargins(0,0,0,0)
        recurrence_row.addWidget(label("Répéter"))
        self.recurrence_interval=QSpinBox()
        self.recurrence_interval.setRange(1,365)
        self.recurrence_interval.setValue(recurrence.get("interval",1) if recurrence else 1)
        recurrence_row.addWidget(self.recurrence_interval)
        self.recurrence_unit=QComboBox()
        for text,value in (("jour(s)","day"),("semaine(s)","week"),("mois","month")):
            self.recurrence_unit.addItem(text,value)
        self.recurrence_unit.setCurrentIndex(max(0,self.recurrence_unit.findData(recurrence.get("unit") if recurrence else "week")))
        recurrence_row.addWidget(self.recurrence_unit)
        self.recurrence_mode=QComboBox()
        self.recurrence_mode.addItem("à date fixe","calendar")
        self.recurrence_mode.addItem("après achèvement","completion")
        self.recurrence_mode.setCurrentIndex(max(0,self.recurrence_mode.findData(recurrence.get("mode") if recurrence else "calendar")))
        recurrence_row.addWidget(self.recurrence_mode,1)
        self.recurrence_controls.setVisible(self.recurring.isChecked())
        self.recurring.toggled.connect(self.recurrence_controls.setVisible)
        self.recurring.toggled.connect(lambda checked:self.has_date.setChecked(True) if checked else None)
        box.addWidget(self.recurrence_controls)
        group=QVBoxLayout()
        group.setSpacing(6)
        group.addWidget(label("Une précision ?"))
        self.notes=QTextEdit()
        self.notes.setAcceptRichText(False)
        self.notes.setPlainText(task["notes"] if task else "")
        self.notes.setMinimumHeight(70)
        group.addWidget(self.notes,1)
        box.addLayout(group,3)
        box=QVBoxLayout(files)
        box.setContentsMargins(22,10,22,8)
        box.setSpacing(10)
        group=QVBoxLayout()
        group.setSpacing(6)
        group.addWidget(label("Fichiers et dossiers liés · facultatif"))
        self.attachment_list=QListWidget()
        self.attachment_list.setObjectName("attachmentList")
        self.attachment_list.setMinimumHeight(64)
        self.attachment_list.itemDoubleClicked.connect(lambda item:self.open_attachment())
        group.addWidget(self.attachment_list,1)
        self.attachment_buttons=QWidget()
        row=QHBoxLayout(self.attachment_buttons)
        row.setContentsMargins(0,0,0,0)
        self.add_files_button=QPushButton("＋ Fichier(s)")
        self.add_files_button.clicked.connect(self.choose_files)
        row.addWidget(self.add_files_button)
        self.add_folder_button=QPushButton("＋ Dossier")
        self.add_folder_button.clicked.connect(self.choose_directory)
        row.addWidget(self.add_folder_button)
        self.open_attachment_button=QPushButton("Ouvrir")
        self.open_attachment_button.clicked.connect(self.open_attachment)
        row.addWidget(self.open_attachment_button)
        self.remove_attachment_button=QPushButton("Retirer le lien")
        self.remove_attachment_button.clicked.connect(self.remove_attachment)
        row.addWidget(self.remove_attachment_button)
        group.addWidget(self.attachment_buttons)
        box.addLayout(group,4)
        self.local_attachment_hint=label("Un lien local est présent : il peut être inaccessible depuis l’autre PC.")
        self.local_attachment_hint.setWordWrap(True)
        box.addWidget(self.local_attachment_hint)
        self.attachment_list.itemSelectionChanged.connect(self.attachment_selection_changed)
        self.refresh_attachments()
        self.history=QTextBrowser()
        self.history.setMaximumHeight(110)
        self.history.setOpenExternalLinks(False)
        self.history.hide()
        if task:
            row=QHBoxLayout()
            report=QPushButton("Reporter…")
            report.setObjectName("quiet")
            report.clicked.connect(self.report)
            row.addWidget(report)
            history=QPushButton("Voir l’historique")
            history.setObjectName("quiet")
            history.clicked.connect(lambda:self.history.setVisible(not self.history.isVisible()))
            row.addWidget(history)
            row.addStretch()
            box.addLayout(row)
            lines=[]
            for h in reversed(task["history"]):
                lines.append(f'<p><span style="color:#8b93a7">{escape(h.get("at","")[:16].replace("T"," à "))}</span><br>{escape(h.get("text",""))}</p>')
            self.history.setHtml("".join(lines))
            box.addWidget(self.history)
        self.copy_button=QPushButton("Copier")
        self.copy_button.setToolTip("Copier ma saisie pour la conserver")
        self.copy_button.setObjectName("quiet")
        self.copy_button.hide()
        self.copy_button.clicked.connect(lambda:QApplication.clipboard().setText(self.copy_text()))
        footer=QWidget()
        footer_layout=QVBoxLayout(footer)
        footer_layout.setContentsMargins(22,8,22,14)
        footer_layout.setSpacing(8)
        buttons=QHBoxLayout()
        message_area=QWidget()
        message_layout=QHBoxLayout(message_area)
        message_layout.setContentsMargins(0,0,0,0)
        message_layout.addWidget(self.error,1)
        message_layout.addWidget(self.copy_button)
        buttons.addWidget(message_area,1)
        self.cancel=QPushButton("Fermer" if task else "Annuler")
        self.cancel.clicked.connect(self.reject)
        buttons.addWidget(self.cancel)
        self.save_button=QPushButton("Enregistrer" if task else "Ajouter la tâche")
        self.save_button.setObjectName("primary")
        self.save_button.clicked.connect(self.submit)
        buttons.addWidget(self.save_button)
        for button in (self.cancel,self.save_button):button.setFixedSize(152,42)
        footer_layout.addLayout(buttons)
        outer.addWidget(footer)
        self.initial=self.fields()
        self.title_edit.setFocus()

    def fields(self):
        owner=self.owner.currentText().strip()
        recurrence=(dict(mode=self.recurrence_mode.currentData(),unit=self.recurrence_unit.currentData(),
                         interval=self.recurrence_interval.value()) if self.recurring.isChecked() else None)
        return dict(title=self.title_edit.text().strip(),client=self.task.get("client","") if self.task else "",
                    owner="" if owner=="À attribuer" else owner,urgent=self.urgent.isChecked(),emergency=self.urgent.isChecked(),
                    status=self.status.currentData(),due=self.due.date().toString("yyyy-MM-dd") if self.has_date.isChecked() else "",
                    notes=self.notes.toPlainText().strip(),attachments=copy.deepcopy(self.attachments),
                    category=self.category.currentData() or "",recurrence=recurrence)

    def copy_text(self):
        f=self.fields()
        return "\n".join([f["title"],f["client"],f["owner"],f["category"],pretty_date(f["due"]),f["notes"],
                          *[item["path"] for item in self.attachments],self.report_note])

    def choose_files(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Rattacher des fichiers existants",self.attachment_start_folder())
        self.add_references(paths,"file")

    def choose_directory(self):
        path=QFileDialog.getExistingDirectory(self,"Rattacher un dossier existant",self.attachment_start_folder())
        if path:self.add_references([path],"folder")

    def attachment_start_folder(self):
        if self.attachments:
            return ntpath.dirname(self.attachments[-1]["path"])
        parent=self.parentWidget()
        return str(parent.repo.folder) if getattr(parent,"repo",None) else ""

    def add_references(self,paths,kind):
        existing={ntpath.normcase(item["path"]) for item in self.attachments}
        try:
            for path in paths:
                item=file_reference(path,kind)
                key=ntpath.normcase(item["path"])
                if key not in existing:
                    self.attachments.append(item)
                    existing.add(key)
        except (OSError,ValueError) as exc:
            self.attachment_error(str(exc))
        self.refresh_attachments()
        if self.attachments:self.attachment_list.setCurrentRow(len(self.attachments)-1)

    def refresh_attachments(self):
        self.attachment_list.clear()
        for item in self.attachments:
            row=QListWidgetItem(item["name"])
            row.setToolTip(item["path"])
            icon=QStyle.StandardPixmap.SP_DirIcon if item["kind"]=="folder" else QStyle.StandardPixmap.SP_FileIcon
            row.setIcon(self.style().standardIcon(icon))
            self.attachment_list.addItem(row)
        self.local_attachment_hint.setVisible(any(not item["path"].startswith("\\\\") for item in self.attachments))
        self.attachment_selection_changed()

    def attachment_selection_changed(self):
        selected=self.attachment_list.currentRow()>=0
        self.open_attachment_button.setEnabled(selected)
        self.remove_attachment_button.setEnabled(selected)

    def open_attachment(self):
        index=self.attachment_list.currentRow()
        if index>=0:self.openAttachmentRequested.emit(copy.deepcopy(self.attachments[index]))

    def remove_attachment(self):
        index=self.attachment_list.currentRow()
        if index>=0:
            del self.attachments[index]
            self.refresh_attachments()
            self.attachment_list.setCurrentRow(min(index,len(self.attachments)-1))

    def attachment_error(self,message):
        self.error.setText(message)
        self.error.show()

    def submit(self):
        fields=self.fields()
        if not fields["title"]:
            self.show_error("Donnez un titre à cette tâche.")
            self.title_edit.setFocus()
            return
        if fields["recurrence"] and not fields["due"]:
            self.show_error("Choisissez une date prévue pour cette tâche récurrente.")
            self.tabs.setCurrentIndex(0)
            return
        if self.task and fields["due"] and self.task["due"] and fields["due"]>self.task["due"] and not self.report_note:
            if not self.report():return
            fields=self.fields()
        self.set_saving(True)
        self.saveRequested.emit(self.task,fields,self.report_note)

    def set_saving(self,busy):
        self.saving=busy
        self.save_button.setEnabled(not busy)
        self.cancel.setEnabled(not busy)
        self.attachment_buttons.setEnabled(not busy)
        self.attachment_list.setEnabled(not busy)
        self.save_button.setText("Enregistrement…" if busy else ("Enregistrer" if self.task else "Ajouter la tâche"))

    def show_error(self,text):
        self.set_saving(False)
        self.error.setText(text)
        self.error.show()
        self.copy_button.setVisible(bool(self.title_edit.text()))

    def report(self):
        dialog=QDialog(self)
        dialog.setWindowTitle("Reporter la tâche")
        dialog.setMinimumWidth(440)
        box=QVBoxLayout(dialog)
        box.setContentsMargins(24,24,24,24)
        box.setSpacing(12)
        title=QLabel("Reporter la tâche")
        title.setObjectName("title")
        box.addWidget(title)
        box.addWidget(label("Nouvelle date"))
        due=QDateEdit(self.due.date())
        due.setCalendarPopup(True)
        due.setDisplayFormat("dddd d MMMM yyyy")
        minimum=QDate.currentDate()
        if self.task and self.task["due"]:
            minimum=max(minimum,QDate.fromString(self.task["due"],"yyyy-MM-dd").addDays(1))
        due.setMinimumDate(minimum)
        due.setMaximumDate(QDate(2100,12,31))
        if due.date()<minimum:due.setDate(minimum)
        box.addWidget(due)
        box.addWidget(label("Pourquoi ce report ?"))
        reason=QLineEdit()
        reason.setMaxLength(250)
        box.addWidget(reason)
        error=QLabel()
        error.setObjectName("error")
        error.hide()
        box.addWidget(error)
        row=QHBoxLayout()
        cancel=QPushButton("Annuler")
        cancel.clicked.connect(dialog.reject)
        ok=QPushButton("Valider le report")
        ok.setObjectName("primary")
        def accept():
            if not reason.text().strip():
                error.setText("Indiquez une courte raison pour garder une trace.")
                error.show()
                return
            dialog.accept()
        ok.clicked.connect(accept)
        row.addStretch()
        row.addWidget(cancel)
        row.addWidget(ok)
        box.addLayout(row)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return False
        self.has_date.setChecked(True)
        self.due.setDate(due.date())
        self.report_note="Motif du report : "+reason.text().strip()
        return True

    def reject(self):
        if self.saving:return
        if self.fields()!=self.initial or self.report_note:
            if not confirm(self,"Modifications non enregistrées","Fermer cette fiche sans enregistrer vos modifications ?",
                           "Quitter sans enregistrer","Continuer la saisie"):return
        super().reject()


class TrashDialog(QDialog):
    restoreRequested=Signal(object)
    emptyRequested=Signal()

    def __init__(self,tasks,parent=None):
        super().__init__(parent)
        self.setWindowTitle("Corbeille")
        self.resize(600,430)
        box=QVBoxLayout(self)
        box.setContentsMargins(24,24,24,24)
        title=QLabel("La corbeille")
        title.setObjectName("title")
        box.addWidget(title)
        box.addWidget(label("Une tâche retirée par erreur peut être restaurée ici."))
        self.items=QListWidget()
        if QApplication.instance().property("tableauExtension"):
            self.items.setStyleSheet("QListWidget::item {padding:12px}")
        else:
            self.items.setStyleSheet("QListWidget {background:#1e2330;border:1px solid #2a3040;border-radius:8px} QListWidget::item {padding:12px}")
        for task in sorted(tasks,key=lambda t:t["updated"],reverse=True):
            item=QListWidgetItem(task["title"]+"\n"+(task["client"] or task["owner"]))
            item.setData(Qt.ItemDataRole.UserRole,task)
            self.items.addItem(item)
        box.addWidget(self.items,1)
        if not tasks:box.addWidget(label("La corbeille est vide."))
        row=QHBoxLayout()
        close=QPushButton("Fermer")
        close.clicked.connect(self.accept)
        self.empty_button=QPushButton("Vider la corbeille…")
        self.empty_button.setObjectName("danger")
        self.empty_button.setEnabled(bool(tasks))
        self.empty_button.clicked.connect(self.emptyRequested)
        self.restore=QPushButton("Restaurer la tâche")
        self.restore.setObjectName("primary")
        self.restore.setEnabled(False)
        self.items.currentItemChanged.connect(lambda current,previous:self.restore.setEnabled(current is not None))
        self.restore.clicked.connect(lambda:self.restoreRequested.emit(self.items.currentItem().data(Qt.ItemDataRole.UserRole)))
        row.addStretch()
        row.addWidget(self.empty_button)
        row.addWidget(close)
        row.addWidget(self.restore)
        box.addLayout(row)
