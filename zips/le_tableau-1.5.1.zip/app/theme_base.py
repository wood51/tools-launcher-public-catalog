BG = "#0f1218"
SURFACE = "#171b24"
SURFACE_2 = "#1e2330"
BORDER = "#2a3040"
TEXT = "#e6e9ef"
MUTED = "#8b93a7"
ACCENT = "#4f8cff"
SUCCESS = "#3ecf8e"
WARN = "#f5a524"
DANGER = "#f0616d"

STYLESHEET = f"""
* {{ font-family: "Segoe UI"; font-size: 10pt; color: {TEXT}; }}
QMainWindow, QWidget#root {{ background: {BG}; }}
QLabel#title {{ font-size: 18pt; font-weight: 600; }}
QLabel#subtitle, QLabel#muted {{ color: {MUTED}; }}

QFrame#card {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 10px; }}
QLabel#cardValue {{ font-size: 22pt; font-weight: 600; }}
QLabel#cardLabel {{ color: {MUTED}; font-size: 9pt; }}

QPushButton {{
    background: {SURFACE_2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 8px 16px;
}}
QPushButton:hover {{ border-color: {ACCENT}; }}
QPushButton:disabled {{ color: {MUTED}; background: {SURFACE}; border-color: {SURFACE_2}; }}
QPushButton#primary {{ background: {ACCENT}; border-color: {ACCENT}; color: white; font-weight: 600; }}
QPushButton#primary:hover {{ background: #6a9dff; }}
QPushButton#primary:disabled {{ background: {SURFACE_2}; border-color: {BORDER}; color: {MUTED}; }}
QPushButton#toggle:checked {{ background: #3a2f12; border-color: {WARN}; color: {WARN}; }}
QPushButton#link {{ background: transparent; border: none; color: {ACCENT}; padding: 2px 6px; }}
QPushButton#link:hover {{ text-decoration: underline; }}

QTableWidget {{
    background: {SURFACE}; alternate-background-color: #1a1f2a; border: 1px solid {BORDER};
    border-radius: 10px; gridline-color: transparent; outline: 0;
    selection-background-color: #25407a; selection-color: {TEXT};
}}
QTableWidget::item {{ padding: 0px 16px; border: none; }}
QTableWidget::item:selected, QTableWidget::item:selected:!active {{
    background: #2b4a8f; color: {TEXT}; border-top: 1px solid {ACCENT}; border-bottom: 1px solid {ACCENT};
}}
QTableWidget::item:hover {{ background: #232a3a; }}
QHeaderView::section {{
    background: {SURFACE_2}; color: {MUTED}; border: none; border-bottom: 1px solid {BORDER};
    padding: 10px 16px; font-weight: 600;
}}
QTableCornerButton::section {{ background: {SURFACE_2}; border: none; }}

QFrame#drop {{ background: {SURFACE}; border: 2px dashed {BORDER}; border-radius: 14px; }}
QFrame#drop[hover="true"] {{ border-color: {ACCENT}; background: #151c2c; }}

QProgressBar {{ background: {SURFACE_2}; border: none; border-radius: 2px; max-height: 4px; }}
QProgressBar::chunk {{ background: {ACCENT}; border-radius: 2px; }}

QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px 0; }}
QScrollBar::handle:vertical {{ background: {MUTED}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {ACCENT}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QMessageBox, QDialog {{ background: {SURFACE}; }}

QComboBox, QLineEdit {{
    background: {SURFACE_2}; border: 1px solid {BORDER}; border-radius: 6px; padding: 2px 8px; min-height: 22px;
    selection-background-color: #25407a;
}}
QComboBox:hover, QLineEdit:focus {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; background: transparent; width: 28px; }}
QComboBox QAbstractItemView {{
    background: {SURFACE_2}; border: 1px solid {BORDER}; selection-background-color: #25407a;
}}
QGroupBox {{ border: 1px solid {BORDER}; border-radius: 8px; margin-top: 14px; padding: 12px 8px 8px 8px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; color: {MUTED}; padding: 0 4px; }}
QTabWidget::pane {{ border: 1px solid {BORDER}; border-radius: 8px; top: -1px; }}
QTabBar::tab {{ background: transparent; color: {MUTED}; padding: 8px 16px; border: none; }}
QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {ACCENT}; }}
QToolTip {{ background: {SURFACE_2}; color: {TEXT}; border: 1px solid {BORDER}; padding: 4px; }}
"""
