# Composants et licences

Le Tableau utilise Python, PySide6, Shiboken6 et Qt. Le code spécifique de cette application et le thème fourni restent à la disposition de son utilisateur.

PySide6, Shiboken6 et les composants Qt concernés sont distribués sous les licences proposées par leurs auteurs, notamment LGPLv3 / GPLv3 et licences commerciales. Les notices et textes applicables sont fournis dans `Licences`. Les bibliothèques n’ont pas été modifiées. La distribution portable conserve les DLL séparées ; le code source de l’application et les instructions de reconstruction permettent d’utiliser une version compatible de ces bibliothèques.

Sources et informations officielles :

- PySide / Shiboken : https://code.qt.io/pyside/pyside-setup.git/ (version 6.11.0).
- Qt : https://download.qt.io/official_releases/qt/6.11/6.11.0/ (archives sources et licences).
- Python : https://www.python.org/downloads/source/ (version 3.14.2 pour cette compilation).
- PyInstaller : https://pyinstaller.org/ ; licence GPL avec exception permettant la distribution des applications empaquetées.

Cette application n’envoie pas les tâches à un service extérieur. Les tâches restent dans le dossier choisi. Les mises à jour de l’édition Tools Launcher sont gérées par le Catalogue. Les préférences et journaux restent sur le PC.
