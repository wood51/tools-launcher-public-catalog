"""Même entrée pour le Catalogue Tools Launcher et l'édition Python autonome."""
import os


def main():
    if os.environ.get("TL_EXTENSION_ID"):
        from core.api import get_api
    else:
        from tl_shim import get_api

    from run import main as run

    api = get_api("le_tableau")
    return run(api=api, launcher=bool(os.environ.get("TL_EXTENSION_ID")))


if __name__ == "__main__":
    raise SystemExit(main())
