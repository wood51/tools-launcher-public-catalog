from __future__ import annotations
import argparse
import logging
import os
from pathlib import Path
import sys


def main(api=None, launcher=False):
    parser=argparse.ArgumentParser(description="Le Tableau — tâches du bureau",add_help=False,
                                   usage="%(prog)s [-h] [--folder DOSSIER]")
    parser.add_argument("-h","--help",action="help",help="Afficher cette aide puis quitter")
    parser.add_argument("--folder",metavar="DOSSIER",help="Dossier contenant le tableau partagé")
    args=parser.parse_args()
    if getattr(sys,"frozen",False):
        from app.updates import is_installing
        if is_installing(Path(sys.executable).parent):
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,"La mise à jour est en cours. Le Tableau va se rouvrir automatiquement.","Le Tableau",0x40)
            return 0
    from PySide6.QtCore import QSettings
    from PySide6.QtWidgets import QApplication,QMessageBox
    from app.i18n import install_french_qt
    from app.theme import STYLESHEET
    from app.window import BoardWindow
    local=Path(os.environ.get("LOCALAPPDATA",Path.home()))/"LeTableau"
    log_dir=api.data_dir if api is not None else local
    log_dir.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(filename=str(log_dir/"application.log"),level=logging.ERROR,encoding="utf-8")
    def handle(exc_type,exc,trace):
        logging.error("Unhandled exception",exc_info=(exc_type,exc,trace))
        message=QMessageBox(QMessageBox.Icon.Critical,"Le Tableau","Une erreur inattendue est survenue. Fermez puis rouvrez l’application. Les données déjà enregistrées restent dans le dossier du tableau.")
        message.addButton("Fermer",QMessageBox.ButtonRole.AcceptRole)
        message.exec()
    sys.excepthook=handle
    app=QApplication(sys.argv[:1])
    install_french_qt(app)
    app.setApplicationName("Le Tableau")
    app.setOrganizationName("AtelierSimple")
    app.setStyle("Fusion")
    if api is None:
        app.setStyleSheet(STYLESHEET)
        settings=QSettings("AtelierSimple","LeTableau")
    else:
        from app.launcher import ApiSettings
        from app.launcher_theme import ExtensionTheme
        app.setProperty("tableauExtension", True)
        api.apply_theme(app)
        settings=ApiSettings(api)
        theme=ExtensionTheme(app)
        theme.refresh()
    folder=args.folder or settings.value("folder","",type=str)
    # Discard the previous prototype's demo preference, never the board data.
    if not args.folder and (settings.value("demo",False,type=bool) or
            (folder and os.path.normcase(os.path.abspath(folder))==os.path.normcase(str(local/"Demonstration")))):
        folder=""
        settings.remove("folder")
    settings.remove("demo")
    window=BoardWindow(folder or None,settings=settings,launcher=launcher)
    window.showMaximized()
    return app.exec()


if __name__=="__main__":
    raise SystemExit(main())
