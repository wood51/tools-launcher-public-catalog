@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "TL_EXTENSION_ID="
set "PYTHONPATH="
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "TABLEAU_PYTHON="
if exist ".venv\Scripts\python.exe" set "TABLEAU_PYTHON=%CD%\.venv\Scripts\python.exe"
if not defined TABLEAU_PYTHON if exist "..\..\.venv\Scripts\python.exe" set "TABLEAU_PYTHON=%CD%\..\..\.venv\Scripts\python.exe"
if not defined TABLEAU_PYTHON if defined VIRTUAL_ENV if exist "%VIRTUAL_ENV%\Scripts\python.exe" set "TABLEAU_PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if not defined TABLEAU_PYTHON for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined TABLEAU_PYTHON set "TABLEAU_PYTHON=%%P"
if not defined TABLEAU_PYTHON for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined TABLEAU_PYTHON set "TABLEAU_PYTHON=%%P"
if not defined TABLEAU_PYTHON (
    echo Python est introuvable. Demandez a votre assistant de preparer Python pour ce dossier.
    pause
    exit /b 1
)
"%TABLEAU_PYTHON%" -c "import PySide6" >nul 2>&1
if errorlevel 1 (
    echo Les dependances Python ne sont pas encore pretes.
    echo Demandez a votre assistant de preparer un environnement .venv dans ce dossier.
    echo Voir README.md, rubrique Sans le lanceur.
    pause
    exit /b 1
)
echo Le Tableau - essai autonome. Fermez la fenetre du tableau pour terminer.
"%TABLEAU_PYTHON%" main.pyw %*
set "TABLEAU_RESULT=%ERRORLEVEL%"
if not "%TABLEAU_RESULT%"=="0" (
    echo Le lancement a echoue. Copiez le message ci-dessus pour votre assistant.
    pause
)
exit /b %TABLEAU_RESULT%
