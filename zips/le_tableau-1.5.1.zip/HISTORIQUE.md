# Le Tableau — historique des évolutions

## Version 1.5.1 — 1er novembre 2026

- Carte légèrement transparente pendant son déplacement, avec un halo dans la couleur d'accent du thème.
- Au-dessus de la corbeille, le halo de la carte devient rouge et la poubelle s'illumine en rouge.
- Poubelle fermée pendant le déplacement ; les halos disparaissent au dépôt ou à l'annulation.

## Prochaine mise à jour — édition Catalogue

- Le Tableau peut être livré en extension Tools Launcher et fonctionner aussi en Python autonome.
- L'édition Catalogue suit le thème du lanceur et conserve ses préférences dans son dossier data.
- Les tableaux partagés et leurs sauvegardes gardent leur emplacement et leur format.
- Les mises à jour de l'extension passent par le Catalogue ; le lancement Windows habituel reste disponible.

## Version 1.4.1 — 21 octobre 2026

- Ajout de Quitter dans le menu, avec protection si un enregistrement ou une mise à jour est en cours.
- Vérification des retards : échéances passées, du jour, futures et absentes ; tâches terminées ou à la corbeille ; reports, filtres et passage au jour suivant.

## Version 1.4.0 — 21 octobre 2026

- Interface plus compacte : filtres, recherche et menu sur une seule ligne, les colonnes occupent davantage de hauteur.
- Menu principal bien visible pour la configuration, les mises à jour, la corbeille et l’aide.
- Choix du prénom dans Configuration → Sur ce PC.
- Création d’une tâche avec un bouton rond + centré sur la bordure inférieure de la colonne, un clic droit ou le menu principal.
- Prénom du profil affiché dans un badge à sa couleur entre la recherche et le menu.
- Suppression du grand titre, du slogan et du pied de page permanent.
- Bordures pointillées aux couleurs des colonnes, repères de couleur légèrement agrandis.
- Filtres des personnes en badges à leurs couleurs, filtre des retards orange avec avertissement.
- Suppression du point vert permanent ; message visible en cas de coupure du dossier partagé.
- Fiche compacte, avec messages à côté des boutons d’action ; défilement de secours sur les petites fenêtres.
- Catégorie à gauche du titre sur les cartes ; tirets lisibles sur les bordures des colonnes.
- Fiche aérée, case Urgent dans l’en-tête et date facultative sur sa propre ligne.
- Zones de précision et de fichiers agrandies selon l’espace disponible ; boutons de validation et d’annulation de même taille.
- Une seule case Urgent, sans champ client ni textes d’exemple ; les anciennes références restent conservées.
- Date facultative à activer, décochée par défaut pour les nouvelles tâches.
- Boutons des confirmations en français.
- Plein écran avec F11, retour avec F11 ou Échap.
- Historique des versions consultable depuis le menu.

## Version 1.3.0

- Couleur du badge de chaque personne configurable, avec aperçu.
- Catégories simples à définir dans la configuration.
- Une catégorie facultative par tâche et un filtre par catégorie.
- Conservation des anciennes catégories sur les tâches existantes.
- Un bouton fichier sur les cartes ouvre la liste des fichiers et dossiers rattachés.

## Version 1.2.0

- Rattachement de plusieurs fichiers et dossiers à une tâche.
- Ouverture des documents depuis la fiche ou la carte.
- Conservation des fichiers à leur emplacement d’origine : seuls leurs chemins sont enregistrés.
- Conversion des lecteurs réseau en chemins partagés lorsque Windows le permet.
- Message explicite lorsqu’un document est déplacé ou inaccessible.
- Recherche prenant en compte les noms des documents rattachés.

## Version 1.1.0

- Mise à jour manuelle depuis l’application, avec téléchargement des versions publiques GitHub.
- Vérification de l’intégrité du téléchargement avant installation.
- Remplacement du logiciel avec retour à la version précédente si l’installation échoue.
- Réouverture automatique après mise à jour ; conservation du tableau et des réglages du poste.
- Ouverture de la fenêtre maximisée.

## Premières versions — octobre 2026

- Tableau partagé dans un dossier NAS ou réseau, avec installation du logiciel sur chaque PC.
- Quatre colonnes : À faire, En cours, En attente et Terminé.
- Création, attribution, modification et déplacement des tâches par glisser-déposer.
- Dates d’échéance, reports motivés, priorités et recherche.
- Case URGENCE avec triangle d’avertissement et mise en évidence des cartes.
- Actualisation automatique entre les postes et protection contre les modifications simultanées.
- Configuration des personnes, choix du prénom et nom du tableau.
- Notifications temporaires avec durée configurable et rappel des échéances à l’ouverture.
- Corbeille avec restauration des tâches.
- Sauvegardes automatiques et sauvegardes périodiques à l’ouverture, tous les X jours.
- Notice PDF illustrée et distribution Windows en dossier complet.

L’historique des premières versions regroupe les fonctionnalités initiales ; il ne reconstitue pas une date de livraison pour chacune.
