VERSION = "1.5.0"
RELEASE_REPOSITORY = "wood51/le-tableau-releases"
