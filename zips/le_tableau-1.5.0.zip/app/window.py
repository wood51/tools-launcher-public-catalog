from __future__ import annotations
import copy
import hashlib
import logging
from datetime import date, datetime
import os
from pathlib import Path
import sys
import time

from PySide6.QtCore import Qt, QObject, Signal, QRunnable, QThreadPool, QTimer, QSettings, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence
from PySide6.QtWidgets import (QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,
    QFileDialog,QMenu,QDialog,QApplication,QButtonGroup,QComboBox,QStackedWidget,QTextBrowser)
from .storage import BoardRepository, StorageError, ConflictError, STATUS_LABELS, board_settings
from .widgets import BoardColumn, TrashDropTarget, board_icon, warning_icon
from .dialogs import TaskDialog, TrashDialog
from .configuration import ConfigurationDialog
from .toast import Toast
from .version import VERSION
from .attachments import reference_exists
from .colors import board_user_colors, owner_color, badge_style
from .messages import confirm, information


class Signals(QObject):
    result=Signal(object)
    error=Signal(object)


class Job(QRunnable):
    def __init__(self,fn):
        super().__init__()
        self.fn=fn
        self.signals=Signals()

    def run(self):
        try:self.signals.result.emit(self.fn())
        except Exception as exc:self.signals.error.emit(exc)


class BoardWindow(QMainWindow):
    boardUpdated=Signal()

    def __init__(self,folder=None,persist=True,profile=None,settings=None,launcher=False):
        super().__init__()
        self.setWindowTitle("Le Tableau")
        self.setWindowIcon(board_icon())
        self.resize(1390,900)
        self.setMinimumSize(1120,700)
        self.settings=settings if settings is not None else QSettings("AtelierSimple","LeTableau")
        self.launcher=launcher
        self.persist=persist
        self.repo=None
        self.member=""
        self.profile_override=profile
        self.toast_seconds=max(3,min(30,self.settings.value("toast_seconds",5,type=int))) if persist else 5
        self.reminders=self.settings.value("reminders",True,type=bool) if persist else True
        self.reminder_key=None
        self.snapshot={"revision":-1,"tasks":[]}
        self.online=False
        self.mutating=False
        self.update_busy=False
        self.switching=False
        self.polling=False
        self.generation=0
        self.jobs={}
        self.pool=QThreadPool(self)
        self.pool.setMaxThreadCount(3)
        self.current_owner=""
        self.current_category=None
        self.only_late=False
        self.refresh_token=None
        self.dragging=False
        self.was_maximized=False
        root=QWidget()
        root.setObjectName("root")
        self.pages=QStackedWidget()
        self.setCentralWidget(self.pages)
        self.pages.addWidget(root)
        self.board_page=root
        layout=QVBoxLayout(root)
        layout.setContentsMargins(16,10,16,10)
        layout.setSpacing(8)
        self.connection=QLabel("●")
        self.connection.hide()
        menu_button=QPushButton("☰  Menu")
        self.menu_button=menu_button
        menu_button.setObjectName("mainMenu")
        menu_button.setCursor(Qt.CursorShape.PointingHandCursor)
        menu_button.setToolTip("Tâches, configuration, corbeille et aide")
        menu=QMenu(menu_button)
        self.new_action=menu.addAction("Nouvelle tâche…",lambda:self.edit_task())
        self.config_action=menu.addAction("Configuration…",self.configure)
        self.fullscreen_action=QAction("Plein écran",self)
        self.fullscreen_action.setCheckable(True)
        self.fullscreen_action.setShortcut(QKeySequence("F11"))
        self.fullscreen_action.triggered.connect(self.toggle_fullscreen)
        self.addAction(self.fullscreen_action)
        menu.addAction(self.fullscreen_action)
        self.exit_fullscreen_action=QAction(self)
        self.exit_fullscreen_action.setShortcut(QKeySequence("Escape"))
        self.exit_fullscreen_action.triggered.connect(self.exit_fullscreen)
        self.addAction(self.exit_fullscreen_action)
        menu.addSeparator()
        menu.addAction("Corbeille…",self.trash)
        menu.addSeparator()
        menu.addAction("Comment ça marche ?",self.open_guide)
        menu.addAction("Historique des versions…",self.open_history)
        menu_button.setMenu(menu)
        filters=QHBoxLayout()
        self.owner_area=QHBoxLayout()
        self.owner_area.setSpacing(3)
        self.owner_group=QButtonGroup(self)
        self.owner_group.setExclusive(True)
        filters.addLayout(self.owner_area)
        self.late_button=QPushButton("En retard")
        self.late_button.setObjectName("lateFilter")
        self.late_button.setIcon(warning_icon(16))
        self.late_button.setCheckable(True)
        self.late_button.toggled.connect(self.set_late)
        filters.addWidget(self.late_button)
        self.category_filter=QComboBox()
        self.category_filter.setMinimumWidth(155)
        self.category_filter.setMaximumWidth(220)
        self.category_filter.setToolTip("Filtrer les tâches par catégorie")
        self.category_filter.addItem("Toutes les catégories",None)
        self.category_filter.currentIndexChanged.connect(self.category_changed)
        self.category_filter.hide()
        filters.addWidget(self.category_filter)
        filters.addStretch()
        self.search=QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("Rechercher une tâche…")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(360)
        self.search.setMinimumWidth(230)
        self.search.textChanged.connect(self.render_board)
        filters.addWidget(self.search)
        filters.addWidget(self.connection)
        self.profile_badge=QLabel()
        self.profile_badge.setObjectName("profileBadge")
        self.profile_badge.setTextFormat(Qt.TextFormat.PlainText)
        self.profile_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.profile_badge.setFixedHeight(28)
        self.profile_badge.setMaximumWidth(180)
        filters.addWidget(self.profile_badge)
        filters.addWidget(menu_button)
        layout.addLayout(filters)
        columns=QHBoxLayout()
        columns.setSpacing(12)
        self.columns={}
        for status,color in [("todo","#8c9cb5"),("doing","#4f8cff"),("waiting","#f5a524"),("done","#3ecf8e")]:
            column=BoardColumn(status,color)
            column.addTask.connect(lambda s:self.edit_task(status=s))
            column.cards.openTask.connect(self.edit_task)
            column.cards.openAttachment.connect(self.open_attachment)
            column.cards.moveTask.connect(self.move_task)
            column.cards.contextTask.connect(self.card_menu)
            column.cards.emptyContext.connect(lambda pos,s=status:self.empty_menu(s,pos))
            column.cards.dragStarted.connect(self.show_drag_trash)
            column.cards.dragFinished.connect(self.hide_drag_trash)
            self.columns[status]=column
            columns.addWidget(column,1)
        layout.addLayout(columns,1)
        self.drag_trash=TrashDropTarget(root)
        self.drag_trash.hide()
        self.drag_trash.dropTask.connect(self.drop_to_trash)
        self.toast=Toast(self)
        self.welcome=QWidget()
        self.welcome.setObjectName("root")
        welcome_box=QVBoxLayout(self.welcome)
        welcome_box.setContentsMargins(110,55,110,55)
        welcome_box.setSpacing(20)
        welcome_box.addStretch()
        welcome_icon=QLabel()
        welcome_icon.setPixmap(board_icon().pixmap(64,64))
        welcome_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        welcome_box.addWidget(welcome_icon)
        welcome_title=QLabel("Bienvenue dans Le Tableau")
        welcome_title.setObjectName("boardTitle")
        welcome_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        welcome_box.addWidget(welcome_title)
        introduction=QLabel("Un tableau commun pour les tâches du bureau.\nLe logiciel sur chaque PC, les tâches dans le même dossier du NAS.")
        introduction.setObjectName("muted")
        introduction.setAlignment(Qt.AlignmentFlag.AlignCenter)
        welcome_box.addWidget(introduction)
        welcome_box.addSpacing(15)
        actions=QHBoxLayout()
        actions.addStretch()
        self.welcome_create=QPushButton("Créer le tableau")
        self.welcome_create.setObjectName("primary")
        self.welcome_create.setMinimumHeight(48)
        self.welcome_create.clicked.connect(self.create_folder)
        actions.addWidget(self.welcome_create)
        self.welcome_open=QPushButton("Ouvrir un tableau existant")
        self.welcome_open.setMinimumHeight(48)
        self.welcome_open.clicked.connect(self.choose_folder)
        actions.addWidget(self.welcome_open)
        actions.addStretch()
        welcome_box.addLayout(actions)
        instructions=QLabel("Premier PC : créez le tableau dans un dossier réservé sur le NAS.\nAutres PC : ouvrez ce même dossier.")
        instructions.setAlignment(Qt.AlignmentFlag.AlignCenter)
        instructions.setObjectName("muted")
        welcome_box.addWidget(instructions)
        help_button=QPushButton("Ouvrir la notice illustrée (PDF)")
        help_button.setObjectName("quiet")
        help_button.clicked.connect(self.open_guide)
        welcome_box.addWidget(help_button,alignment=Qt.AlignmentFlag.AlignCenter)
        welcome_box.addStretch()
        self.pages.addWidget(self.welcome)
        self.pages.setCurrentWidget(self.welcome)
        self.set_enabled(False)
        self.update_owners()
        self.update_profiles()
        self.poll_timer=QTimer(self)
        self.poll_timer.setInterval(2000)
        self.poll_timer.timeout.connect(self.refresh)
        self.poll_timer.start()
        if folder:self.open_repository(folder,existing_only=True)

    @property
    def board_key(self):
        return os.path.normcase(str(self.repo.folder.absolute())) if self.repo else ""

    def job(self,fn,success,error):
        job=Job(fn)
        key=id(job)
        self.jobs[key]=job
        def done(value):
            try:success(value)
            finally:self.jobs.pop(key,None)
        def failed(exc):
            try:error(exc)
            finally:self.jobs.pop(key,None)
        job.signals.result.connect(done)
        job.signals.error.connect(failed)
        self.pool.start(job)

    def open_repository(self,folder,existing_only=True):
        if self.mutating or self.switching:return
        self.switching=True
        self.set_enabled(False)
        repo=BoardRepository(folder)
        self.config_action.setEnabled(False)
        def success(data):
            self.switching=False
            self.repo=repo
            self.generation+=1
            self.snapshot=data
            self.current_owner=""
            self.current_category=None
            self.config_action.setEnabled(True)
            self.set_online(True)
            self.update_owners()
            self.member=self.profile_override or (self.settings.value(self.profile_key(),"") if self.persist else "")
            self.update_profiles()
            self.render_board()
            self.pages.setCurrentWidget(self.board_page)
            if self.persist:
                self.settings.setValue("folder",str(repo.folder))
            self.remind_due()
            generation=self.generation
            def backed_up(path):
                if path and generation==self.generation:self.flash("Copie de sauvegarde périodique créée dans le dossier du tableau.")
            def backup_failed(exc):
                if generation==self.generation:self.flash("La sauvegarde périodique n’a pas pu être créée. Vérifiez les droits du dossier ou réessayez à la prochaine ouverture.")
            self.job(repo.backup_on_open,backed_up,backup_failed)
            self.refresh()
        def failure(exc):
            self.switching=False
            self.config_action.setEnabled(True)
            self.flash(str(exc))
            self.set_online(self.online if self.repo else False)
        self.job(lambda:repo.initialize(existing_only=existing_only),success,failure)

    def set_enabled(self,enabled):
        self.new_action.setEnabled(enabled)
        for column in self.columns.values():
            column.add_button.setEnabled(enabled)
            column.cards.setDragEnabled(enabled)
            column.cards.setAcceptDrops(enabled)

    def set_online(self,online):
        self.online=online
        self.set_enabled(online and not self.mutating and not self.switching)
        self.connection.setText("Dossier inaccessible · lecture seule")
        self.connection.setVisible(not online)
        self.connection.setToolTip("Les dernières tâches restent affichées. L’enregistrement sera possible au retour du dossier partagé.")
        self.connection.setStyleSheet("color:#f5a524;font-size:9pt")

    def refresh(self):
        if not self.repo or self.polling or self.mutating or self.switching or QApplication.mouseButtons()!=Qt.MouseButton.NoButton:return
        self.polling=True
        generation=self.generation
        repo=self.repo
        def success(data):
            self.polling=False
            if generation!=self.generation:return
            self.set_online(True)
            if data["revision"]>=self.snapshot["revision"]:
                changed=data!=self.snapshot
                self.snapshot=data
                self.update_owners()
                self.update_profiles()
                if changed or self.refresh_token!=date.today():self.render_board()
                self.remind_due()
        def failure(exc):
            self.polling=False
            if generation==self.generation:self.set_online(False)
        self.job(repo.generate_recurrences,success,failure)

    def apply_snapshot(self,data):
        if data["revision"]>=self.snapshot["revision"]:
            self.snapshot=data
            self.update_owners()
            self.update_profiles()
            self.render_board()

    def owners(self):
        return list(dict.fromkeys([*board_settings(self.snapshot)["users"],*sorted({t["owner"] for t in self.snapshot["tasks"] if t["owner"] and not t["deleted"]})]))

    def profile_key(self):
        key=hashlib.sha256(self.board_key.encode("utf-8")).hexdigest()[:20]
        return "profile/"+key

    def update_profiles(self):
        config=board_settings(self.snapshot)
        names=config["users"]
        if self.member not in names:self.member=""
        self.profile_badge.setText(self.member or "Profil non choisi")
        self.profile_badge.setToolTip(("Sur ce PC : "+self.member+"\n" if self.member else "")+
            "Choisir votre prénom dans Menu → Configuration → Sur ce PC")
        self.profile_badge.setStyleSheet(badge_style(owner_color(self.member,names,board_user_colors(config))))

    def remind_due(self):
        key=(self.board_key,date.today())
        if not self.reminders or key==self.reminder_key:return
        self.reminder_key=key
        today=date.today().isoformat()
        active=[t for t in self.snapshot["tasks"] if not t["deleted"] and t["status"]!="done"]
        late=sum(bool(t["due"] and t["due"]<today) for t in active)
        due=sum(t["due"]==today for t in active)
        if late or due:self.flash(f"À surveiller aujourd’hui : {late} tâche(s) en retard · {due} pour aujourd’hui.")

    def update_owners(self):
        labels=["Tout le monde",*self.owners()]
        colors=board_user_colors(board_settings(self.snapshot))
        key=(labels,colors)
        if getattr(self,"owner_labels",None)==key:return
        self.owner_labels=key
        while self.owner_area.count():
            item=self.owner_area.takeAt(0)
            if item.widget():
                self.owner_group.removeButton(item.widget())
                item.widget().hide()
                item.widget().deleteLater()
        if self.current_owner and self.current_owner not in labels:self.current_owner=""
        for text in labels[:6]:
            value="" if text=="Tout le monde" else text
            button=QPushButton(text)
            button.setObjectName("filter")
            if value:
                color=owner_color(value,overrides=colors)
                button.setStyleSheet(f"""
                    QPushButton {{ {badge_style(color)} border: 2px solid transparent;
                        border-radius: 14px; padding: 5px 12px; }}
                    QPushButton:checked {{ border-color: #ffffff; }}
                    QPushButton:hover {{ border-color: #bccde4; }}
                """)
            button.setCheckable(True)
            button.setChecked(value==self.current_owner)
            button.clicked.connect(lambda checked,v=value:self.set_owner(v))
            self.owner_group.addButton(button)
            self.owner_area.addWidget(button)

    def set_owner(self,owner):
        self.current_owner=owner
        self.render_board()

    def set_late(self,on):
        self.only_late=on
        self.render_board()

    def update_categories(self):
        names=list(dict.fromkeys([*board_settings(self.snapshot)["categories"],
            *sorted({t.get("category","") for t in self.snapshot["tasks"] if not t["deleted"] and t.get("category")})]))
        choices=[("Toutes les catégories",None),("Sans catégorie","")]+[(name,name) for name in names]
        values=[value for _,value in choices]
        if self.current_category not in values:self.current_category=None
        current=[(self.category_filter.itemText(i),self.category_filter.itemData(i)) for i in range(self.category_filter.count())]
        self.category_filter.blockSignals(True)
        if current!=choices:
            self.category_filter.clear()
            for label,value in choices:self.category_filter.addItem(label,value)
        self.category_filter.setCurrentIndex(values.index(self.current_category))
        self.category_filter.blockSignals(False)
        self.category_filter.setVisible(bool(names))

    def category_changed(self,index):
        self.current_category=self.category_filter.currentData()
        self.render_board()

    def render_board(self):
        self.update_categories()
        self.refresh_token=date.today()
        live=[t for t in self.snapshot["tasks"] if not t["deleted"]]
        active=[t for t in live if t["status"]!="done"]
        today=date.today().isoformat()
        overdue=[t for t in active if t["due"] and t["due"]<today]
        self.late_button.setText(f"En retard ({len(overdue)})")
        search=self.search.text().casefold().strip()
        visible=[t for t in live if (not self.current_owner or t["owner"]==self.current_owner)
                 and (self.current_category is None or t.get("category","")==self.current_category)
                 and (not self.only_late or t in overdue)
                 and (not search or search in " ".join([*[t[k] for k in ("title","client","owner","notes")],t.get("category",""),
                     *[a["name"] for a in t.get("attachments",[])]]).casefold())]
        for status,column in self.columns.items():
            tasks=[t for t in visible if t["status"]==status]
            if status=="done":tasks.sort(key=lambda t:t["updated"],reverse=True)
            else:tasks.sort(key=lambda t:(not (t.get("emergency",False) or t["urgent"]),t["due"] or "9999-12-31",t["created"]))
            column.cards.populate(tasks,self.board_key,board_user_colors(board_settings(self.snapshot)))
            column.count_label.setText(str(len(tasks)))
        self.boardUpdated.emit()

    def find(self,ident):
        return next((t for t in self.snapshot["tasks"] if t["id"]==ident and not t["deleted"]),None)

    def flash(self,text):
        self.toast.notify(text,self.toast_seconds)

    def open_attachment(self,attachment,on_error=None):
        def failure(message):
            if on_error:on_error(message)
            else:self.flash(message)
        def checked(exists):
            if not exists:
                failure("Ce fichier ou dossier est introuvable ou inaccessible. Vérifiez le NAS ; s’il a été déplacé ou renommé, rattachez son nouveau chemin depuis la fiche.")
                return
            try:
                if os.name=="nt":
                    os.startfile(attachment["path"])
                elif not QDesktopServices.openUrl(QUrl.fromLocalFile(attachment["path"])):
                    raise OSError("Aucune application n’a accepté ce chemin")
            except OSError as exc:
                logging.exception("Ouverture du lien impossible : %s",attachment["path"])
                code=getattr(exc,"winerror",None) or getattr(exc,"errno",None)
                detail=f" (erreur Windows {code})" if code else ""
                failure("Windows n’a pas pu ouvrir ce fichier ou dossier"+detail+". Vérifiez l’accès au NAS et l’application associée.")
        self.job(lambda:reference_exists(attachment),checked,
                 lambda exc:failure("Ce fichier ou dossier est inaccessible. Vérifiez son emplacement et la connexion au NAS."))

    def edit_task(self,ident=None,status="todo"):
        if not self.online or self.mutating or self.switching:return
        task=self.find(ident) if ident else None
        if ident and task is None:return
        dialog_task=copy.deepcopy(task) if task else None
        if dialog_task and dialog_task.get("recurrence_id"):
            series=self.snapshot.get("recurrences",{}).get(dialog_task["recurrence_id"])
            if series and series.get("active") and series.get("current_task_id")==dialog_task["id"]:
                dialog_task["recurrence"]={key:series[key] for key in ("mode","unit","interval")}
        dialog=TaskDialog(dialog_task,self.owners(),status,self,categories=board_settings(self.snapshot)["categories"])
        if task is None and self.current_category:
            dialog.category.setCurrentIndex(max(0,dialog.category.findData(self.current_category)))
            dialog.initial=dialog.fields()
        dialog.openAttachmentRequested.connect(lambda attachment:self.open_attachment(
            attachment,lambda message:dialog.attachment_error(message) if dialog.isVisible() else self.flash(message)))
        if task is None and self.member:
            dialog.owner.setCurrentText(self.member)
            dialog.initial=dialog.fields()
        def save(original,fields,note):
            repo=self.repo
            fn=(lambda:repo.update(original["id"],original["version"],fields,note)) if original else (lambda:repo.create(fields))
            self.mutating=True
            self.set_enabled(False)
            def success(data):
                self.mutating=False
                self.apply_snapshot(data)
                self.set_online(True)
                dialog.saving=False
                dialog.accept()
                self.flash("Tâche enregistrée.")
            def failure(exc):
                self.mutating=False
                self.set_enabled(self.online)
                dialog.show_error(str(exc) if isinstance(exc,StorageError) else "L’enregistrement a échoué. Votre saisie est conservée dans cette fiche.")
                self.refresh()
            self.job(fn,success,failure)
        dialog.saveRequested.connect(save)
        dialog.exec()

    def mutate(self,task,changes,message):
        if not self.online or self.mutating or self.switching:return
        repo=self.repo
        self.mutating=True
        self.set_enabled(False)
        def success(data):
            self.mutating=False
            self.apply_snapshot(data)
            self.set_online(True)
            self.flash(message)
        def failure(exc):
            self.mutating=False
            self.set_enabled(self.online)
            self.flash(str(exc) if isinstance(exc,StorageError) else "Modification non enregistrée. Réessayez après actualisation.")
            self.refresh()
        self.job(lambda:repo.update(task["id"],task["version"],changes),success,failure)

    def move_task(self,ident,version,status):
        task=self.find(ident)
        if task is None or task["status"]==status:return
        self.mutate({**task,"version":version},{"status":status},"Tâche déplacée dans « "+STATUS_LABELS[status]+" ».")

    def show_drag_trash(self):
        self.drag_trash.board_key=self.board_key
        self.drag_trash.show()
        self.drag_trash.raise_()
        self.place_drag_trash()

    def hide_drag_trash(self):
        self.drag_trash.hide()

    def place_drag_trash(self):
        if not hasattr(self,"drag_trash"):return
        area=self.board_page.rect()
        self.drag_trash.move(max(0,(area.width()-self.drag_trash.width())//2),
                             max(0,area.height()-self.drag_trash.height()-128))

    def drop_to_trash(self,ident,version):
        task=self.find(ident)
        self.hide_drag_trash()
        if task:
            self.mutate({**task,"version":version},{"deleted":True},
                        "Tâche placée dans la corbeille. Elle reste récupérable.")

    def card_menu(self,ident,pos):
        task=self.find(ident)
        if task is None or not self.online:return
        menu=QMenu(self)
        menu.addAction("Nouvelle tâche dans cette colonne…",lambda:self.edit_task(status=task["status"]))
        menu.addSeparator()
        menu.addAction("Ouvrir la tâche",lambda:self.edit_task(ident))
        if task.get("attachments"):
            attachments_menu=menu.addMenu("Ouvrir un fichier ou dossier lié")
            for attachment in task["attachments"]:
                attachments_menu.addAction(attachment["name"].replace("&","&&"),lambda checked=False,a=attachment:self.open_attachment(a))
        submenu=menu.addMenu("Déplacer vers")
        for status,label in STATUS_LABELS.items():
            if status!=task["status"]:
                submenu.addAction(label,lambda s=status:self.move_task(task["id"],task["version"],s))
        menu.addSeparator()
        menu.addAction("Mettre à la corbeille…",lambda:self.remove_task(task))
        menu.exec(pos)

    def empty_menu(self,status,pos):
        if not self.online or self.mutating or self.switching:return
        menu=QMenu(self)
        menu.addAction("Nouvelle tâche…",lambda:self.edit_task(status=status))
        menu.exec(pos)

    def remove_task(self,task):
        if confirm(self,"Retirer une tâche","Mettre cette tâche à la corbeille ?\n\n"+task["title"]+"\n\nVous pourrez la restaurer depuis Menu → Corbeille.","Mettre à la corbeille"):
            self.mutate(task,{"deleted":True},"Tâche placée dans la corbeille. Elle reste récupérable.")

    def trash(self):
        if self.mutating:return
        dialog=TrashDialog([t for t in self.snapshot["tasks"] if t["deleted"]],self)
        def restore(task):
            if not self.online:return
            dialog.accept()
            self.mutate(task,{"deleted":False},"Tâche restaurée.")
        dialog.restoreRequested.connect(restore)
        def empty_trash():
            tasks=[task for task in self.snapshot["tasks"] if task["deleted"]]
            if not tasks:return
            if not confirm(dialog,"Vider la corbeille",
                f"Supprimer définitivement {len(tasks)} tâche(s) de la corbeille ?\n\nElles ne seront plus restaurables depuis l’application. Les sauvegardes existantes ne sont pas effacées.",
                "Vider la corbeille"):
                return
            dialog.accept()
            repo=self.repo
            self.mutating=True
            self.set_enabled(False)
            def success(data):
                self.mutating=False
                self.apply_snapshot(data)
                self.set_online(True)
                self.flash("Corbeille vidée.")
            def failure(exc):
                self.mutating=False
                self.set_enabled(self.online)
                self.flash(str(exc) if isinstance(exc,StorageError) else "La corbeille n’a pas pu être vidée.")
            self.job(repo.purge_deleted,success,failure)
        dialog.emptyRequested.connect(empty_trash)
        dialog.exec()

    def configure(self):
        if self.mutating or self.switching:return
        dialog=ConfigurationDialog(self.snapshot,self.repo.folder if self.repo else "Aucun dossier ouvert",self.member,self.toast_seconds,self.reminders,self)
        dialog.openRequested.connect(self.choose_folder)
        dialog.createRequested.connect(self.create_folder)
        dialog.openBoardFolderRequested.connect(self.open_folder)
        dialog.openBackupsRequested.connect(self.open_backups)
        dialog.openPeriodicBackupsRequested.connect(self.open_periodic_backups)
        def save(values):
            if not self.repo or not self.online:
                dialog.show_error("Le dossier du tableau est inaccessible. Ouvrez un tableau ou réessayez après reconnexion.")
                return
            self.mutating=True
            self.set_enabled(False)
            repo=self.repo
            def success(data):
                self.mutating=False
                self.apply_snapshot(data)
                self.member=values["member"]
                self.toast_seconds=values["duration"]
                self.reminders=values["reminders"]
                if self.persist:
                    self.settings.setValue(self.profile_key(),self.member)
                    self.settings.setValue("toast_seconds",self.toast_seconds)
                    self.settings.setValue("reminders",self.reminders)
                self.update_profiles()
                self.set_online(True)
                dialog.saving=False
                dialog.accept()
                self.flash("Configuration enregistrée.")
            def failure(exc):
                self.mutating=False
                self.set_enabled(self.online)
                dialog.show_error(str(exc) if isinstance(exc,StorageError) else "La configuration n’a pas été enregistrée. Réessayez.")
                self.refresh()
            self.job(lambda:repo.configure(values["title"],values["users"],values["version"],values["backup_days"],values["user_colors"],values["categories"]),success,failure)
        dialog.saveRequested.connect(save)
        dialog.exec()

    def choose_folder(self):
        if self.mutating or self.switching:return
        folder=QFileDialog.getExistingDirectory(self,"Ouvrir le dossier du tableau existant sur le NAS",str(self.repo.folder.parent) if self.repo else "")
        if not folder:return
        if self.repo and os.path.normcase(os.path.abspath(folder))==self.board_key:return
        if not (Path(folder)/BoardRepository.filename).exists():
            self.flash("Aucun tableau dans ce dossier. Choisissez celui utilisé sur l’autre poste, ou utilisez « Créer le tableau » au premier démarrage.")
            return
        self.open_repository(folder,existing_only=True)

    def create_folder(self):
        if self.mutating or self.switching:return
        folder=QFileDialog.getExistingDirectory(self,"Choisir un dossier réservé au nouveau tableau sur le NAS",str(self.repo.folder.parent) if self.repo else "")
        if not folder:return
        if (Path(folder)/BoardRepository.filename).exists():
            self.flash("Un tableau existe déjà dans ce dossier. Il a été ouvert sans effacer les tâches.")
            self.open_repository(folder,existing_only=True)
            return
        if confirm(self,"Créer le tableau commun","Créer un tableau vide dans ce dossier ?\n\n"+folder+"\n\nSur le second PC, utilisez « Ouvrir un tableau existant » et choisissez ce même dossier.","Créer le tableau",default_accept=True):
            self.open_repository(folder,existing_only=False)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,"toast"):self.toast.place()
        self.place_drag_trash()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            if self.was_maximized:self.showMaximized()
            else:self.showNormal()
        else:
            self.was_maximized=self.isMaximized()
            self.showFullScreen()
        self.fullscreen_action.setChecked(self.isFullScreen())

    def exit_fullscreen(self):
        if self.isFullScreen():self.toggle_fullscreen()

    def changeEvent(self,event):
        super().changeEvent(event)
        if hasattr(self,"fullscreen_action"):
            self.fullscreen_action.setChecked(self.isFullScreen())

    def open_history(self):
        folder=Path(getattr(sys,"_MEIPASS",Path(__file__).resolve().parent.parent))
        dialog=QDialog(self)
        dialog.setWindowTitle("Historique des versions")
        dialog.resize(720,650)
        box=QVBoxLayout(dialog)
        browser=QTextBrowser()
        browser.setOpenExternalLinks(False)
        try:browser.setMarkdown((folder/"HISTORIQUE.md").read_text(encoding="utf-8"))
        except OSError:browser.setPlainText("L’historique n’est pas disponible dans ce dossier du logiciel.")
        box.addWidget(browser)
        close=QPushButton("Fermer")
        close.clicked.connect(dialog.accept)
        box.addWidget(close,alignment=Qt.AlignmentFlag.AlignRight)
        dialog.exec()

    def open_folder(self):
        if self.repo:QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.repo.folder)))

    def open_backups(self):
        if self.repo:
            folder=self.repo.folder/"Sauvegardes"
            if folder.exists():QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
            else:self.flash("La première sauvegarde sera créée lors d’une modification du tableau.")

    def open_guide(self):
        root=Path(sys.executable).parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent.parent
        candidates=(root/"Guide-utilisateur-Le-Tableau.pdf",root/"output"/"pdf"/"Guide-utilisateur-Le-Tableau.pdf")
        path=next((candidate for candidate in candidates if candidate.is_file()),None)
        if path:QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:self.flash("Le guide illustré est fourni dans le dossier complet du logiciel.")

    def open_periodic_backups(self):
        if not self.repo:return
        folder=self.repo.folder/"Sauvegardes periodiques"
        if folder.exists():QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
        else:self.flash("La première copie périodique sera créée à l’ouverture du tableau, selon le délai choisi dans Configuration.")

    def help(self):
        information(self,"Comment ça marche ?",
            "1. Cliquez sur le + d’une colonne ou faites un clic droit dans cette colonne pour créer une tâche.\n2. Choisissez un responsable et, si utile, une date.\n3. Glissez la carte dans une autre colonne pour la faire avancer.\n\n"
            "Cliquez sur une carte pour la modifier ou la reporter. Un clic droit permet de la retirer ; la corbeille reste accessible dans Menu.\n\n"
            "F11 : activer ou quitter le plein écran. Échap : sortir du plein écran.\n\n"
            "À deux : chacun copie le dossier du logiciel sur son PC. Dans Configuration, le premier crée le tableau sur le NAS ; le second ouvre ce même dossier. Choisissez aussi votre prénom et la durée des notifications. Les changements apparaissent toutes les 2 secondes.\n\n"
            "Utilisez un partage réseau direct, pas deux copies synchronisées par OneDrive ou Dropbox. Les sauvegardes sont conservées dans le dossier du tableau.\n\n"
            "En cas de coupure réseau, les dernières tâches restent visibles ; l’enregistrement attend le retour de la connexion.")

    def about(self):
        information(self,"À propos",f"Le Tableau · version {VERSION}\n\nUn tableau de tâches pour le bureau.\nDonnées conservées dans le dossier que vous choisissez.\n\nApplication Python / PySide6.\nPySide6 et Qt : licences LGPLv3 / GPLv3 / commerciale.\nLes textes des licences sont fournis avec l’application.")

    def check_updates(self):
        if self.launcher:
            self.flash("Les mises à jour de cette édition se font dans Tools Launcher > Catalogue…")
            return
        if QApplication.instance().property("tableauExtension"):
            self.flash("Cette édition Python se met à jour en remplaçant ses fichiers, en conservant le dossier data.")
            return
        if self.mutating or self.switching or self.update_busy:
            self.flash("Attendez la fin de l’opération en cours.")
            return
        from .update_dialog import UpdateDialog
        dialog=UpdateDialog(self)
        dialog.exec()

    def closeEvent(self,event):
        if self.mutating or self.switching or self.update_busy:
            self.flash("L’enregistrement est en cours. Attendez quelques secondes avant de fermer.")
            event.ignore()
            return
        self.poll_timer.stop()
        # A background NAS request may still be finishing. Keep its signal objects
        # alive until Qt tears down the window, without blocking close on the LAN.
        event.accept()
