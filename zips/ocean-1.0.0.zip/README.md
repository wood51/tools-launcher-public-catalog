# Océan

Thème sombre bleu nuit avec un accent turquoise. Extension de type `theme` : un fichier de couleurs (`ocean.json`), sans code.
